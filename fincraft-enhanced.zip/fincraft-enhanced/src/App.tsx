import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import MarketHub from "@/pages/MarketHub";
import MarketSimulation from "@/pages/MarketSimulation";
import BoardroomHub from "@/pages/BoardroomHub";
import BoardroomSimulation from "@/pages/BoardroomSimulation";
import Career from "@/pages/Career";
import Report from "@/pages/Report";
import ProblemRoomHub from "@/pages/ProblemRoomHub";
import ProblemRoomSimulation from "@/pages/ProblemRoomSimulation";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/market" component={MarketHub} />
      <Route path="/market/:scenarioId" component={MarketSimulation} />
      <Route path="/boardroom" component={BoardroomHub} />
      <Route path="/boardroom/:scenarioId" component={BoardroomSimulation} />
      <Route path="/career" component={Career} />
      <Route path="/report" component={Report} />
      <Route path="/problem" component={ProblemRoomHub} />
      <Route path="/problem/:scenarioId" component={ProblemRoomSimulation} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: "#12141A",
              border: "1px solid #1E2028",
              color: "#fff",
              fontFamily: "'IBM Plex Mono', monospace",
              fontSize: "12px",
            },
          }}
        />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
