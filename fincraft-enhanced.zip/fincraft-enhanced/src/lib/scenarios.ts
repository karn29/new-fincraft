export interface CompanyDossier {
  id: string;
  name: string;
  sector: string;
  founded: number;
  description: string;
  revenue: string;
  revenueChange: string;
  profitMargin: string;
  debtToEquity: string;
  marketCap: string;
  model: { label: string; pct: number }[];
  maxAlloc: number;
  sectorReturn: number;
}

export const marketScenarios = [
  {
    id: "1929",
    title: "1929 — BLACK TUESDAY",
    threatLevel: "CRITICAL",
    hook: "The day the roaring twenties died. Were you long?",
    date: "October 24, 1929",
    startingPortfolio: 100000,
    currency: "$",
    brief: "The US economy had been on a decade-long euphoria. Margin trading was rampant — investors were borrowing 90 cents on every dollar. The market had tripled since 1921. Then the whispers started. Banks began calling in loans. The Dow stood at 305 points.",
    fearGreed: 72,
    sectors: [
      { name: "Banking", value: -60 },
      { name: "Rail", value: -45 },
      { name: "Steel", value: -55 },
      { name: "Utilities", value: -30 },
      { name: "Auto", value: -50 },
      { name: "Mining", value: -65 },
      { name: "Retail", value: -35 },
      { name: "Bonds", value: 25 },
    ],
    news: [
      "WALL STREET SETS NEW ALL-TIME HIGH",
      "ECONOMIST PREDICTS FURTHER GAINS",
      "BANKS REPORT RECORD LENDING",
      "AUTO SALES HIT DECADE HIGH",
      "MARGIN ACCOUNTS AT RECORD LEVELS",
      "FEDERAL RESERVE SIGNALS CONCERN"
    ],
    companies: [
      {
        id: "gm",
        name: "General Motors",
        sector: "Automotive",
        founded: 1908,
        description: "General Motors is America's largest automaker, producing Chevrolet, Buick, and Cadillac vehicles for a rapidly motorizing nation. The company earns money by manufacturing and selling cars to a middle class flush with credit. It represents the beating heart of the 1920s consumer boom. In October 1929, its stock had risen 400% in four years on borrowed capital.",
        revenue: "$1.5B",
        revenueChange: "+18%",
        profitMargin: "12%",
        debtToEquity: "0.4",
        marketCap: "$800M",
        model: [{ label: "Vehicle Sales", pct: 85 }, { label: "Parts & Service", pct: 10 }, { label: "Financing", pct: 5 }],
        maxAlloc: 40,
        sectorReturn: -50,
      },
      {
        id: "uss",
        name: "US Steel",
        sector: "Industrial",
        founded: 1901,
        description: "US Steel is the world's first billion-dollar corporation, controlling 67% of American steel output. Its profits flow from selling steel to railroads, auto companies, and construction firms fueled by the decade's building frenzy. In 1929, its stock commanded a premium as infrastructure demand appeared limitless. But steel is a cyclical business, and when credit dries up, orders evaporate overnight.",
        revenue: "$1.2B",
        revenueChange: "+8%",
        profitMargin: "9%",
        debtToEquity: "0.6",
        marketCap: "$1.1B",
        model: [{ label: "Structural Steel", pct: 60 }, { label: "Rail Products", pct: 25 }, { label: "Wire & Tubes", pct: 15 }],
        maxAlloc: 40,
        sectorReturn: -55,
      },
      {
        id: "chase",
        name: "Chase National Bank",
        sector: "Banking",
        founded: 1877,
        description: "Chase National is America's third-largest bank by assets, deeply embedded in the margin-lending frenzy that fueled the bull market. It profits by lending money to investors to buy stocks — a machine that works beautifully until it doesn't. When stocks fall, borrowers can't repay, banks call loans, stocks fall further. Chase is both the engine of the boom and the ignition point of the collapse.",
        revenue: "$180M",
        revenueChange: "+22%",
        profitMargin: "31%",
        debtToEquity: "12.0",
        marketCap: "$550M",
        model: [{ label: "Margin Loans", pct: 55 }, { label: "Deposits", pct: 30 }, { label: "Securities", pct: 15 }],
        maxAlloc: 40,
        sectorReturn: -60,
      },
      {
        id: "rca",
        name: "Radio Corporation (RCA)",
        sector: "Technology",
        founded: 1919,
        description: "RCA is the defining technology company of the 1920s, broadcasting radio into American homes and transforming mass media. It earns money through radio set manufacturing, broadcast licenses, and entertainment content. Wall Street called it the 'stock of the decade' and bid it from $11 to $549 between 1921 and 1929. With zero earnings and extraordinary hype, it was the Dot-com stock of its era.",
        revenue: "$182M",
        revenueChange: "+45%",
        profitMargin: "4%",
        debtToEquity: "1.8",
        marketCap: "$1.5B",
        model: [{ label: "Radio Sets", pct: 60 }, { label: "Broadcasting", pct: 25 }, { label: "Patents", pct: 15 }],
        maxAlloc: 40,
        sectorReturn: -65,
      },
      {
        id: "bonds",
        name: "US Government Bonds",
        sector: "Fixed Income",
        founded: 1776,
        description: "US Government Bonds are the safest instrument in the world, backed by the full faith and credit of the American government. They earn a fixed coupon (interest) paid semi-annually regardless of market conditions. In panics, capital floods into government bonds as investors seek capital preservation over returns. In 1929, 10-year Treasuries yielded about 3.3% — modest but certain in a world of collapsing certainties.",
        revenue: "N/A",
        revenueChange: "N/A",
        profitMargin: "N/A",
        debtToEquity: "N/A",
        marketCap: "N/A",
        model: [{ label: "Fixed Coupon", pct: 100 }],
        maxAlloc: 40,
        sectorReturn: 25,
      },
      {
        id: "socon",
        name: "Standard Oil of New Jersey",
        sector: "Energy",
        founded: 1882,
        description: "Standard Oil of New Jersey (predecessor to ExxonMobil) controls America's oil refining and distribution after the breakup of the original Rockefeller trust. It earns money by refining crude oil into gasoline, kerosene, and industrial oil — fuels demanded by the automobile age. Its dividends are consistent and its cashflows are tied to commodity prices. In crashes, energy companies bleed slower than financials.",
        revenue: "$890M",
        revenueChange: "+12%",
        profitMargin: "14%",
        debtToEquity: "0.3",
        marketCap: "$900M",
        model: [{ label: "Refining", pct: 65 }, { label: "Distribution", pct: 25 }, { label: "Exploration", pct: 10 }],
        maxAlloc: 40,
        sectorReturn: -30,
      },
    ],
    referenceInvestor: "Jesse Livermore",
    referenceQuote: "Livermore shorted the market and made $100M. He saw the euphoria for what it was.",
    benchmark: -25
  },
  {
    id: "1991",
    title: "1991 — INDIA LIBERALIZATION",
    threatLevel: "EXTREME",
    hook: "The IMF gave us 15 days. Manmohan opened the gates. Would you have bet on India?",
    date: "July 24, 1991",
    startingPortfolio: 1000000,
    currency: "₹",
    brief: "India had 2 weeks of foreign exchange reserves left. The IMF was at the door. Finance Minister Manmohan Singh was preparing a historic budget. The rupee was about to be devalued. The question was not if things would change — it was whether you believed India could rise from this moment.",
    fearGreed: 15,
    sectors: [
      { name: "Export IT", value: 80 },
      { name: "Banking", value: -20 },
      { name: "FMCG", value: 40 },
      { name: "Infrastructure", value: 60 },
      { name: "Oil", value: -30 },
      { name: "Textiles", value: 55 },
      { name: "Auto", value: 45 },
      { name: "Pharma", value: 70 },
    ],
    news: [
      "IMF LOAN APPROVED — INDIA PLEDGES REFORMS",
      "RUPEE DEVALUED BY 18% IN TWO DAYS",
      "MANMOHAN SINGH PRESENTS REVOLUTIONARY BUDGET",
      "LICENSE RAJ TO BE DISMANTLED",
      "FOREIGN INVESTMENT NOW PERMITTED",
      "SENSEX FALLS ON REFORM UNCERTAINTY"
    ],
    companies: [
      {
        id: "infosys91",
        name: "Infosys",
        sector: "Information Technology",
        founded: 1981,
        description: "Infosys is a Bangalore-based software services firm that helps US companies build technology systems. It earns money by billing American corporations at $15/hour for Indian engineers — a 10x cost arbitrage that's impossible to ignore. The rupee devaluation makes every dollar of foreign revenue worth 18% more overnight. This is a company positioned to benefit from the exact policy change that everyone else fears.",
        revenue: "₹45Cr",
        revenueChange: "+67%",
        profitMargin: "21%",
        debtToEquity: "0.1",
        marketCap: "₹120Cr",
        model: [{ label: "Software Services", pct: 90 }, { label: "Products", pct: 7 }, { label: "Training", pct: 3 }],
        maxAlloc: 40,
        sectorReturn: 80,
      },
      {
        id: "reliance91",
        name: "Reliance Industries",
        sector: "Conglomerate",
        founded: 1966,
        description: "Reliance Industries, led by Dhirubhai Ambani, is India's largest private sector company spanning textiles, petrochemicals, and refining. It earns money by selling products to India's massive domestic consumer base and exporting yarn and chemicals. License Raj removal removes the regulatory ceiling on Reliance's expansion — it can now grow as fast as its capital allows. Dhirubhai had cultivated political relationships across party lines for exactly this moment.",
        revenue: "₹5,200Cr",
        revenueChange: "+28%",
        profitMargin: "11%",
        debtToEquity: "1.1",
        marketCap: "₹8,500Cr",
        model: [{ label: "Petrochemicals", pct: 45 }, { label: "Textiles", pct: 35 }, { label: "Trading", pct: 20 }],
        maxAlloc: 40,
        sectorReturn: 45,
      },
      {
        id: "hdfc91",
        name: "HDFC Bank",
        sector: "Financial Services",
        founded: 1977,
        description: "HDFC (Housing Development Finance Corporation) is India's premier housing finance institution, lending money for home loans to India's growing middle class. It earns money through the interest spread between its cost of borrowing and the rates it charges homebuyers. Liberalization will deregulate the financial sector, allow foreign capital to flow in, and dramatically expand the pool of bankable Indians. HDFC is positioned at the center of this credit revolution.",
        revenue: "₹320Cr",
        revenueChange: "+19%",
        profitMargin: "28%",
        debtToEquity: "8.2",
        marketCap: "₹1,100Cr",
        model: [{ label: "Home Loans", pct: 70 }, { label: "Corporate Loans", pct: 20 }, { label: "Insurance", pct: 10 }],
        maxAlloc: 40,
        sectorReturn: 60,
      },
      {
        id: "ranbaxy91",
        name: "Ranbaxy Laboratories",
        sector: "Pharmaceuticals",
        founded: 1961,
        description: "Ranbaxy is India's largest pharmaceutical company, manufacturing generic medicines for both domestic consumption and export to the US and Europe. It earns money by producing copies of off-patent drugs at a fraction of their branded cost. The rupee devaluation makes Indian pharma exports dramatically more competitive globally overnight. Ranbaxy holds WHO approvals needed to supply international health agencies — a moat that took years to build.",
        revenue: "₹480Cr",
        revenueChange: "+34%",
        profitMargin: "16%",
        debtToEquity: "0.4",
        marketCap: "₹1,200Cr",
        model: [{ label: "Generic Exports", pct: 55 }, { label: "Domestic Branded", pct: 35 }, { label: "Bulk Drugs", pct: 10 }],
        maxAlloc: 40,
        sectorReturn: 70,
      },
      {
        id: "hindalco91",
        name: "Hindalco Industries",
        sector: "Metals & Mining",
        founded: 1958,
        description: "Hindalco is India's largest aluminium producer, manufacturing metal used in everything from power cables to consumer goods. It earns money by smelting bauxite into aluminium and selling to auto, construction, and packaging companies. License Raj removal means Hindalco can expand capacity without government approval — a bottleneck that had stunted Indian industry for 40 years. India's infrastructure boom will need enormous amounts of metal.",
        revenue: "₹820Cr",
        revenueChange: "+11%",
        profitMargin: "9%",
        debtToEquity: "0.8",
        marketCap: "₹900Cr",
        model: [{ label: "Aluminium", pct: 75 }, { label: "Copper", pct: 18 }, { label: "By-Products", pct: 7 }],
        maxAlloc: 40,
        sectorReturn: 40,
      },
    ],
    referenceInvestor: "Rakesh Jhunjhunwala",
    referenceQuote: "RJ bet everything on India's liberalization moment and built his fortune here.",
    benchmark: 28
  },
  {
    id: "1992",
    title: "1992 — HARSHAD MEHTA SCAM",
    threatLevel: "EXTREME",
    hook: "₹5000 crore. Fake bank receipts. The bull that broke a nation. Did you see it coming?",
    date: "April 1992",
    startingPortfolio: 1000000,
    currency: "₹",
    brief: "Harshad Mehta had driven the BSE Sensex from 1000 to 4500 in 18 months. He was buying ACC cement at ₹200 and selling it at ₹9000. He called himself the Big Bull. Journalist Sucheta Dalal was about to expose the biggest banking fraud in Indian history. The question was: did you see the cracks?",
    fearGreed: 88,
    sectors: [
      { name: "Banking", value: 90 },
      { name: "Cement", value: 85 },
      { name: "Steel", value: 70 },
      { name: "Auto", value: 60 },
      { name: "FMCG", value: 30 },
      { name: "IT", value: 20 },
      { name: "Pharma", value: 15 },
      { name: "Bonds", value: -10 },
    ],
    news: [
      "SENSEX CROSSES 4500 — HARSHAD MEHTA'S BULL RUN CONTINUES",
      "ACC CEMENT UP 4500% IN 18 MONTHS",
      "BANKS REPORT RECORD PROFITS",
      "RBI RAISES CONCERNS ABOUT BANK RECEIPTS",
      "FOREIGN INVESTORS POUR INTO INDIA",
      "SMALL INVESTORS TAKING LOANS TO BUY STOCKS"
    ],
    companies: [
      {
        id: "acc",
        name: "ACC Cement",
        sector: "Cement",
        founded: 1936,
        description: "ACC Cement is India's oldest and largest cement manufacturer, supplying concrete for India's construction industry. It earns money selling cement to builders, government projects, and real estate developers. In 1992, its stock had risen from ₹200 to ₹9,000 — a 4,500% gain — driven entirely by Harshad Mehta's fraudulent bank receipt scheme. The fundamental business hadn't changed. Only the price had, in defiance of all logic.",
        revenue: "₹1,100Cr",
        revenueChange: "+6%",
        profitMargin: "8%",
        debtToEquity: "0.5",
        marketCap: "₹22,000Cr",
        model: [{ label: "Grey Cement", pct: 80 }, { label: "White Cement", pct: 12 }, { label: "RMC", pct: 8 }],
        maxAlloc: 40,
        sectorReturn: -70,
      },
      {
        id: "sbi92",
        name: "State Bank of India",
        sector: "Public Banking",
        founded: 1955,
        description: "SBI is India's largest bank, owned by the government, with deposits from 300 million Indians and loans across every sector. It earns money through interest income on loans to companies and individuals. SBI was one of the major victims of Harshad Mehta's fraud — he used fake bank receipts (BRs) issued in SBI's name to borrow money and drive up stocks. When the scam breaks, SBI's credibility and balance sheet will be devastated.",
        revenue: "₹9,200Cr",
        revenueChange: "+14%",
        profitMargin: "18%",
        debtToEquity: "15.0",
        marketCap: "₹14,000Cr",
        model: [{ label: "Interest Income", pct: 75 }, { label: "Fee Income", pct: 15 }, { label: "Trading", pct: 10 }],
        maxAlloc: 40,
        sectorReturn: -65,
      },
      {
        id: "reliance92",
        name: "Reliance Industries",
        sector: "Conglomerate",
        founded: 1966,
        description: "Reliance Industries had been Harshad Mehta's favourite stock early in the bull run, but by 1992 it had diversified away from the most egregious speculation. Its fundamentals remained strong — growing revenues from petrochemicals and textiles on the back of liberalization. Unlike ACC, Reliance's price appreciation had some earnings support. In the crash, fundamentally sound companies recover faster than fraudulently inflated ones.",
        revenue: "₹7,800Cr",
        revenueChange: "+31%",
        profitMargin: "13%",
        debtToEquity: "0.9",
        marketCap: "₹18,000Cr",
        model: [{ label: "Petrochemicals", pct: 50 }, { label: "Textiles", pct: 30 }, { label: "Trading", pct: 20 }],
        maxAlloc: 40,
        sectorReturn: -30,
      },
      {
        id: "itc92",
        name: "ITC Limited",
        sector: "FMCG & Tobacco",
        founded: 1910,
        description: "ITC is India's largest cigarette company and an emerging conglomerate spanning hotels, paperboards, and food products. It earns money primarily from tobacco — a recession-proof, high-margin business with pricing power. During the Mehta bull run, ITC was relatively ignored by speculators who preferred steel and cement. This actually made it safer — less manipulated, less inflated, with genuine cash generation that provides a cushion in crashes.",
        revenue: "₹3,400Cr",
        revenueChange: "+9%",
        profitMargin: "22%",
        debtToEquity: "0.2",
        marketCap: "₹8,000Cr",
        model: [{ label: "Cigarettes", pct: 70 }, { label: "Hotels", pct: 15 }, { label: "Agribusiness", pct: 15 }],
        maxAlloc: 40,
        sectorReturn: -15,
      },
      {
        id: "drreddy92",
        name: "Dr. Reddy's Laboratories",
        sector: "Pharmaceuticals",
        founded: 1984,
        description: "Dr. Reddy's is a Hyderabad-based generic pharmaceutical company that develops and manufactures affordable medicines for India and global markets. It earns money by selling generic copies of off-patent drugs at a fraction of branded prices. Pharma was almost entirely ignored by the Harshad Mehta speculation — which paradoxically made it one of the safest places to be in April 1992. Real earnings, real products, no manipulation.",
        revenue: "₹360Cr",
        revenueChange: "+38%",
        profitMargin: "17%",
        debtToEquity: "0.3",
        marketCap: "₹1,200Cr",
        model: [{ label: "Generics Export", pct: 60 }, { label: "India Branded", pct: 30 }, { label: "APIs", pct: 10 }],
        maxAlloc: 40,
        sectorReturn: 10,
      },
    ],
    referenceInvestor: "Rakesh Jhunjhunwala",
    referenceQuote: "RJ saw warning signs early and reduced exposure before the crash.",
    benchmark: -40
  },
  {
    id: "2008",
    title: "2008 — THE GREAT COLLAPSE",
    threatLevel: "CRITICAL",
    hook: "Lehman filed. The world froze. Every bank was lying. What did you do?",
    date: "September 15, 2008",
    startingPortfolio: 100000,
    currency: "$",
    brief: "Lehman Brothers filed Chapter 11 with $600 billion in liabilities. Bear Stearns had already fallen. The CDO market was a fiction. Every bank balance sheet was a lie. The world's financial system had 72 hours before ATMs stopped working. What did you do?",
    fearGreed: 5,
    sectors: [
      { name: "Banking", value: -85 },
      { name: "Real Estate", value: -90 },
      { name: "Auto", value: -60 },
      { name: "Tech", value: -40 },
      { name: "Energy", value: -50 },
      { name: "Defense", value: 10 },
      { name: "Gold", value: 30 },
      { name: "Treasuries", value: 25 },
    ],
    news: [
      "LEHMAN BROTHERS FILES FOR BANKRUPTCY",
      "AIG SEEKS $85B EMERGENCY BAILOUT",
      "MONEY MARKET FUNDS 'BREAK THE BUCK'",
      "CONGRESS DEBATES $700B TARP",
      "WARREN BUFFETT INVESTS $5B IN GOLDMAN SACHS",
      "FED CUTS RATES IN EMERGENCY SESSION"
    ],
    companies: [
      {
        id: "gs2008",
        name: "Goldman Sachs",
        sector: "Investment Banking",
        founded: 1869,
        description: "Goldman Sachs is Wall Street's most prestigious investment bank, earning money through trading, investment banking fees, and asset management. In 2007, Goldman actually bet against the mortgage market it was selling to clients — a controversial but prescient move. When Lehman failed, Goldman faced an existential moment: would the market trust it? Buffett's $5B investment in September 2008 provided lifeline credibility, but the stock had already fallen 50%.",
        revenue: "$46B",
        revenueChange: "-43%",
        profitMargin: "18%",
        debtToEquity: "22.0",
        marketCap: "$45B",
        model: [{ label: "Trading", pct: 50 }, { label: "Investment Banking", pct: 30 }, { label: "Asset Mgmt", pct: 20 }],
        maxAlloc: 40,
        sectorReturn: -60,
      },
      {
        id: "citi2008",
        name: "Citigroup",
        sector: "Commercial Banking",
        founded: 1812,
        description: "Citigroup is America's largest bank by assets, with operations in 160 countries. It earns money through consumer deposits, credit cards, mortgages, and investment banking. By September 2008, Citi had $43B in toxic mortgage-backed securities on its balance sheet that it had hidden in off-balance-sheet vehicles. It needed a government bailout of $25B and guarantees on $300B in assets. It was too big to fail, which is not the same as being safe to own.",
        revenue: "$52B",
        revenueChange: "-65%",
        profitMargin: "-31%",
        debtToEquity: "28.0",
        marketCap: "$80B",
        model: [{ label: "Consumer Banking", pct: 45 }, { label: "Cards", pct: 25 }, { label: "Investment Banking", pct: 30 }],
        maxAlloc: 40,
        sectorReturn: -80,
      },
      {
        id: "apple2008",
        name: "Apple Inc.",
        sector: "Technology",
        founded: 1976,
        description: "Apple in 2008 is a company one year removed from launching the iPhone, watching its consumer electronics revolution unfold in real time. It earns money by selling iPhones, Macs, and iPods at premium margins with near-cult customer loyalty. Apple has zero exposure to mortgages, CDOs, or financial instruments. Its balance sheet holds $25B in cash with no debt. In a crisis, cash is king — and Apple is a cash machine with the wind behind it.",
        revenue: "$32B",
        revenueChange: "+35%",
        profitMargin: "19%",
        debtToEquity: "0.0",
        marketCap: "$90B",
        model: [{ label: "iPhone", pct: 45 }, { label: "Mac", pct: 30 }, { label: "iPod & Services", pct: 25 }],
        maxAlloc: 40,
        sectorReturn: -30,
      },
      {
        id: "gold2008",
        name: "SPDR Gold ETF (GLD)",
        sector: "Commodities",
        founded: 2004,
        description: "GLD is an exchange-traded fund that physically holds gold bullion, allowing ordinary investors to own gold without storing it. Gold earns no interest — its value comes from being the world's oldest store of value in times of systemic fear. When paper money and financial institutions are seen as unreliable, capital flees into gold. In 2008, central banks around the world began printing money at historic rates — the exact condition that has historically sent gold higher.",
        revenue: "N/A",
        revenueChange: "N/A",
        profitMargin: "N/A",
        debtToEquity: "N/A",
        marketCap: "$18B AUM",
        model: [{ label: "Gold Bullion", pct: 100 }],
        maxAlloc: 40,
        sectorReturn: 25,
      },
      {
        id: "jnj2008",
        name: "Johnson & Johnson",
        sector: "Healthcare",
        founded: 1886,
        description: "Johnson & Johnson is a diversified healthcare conglomerate selling pharmaceuticals, medical devices, and consumer products like Band-Aid and Tylenol. It earns money from products that people need regardless of economic conditions — cancer drugs, surgical implants, baby powder. J&J has paid a dividend every year since 1944 and increased it for 46 consecutive years by 2008. In financial crises, defensively positioned companies with reliable cashflows become sanctuaries.",
        revenue: "$64B",
        revenueChange: "+4%",
        profitMargin: "20%",
        debtToEquity: "0.2",
        marketCap: "$180B",
        model: [{ label: "Pharmaceuticals", pct: 40 }, { label: "Medical Devices", pct: 35 }, { label: "Consumer", pct: 25 }],
        maxAlloc: 40,
        sectorReturn: -10,
      },
      {
        id: "tbill2008",
        name: "US Treasury Bills",
        sector: "Fixed Income",
        founded: 1776,
        description: "US Treasury Bills are short-term government debt instruments, yielding a fixed rate over 3 to 12 months. In September 2008, investors were so terrified that they briefly accepted negative yields on T-bills — meaning they paid the US government to hold their money. That is the definition of maximum fear. T-bills offer zero credit risk and near-zero return, making them the ultimate defensive position when you believe every other asset is at risk of going to zero.",
        revenue: "N/A",
        revenueChange: "N/A",
        profitMargin: "N/A",
        debtToEquity: "N/A",
        marketCap: "N/A",
        model: [{ label: "Fixed Coupon", pct: 100 }],
        maxAlloc: 40,
        sectorReturn: 20,
      },
    ],
    referenceInvestor: "Warren Buffett",
    referenceQuote: "Buffett deployed $15B at the bottom and earned billions. He was buying when blood was in the streets.",
    benchmark: -37
  },
  {
    id: "2000",
    title: "2000 — DOT-COM COLLAPSE",
    threatLevel: "CRITICAL",
    hook: "The Nasdaq lost 78% in 30 months. Some names survived. Did you know which?",
    date: "March 10, 2000",
    startingPortfolio: 100000,
    currency: "$",
    brief: "The Nasdaq Composite peaked at 5,048 on March 10, 2000. For three years, any internet company with a domain name raised hundreds of millions. Pets.com. Webvan. Boo.com. The collective delusion was that eyeballs were revenue. Now the music has stopped. But hidden inside the wreckage are a handful of companies with actual business models. The question: can you tell the difference before the crash hits bottom?",
    fearGreed: 82,
    sectors: [
      { name: "Internet Retail", value: -95 },
      { name: "Telecom", value: -80 },
      { name: "B2B Software", value: -55 },
      { name: "Infrastructure", value: -40 },
      { name: "E-Commerce Infra", value: -30 },
      { name: "Healthcare IT", value: -20 },
      { name: "Defense", value: 15 },
      { name: "T-Bills", value: 6 },
    ],
    news: [
      "NASDAQ HITS ALL-TIME HIGH OF 5,048",
      "PETS.COM RAISES $82.5M IN IPO",
      "INTERNET COMPANIES COLLECTIVELY BURN $1B A MONTH",
      "WARREN BUFFETT REFUSES TO BUY TECH STOCKS",
      "FEDERAL RESERVE RAISES RATES FOR 6TH TIME",
      "ANALYST UPGRADES 47 DOT-COM STOCKS TO 'BUY'"
    ],
    companies: [
      {
        id: "amazon2000",
        name: "Amazon.com",
        sector: "E-Commerce",
        founded: 1994,
        description: "Amazon is bleeding cash — $1.4B in losses in 1999 — but it sells real products to real people and has a distribution infrastructure that took years to build. Jeff Bezos has been called a fraud and a genius in the same week. The company has $1.6B in revenue but deeply negative margins. The question is whether its cost structure will ever produce a profit, or whether it becomes the cautionary tale of a company that grew too fast to survive.",
        revenue: "$1.6B",
        revenueChange: "+68%",
        profitMargin: "-16%",
        debtToEquity: "4.2",
        marketCap: "$4.8B",
        model: [{ label: "Books", pct: 40 }, { label: "Electronics", pct: 35 }, { label: "Other Retail", pct: 25 }],
        maxAlloc: 40,
        sectorReturn: -30,
      },
      {
        id: "cisco2000",
        name: "Cisco Systems",
        sector: "Infrastructure",
        founded: 1984,
        description: "Cisco makes the routers and switches that run the internet. It's not a dot-com — it sells hardware to the dot-coms. In 2000, it briefly became the most valuable company on Earth at $555B. But its revenue growth depends entirely on telecom companies continuing to build out infrastructure, and those companies borrowed billions to do so. When telecom spending freezes, Cisco will feel it hard and fast.",
        revenue: "$18.9B",
        revenueChange: "+55%",
        profitMargin: "17%",
        debtToEquity: "0.1",
        marketCap: "$400B",
        model: [{ label: "Routers", pct: 45 }, { label: "Switches", pct: 35 }, { label: "Other", pct: 20 }],
        maxAlloc: 40,
        sectorReturn: -40,
      },
      {
        id: "microsoft2000",
        name: "Microsoft",
        sector: "Software",
        founded: 1975,
        description: "Microsoft is not a dot-com. It sells Windows and Office to every business and consumer on Earth. It generates $23B in revenue and $9.4B in profit. The DOJ antitrust case is a cloud overhead. The stock tripled since 1997 and is arguably overvalued. But it has a monopoly on the enterprise desktop, $10B in cash, and zero dependency on venture capital or speculative sentiment.",
        revenue: "$23.0B",
        revenueChange: "+16%",
        profitMargin: "41%",
        debtToEquity: "0.0",
        marketCap: "$580B",
        model: [{ label: "Windows", pct: 35 }, { label: "Office", pct: 40 }, { label: "Server/Other", pct: 25 }],
        maxAlloc: 40,
        sectorReturn: -55,
      },
      {
        id: "webvan2000",
        name: "Webvan",
        sector: "Internet Retail",
        founded: 1996,
        description: "Webvan is trying to reinvent grocery delivery with $375M in VC backing. It plans to build $1B in automated warehouses across 26 cities before it has proven the model in even one. Goldman Sachs took it public in 1999. It is spending $400M building infrastructure for a product that 0.1% of the population uses. George Shaheen — CEO of Andersen Consulting — quit his $5M job to run it. Smart, credentialed people believe in this story deeply.",
        revenue: "$13.3M",
        revenueChange: "+800%",
        profitMargin: "-5000%",
        debtToEquity: "N/A",
        marketCap: "$1.2B",
        model: [{ label: "Grocery Delivery", pct: 100 }],
        maxAlloc: 20,
        sectorReturn: -95,
      },
      {
        id: "tbills2000",
        name: "US Treasury Bonds",
        sector: "Fixed Income",
        founded: 1776,
        description: "10-year US Treasury bonds are yielding 6.8%. The Federal Reserve has raised rates six times since 1999 specifically to cool the speculative frenzy in equities. In a world where stocks trade at 100x revenue with no path to profitability, a risk-free 6.8% return looks increasingly rational. Warren Buffett has held cash and bonds for 3 years and been called an idiot by the press. He is not an idiot.",
        revenue: "N/A",
        revenueChange: "N/A",
        profitMargin: "N/A",
        debtToEquity: "N/A",
        marketCap: "N/A",
        model: [{ label: "Interest Income", pct: 100 }],
        maxAlloc: 60,
        sectorReturn: 6,
      },
    ],
    referenceInvestor: "Warren Buffett",
    referenceQuote: "Buffett held cash when everyone was buying dot-coms. By 2002, he was one of the few large investors with dry powder to deploy. He called it 'not participating in a bubble.'",
    benchmark: -78
  },
  {
    id: "covid-2020",
    title: "2020 — PANDEMIC PANIC",
    threatLevel: "CRITICAL",
    hook: "The fastest bear market in history. 34 trading days. -34%. What did you do?",
    date: "March 16, 2020",
    startingPortfolio: 100000,
    currency: "$",
    brief: "The WHO declared a pandemic on March 11, 2020. The US stock market lost 34% in 33 trading days — the fastest bear market in history. Airlines, hotels, restaurants: shutting down. Oil futures went negative. But somewhere inside this chaos, a new economy was being born: remote work, e-commerce, telemedicine, streaming. The question was not whether to panic. It was whether you could see the future through the noise.",
    fearGreed: 3,
    sectors: [
      { name: "Airlines", value: -70 },
      { name: "Hotels", value: -65 },
      { name: "Energy", value: -55 },
      { name: "Banking", value: -40 },
      { name: "Retail (Physical)", value: -45 },
      { name: "Cloud/SaaS", value: 25 },
      { name: "E-Commerce", value: 40 },
      { name: "Biotech", value: 30 },
    ],
    news: [
      "WHO DECLARES COVID-19 A GLOBAL PANDEMIC",
      "US MARKETS CIRCUIT BREAKER TRIGGERED 4 TIMES IN ONE WEEK",
      "FED CUTS RATES TO ZERO — LAUNCHES UNLIMITED QE",
      "CONGRESS PASSES $2.2T CARES ACT",
      "MODERNA BEGINS PHASE 1 VACCINE TRIALS",
      "OIL FUTURES TURN NEGATIVE FOR FIRST TIME IN HISTORY"
    ],
    companies: [
      {
        id: "zoom2020",
        name: "Zoom Video",
        sector: "Cloud Software",
        founded: 2011,
        description: "Zoom had 10 million daily meeting participants in December 2019. By April 2020 it has 300 million. The entire world is working, learning, and connecting through this one company's software. Revenue is growing 300% year-over-year. The question: is this a permanent shift in how humans work, or a temporary emergency that reverses when offices reopen? The answer determines whether this is a $150 stock or a $50 stock in 2022.",
        revenue: "$623M",
        revenueChange: "+300%",
        profitMargin: "8%",
        debtToEquity: "0.0",
        marketCap: "$48B",
        model: [{ label: "Enterprise Subscription", pct: 82 }, { label: "Self-Service", pct: 18 }],
        maxAlloc: 40,
        sectorReturn: 25,
      },
      {
        id: "moderna2020",
        name: "Moderna",
        sector: "Biotech",
        founded: 2010,
        description: "Moderna has never brought a product to market in 10 years of existence. No approved drug. Negligible revenue. But in January 2020, their team designed a COVID vaccine candidate in exactly 2 days using mRNA technology they've been building for a decade. It is now in Phase 1 trials. If mRNA works in humans at scale, this company is worth $100B+. If the technology fails, the stock approaches zero. The most asymmetric bet in the market.",
        revenue: "$60M",
        revenueChange: "N/A",
        profitMargin: "-500%",
        debtToEquity: "0.3",
        marketCap: "$8B",
        model: [{ label: "Government Grants", pct: 100 }],
        maxAlloc: 20,
        sectorReturn: 30,
      },
      {
        id: "delta2020",
        name: "Delta Airlines",
        sector: "Airlines",
        founded: 1929,
        description: "Delta was the world's most profitable airline entering 2020, with $6.2B in annual profit and a best-in-class balance sheet. Then the world stopped flying. Revenue fell 95% overnight. They are burning $100M a day. They have $6B in cash. The US government is preparing a $25B airline bailout. Delta will almost certainly survive — but it will emerge smaller, more leveraged, and structurally weakened for years. The question is whether the discount is already priced in.",
        revenue: "$47B",
        revenueChange: "-95%",
        profitMargin: "-180%",
        debtToEquity: "8.5",
        marketCap: "$8B",
        model: [{ label: "Passenger Revenue", pct: 85 }, { label: "Cargo", pct: 10 }, { label: "Loyalty Program", pct: 5 }],
        maxAlloc: 30,
        sectorReturn: -70,
      },
      {
        id: "amazon2020",
        name: "Amazon",
        sector: "E-Commerce",
        founded: 1994,
        description: "The world is locked indoors and ordering everything online. Amazon's warehouses are overwhelmed. They are hiring 175,000 workers and still can't keep up. AWS cloud revenue is accelerating because every company is suddenly remote. Jeff Bezos's net worth grew $75B in 2020 alone as the pandemic forced the entire consumer economy onto his platform. This is 10 years of e-commerce adoption compressed into 10 months.",
        revenue: "$380B",
        revenueChange: "+38%",
        profitMargin: "4%",
        debtToEquity: "1.2",
        marketCap: "$1.1T",
        model: [{ label: "E-Commerce", pct: 55 }, { label: "AWS", pct: 30 }, { label: "Advertising", pct: 15 }],
        maxAlloc: 40,
        sectorReturn: 40,
      },
      {
        id: "spy2020",
        name: "S&P 500 Index (SPY)",
        sector: "Diversified",
        founded: 1993,
        description: "The S&P 500 is down 34% from its February 19 peak. The Federal Reserve has cut rates to zero and announced unlimited quantitative easing. Congress is deploying $2.2 trillion in fiscal stimulus. Warren Buffett is sitting on $137B in cash and refusing to buy. History says that broad-index buying at bear market lows — when fear is at maximum — has been the highest expected-value trade over any 5-year horizon in US market history.",
        revenue: "N/A",
        revenueChange: "N/A",
        profitMargin: "N/A",
        debtToEquity: "N/A",
        marketCap: "N/A",
        model: [{ label: "500 US Large Caps", pct: 100 }],
        maxAlloc: 60,
        sectorReturn: 15,
      },
    ],
    referenceInvestor: "Cathie Wood",
    referenceQuote: "Wood deployed aggressively into Zoom, Moderna, and Tesla during the crash. ARK Innovation returned 152% in 2020. She saw the technological acceleration that the pandemic forced.",
    benchmark: -34
  }
];

export const boardroomScenarios = [
  {
    id: "netflix-2011",
    title: "NETFLIX 2011",
    subtitle: "You just split your company in two and lost 800,000 subscribers in a month. The board is watching.",
    company: "NETFLIX",
    badge: "BOARD EYES ONLY",
    stats: [
      { label: "Subscribers", value: "23.8M", prev: "24.6M" },
      { label: "Stock Price", value: "$53", prev: "$298" },
      { label: "Qwikster Age", value: "0 days", prev: "" }
    ],
    crisis: "You just announced Qwikster — splitting streaming and DVDs into two separate services with two separate bills. Customers are furious. 800K subscribers canceled in 30 days. Your stock dropped 75%. The media says you've lost your mind. Netflix's credibility is on trial.",
    revenueTrend: [
      { year: "2007", revenue: 1.2, growth: true },
      { year: "2008", revenue: 1.4, growth: true },
      { year: "2009", revenue: 1.7, growth: true },
      { year: "2010", revenue: 2.2, growth: true },
      { year: "2011", revenue: 3.2, growth: true },
    ],
    marketShare: [
      { name: "Netflix", value: 34 },
      { name: "Hulu", value: 12 },
      { name: "Redbox", value: 18 },
      { name: "Cable VOD", value: 36 },
    ],
    crisisTimeline: [
      { date: "Jan 2011", event: "Netflix raises streaming price 60% for existing DVD+streaming customers" },
      { date: "Apr 2011", event: "Starz negotiations collapse — content library to shrink by 1,000 titles" },
      { date: "Jul 2011", event: "Price hike takes effect; subscriber growth stalls for first time" },
      { date: "Sep 2011", event: "Qwikster announced: streaming and DVD to become separate companies with separate bills" },
      { date: "Oct 2011", event: "800,000 subscribers cancel; stock falls from $298 to $53 in 3 months" },
    ],
    financialPressure: [
      { period: "Q1", subscribers: 23.6, stockPrice: 220 },
      { period: "Q2", subscribers: 26.0, stockPrice: 268 },
      { period: "Q3 Peak", subscribers: 24.6, stockPrice: 298 },
      { period: "Q3 End", subscribers: 23.8, stockPrice: 185 },
      { period: "Q4", subscribers: 24.4, stockPrice: 53 },
    ],
    boardVoices: [
      {
        name: "Reed Hastings",
        title: "CEO",
        avatar: "RH",
        argument: "We moved too fast, I know. But the logic was right: streaming and DVDs are fundamentally different businesses. The market is punishing us now, but we cannot let short-term pain make us abandon long-term vision. The question is how we execute better, not whether the direction was wrong."
      },
      {
        name: "David Wells",
        title: "CFO",
        avatar: "DW",
        argument: "We have $400M in cash and $500M in credit. We are not in danger of failure. But the subscriber losses are accelerating. Every month we delay a decision, we lose 200,000 more customers. I need a number from this board: what is the maximum further drawdown we are willing to accept before we reverse course?"
      },
      {
        name: "Ted Sarandos",
        title: "Chief Content Officer",
        avatar: "TS",
        argument: "The content deals we're signing — House of Cards, Lilyhammer — these only work if subscribers trust that Netflix streaming is a premium destination. Right now, our brand is radioactive. I can't close deals when studios think we're a company in freefall. We need to stabilize the story before we can execute the content strategy."
      }
    ],
    options: [
      {
        id: "A",
        title: "Reverse Qwikster immediately",
        rationale: "Stop the bleeding now. Apologize publicly. Reunify the services. Accept the embarrassment and rebuild trust from zero.",
        risk: "HIGH",
        timeHorizon: "Quick Win",
        xp: 150
      },
      {
        id: "B",
        title: "Stay the course on Qwikster",
        rationale: "The vision is right. Pain is temporary. Every great pivot involves a transitional valley.",
        risk: "EXISTENTIAL",
        timeHorizon: "Decade Play",
        xp: 25
      },
      {
        id: "C",
        title: "Reverse Qwikster, double down on content spending",
        rationale: "Walk back the brand mistake but accelerate the strategic move: own the content, not just the pipe.",
        risk: "HIGH",
        timeHorizon: "2-Year Bet",
        xp: 75
      }
    ],
    outcomeData: [
      { year: "2011 Q4", value: 53 },
      { year: "2012", value: 90 },
      { year: "2013", value: 360 },
      { year: "2014", value: 340 },
      { year: "2015", value: 650 },
    ],
    outcomePositive: true,
    whatIf: [
      {
        option: "B — Stay the course",
        outcome: "Qwikster would have launched with 12M subscribers and collapsed within 6 months. Netflix would have needed emergency financing. The streaming vision was correct; the execution would have been fatal. Netflix likely gets acquired by Amazon in 2013 at a fire-sale price."
      },
      {
        option: "C — Reverse + content bet",
        outcome: "This is what actually happened. Reed reversed Qwikster in 23 days, called it moving too fast, and began the content spending spree that produced House of Cards in 2013. The stock recovered to $400 by 2013 and 10x'd by 2015."
      }
    ],
    verdictA: "You chose the humble path. Reed's actual decision — the one Netflix became famous for. Speed of course-correction beat the pride of consistency.",
    verdictB: "You held conviction over customer signal. In startups, this is sometimes genius. In a public company with 25M angry subscribers, it is usually a slower form of the same failure.",
    verdictC: "You combined the tactical retreat with the strategic leap. This is exactly what Reed Hastings did. The reversal bought time; the content bet bought the future.",
    verdict: "Reed reversed Qwikster 23 days later. Called it 'moving too fast.' Netflix streaming became the dominant product. Stock recovered and 10x'd in 5 years. Lesson: Speed of course-correction matters more than never being wrong.",
    chartData: [
      { name: "Jan", sub: 22.0, stock: 180 },
      { name: "Mar", sub: 23.4, stock: 240 },
      { name: "Jun", sub: 24.6, stock: 298 },
      { name: "Sep", sub: 23.8, stock: 185 },
      { name: "Dec", sub: 22.8, stock: 53 }
    ],
    stakeholders: [
      { name: "Reed Hastings", role: "CEO", position: "committed", type: "neutral" },
      { name: "The Board", role: "Directors", position: "skeptical", type: "hostile" },
      { name: "Subscribers", role: "Customers", position: "furious", type: "hostile" },
      { name: "Tech Team", role: "Engineering", position: "supportive", type: "supportive" },
      { name: "Wall Street", role: "Investors", position: "hostile", type: "hostile" }
    ],
  },
  {
    id: "amazon-2003",
    title: "AMAZON 2003",
    subtitle: "AWS is an internal tool. Your engineers say open it to the world. The CFO says it's a distraction.",
    company: "AMAZON",
    badge: "CLASSIFIED",
    stats: [
      { label: "Revenue", value: "$5.3B", prev: "$3.9B" },
      { label: "AWS Status", value: "INTERNAL", prev: "" },
      { label: "Server Costs", value: "$150M/yr", prev: "" }
    ],
    crisis: "Your internal infrastructure team has built a set of web services to manage Amazon's own servers. It's reliable, scalable, and elegant. A group of engineers wants to open it to the world as a public cloud platform. Your CFO says it distracts from retail. Your CTO says it's the future of computing. You have to decide.",
    revenueTrend: [
      { year: "1999", revenue: 1.6, growth: true },
      { year: "2000", revenue: 2.7, growth: true },
      { year: "2001", revenue: 3.1, growth: true },
      { year: "2002", revenue: 3.9, growth: true },
      { year: "2003", revenue: 5.3, growth: true },
    ],
    marketShare: [
      { name: "Amazon", value: 14 },
      { name: "eBay", value: 25 },
      { name: "Walmart.com", value: 8 },
      { name: "Traditional Retail", value: 53 },
    ],
    crisisTimeline: [
      { date: "2000", event: "Dot-com crash; Amazon stock falls 93%; Jeff Bezos doubles down on logistics" },
      { date: "2002", event: "Amazon builds internal compute infrastructure to handle holiday traffic spikes" },
      { date: "Mar 2003", event: "Engineering team completes modular web services stack — S3 and EC2 prototypes ready" },
      { date: "Jul 2003", event: "Andy Jassy presents internal pitch: open this infrastructure to external developers" },
      { date: "Oct 2003", event: "Board meeting: CFO pushes back. Board must decide: stay retail-focused or bet on cloud" },
    ],
    financialPressure: [
      { period: "1999", revenue: 1.6, serverCost: 25 },
      { period: "2000", revenue: 2.7, serverCost: 60 },
      { period: "2001", revenue: 3.1, serverCost: 80 },
      { period: "2002", revenue: 3.9, serverCost: 110 },
      { period: "2003", revenue: 5.3, serverCost: 150 },
    ],
    boardVoices: [
      {
        name: "Jeff Bezos",
        title: "CEO & Founder",
        avatar: "JB",
        argument: "Every company in the world needs reliable computing. We've built the infrastructure to handle our own scale. The question isn't whether the world needs cloud computing — it does. The question is whether we have the conviction to be the ones who build it. I think we do."
      },
      {
        name: "Tom Szkutak",
        title: "CFO",
        avatar: "TS",
        argument: "Our margins in retail are already thin. We are still in debt from the dot-com era expansion. Launching a cloud platform means capital expenditure we cannot model, support costs we cannot predict, and a business model we don't understand. We're a retailer. We should focus on being the best retailer in the world."
      },
      {
        name: "Andy Jassy",
        title: "VP Engineering",
        avatar: "AJ",
        argument: "Every startup in the world will need this. Every developer building the next Amazon will need this. The marginal cost of adding a new customer is almost zero. We've already spent the money building it — we're just deciding whether to let it generate revenue or let it sit idle. This is a $100B opportunity and we're the only ones positioned to take it."
      }
    ],
    options: [
      {
        id: "A",
        title: "Launch AWS publicly",
        rationale: "Open the infrastructure to the world as a platform. Price it to undercut traditional enterprise IT. Build the cloud computing market before anyone else can.",
        risk: "HIGH",
        timeHorizon: "Decade Play",
        xp: 150
      },
      {
        id: "B",
        title: "Keep it internal only",
        rationale: "Stay focused on retail dominance. The infrastructure serves Amazon. Let others build cloud; we'll use what we build.",
        risk: "LOW",
        timeHorizon: "Quick Win",
        xp: 25
      },
      {
        id: "C",
        title: "Sell to an enterprise partner",
        rationale: "Monetize the technology through a licensing deal with IBM or Microsoft. Get immediate cash without the distraction of running a platform business.",
        risk: "MEDIUM",
        timeHorizon: "2-Year Bet",
        xp: 75
      }
    ],
    outcomeData: [
      { year: "2006", value: 0.1 },
      { year: "2008", value: 1.1 },
      { year: "2010", value: 2.7 },
      { year: "2013", value: 9.0 },
      { year: "2016", value: 31.0 },
    ],
    outcomePositive: true,
    whatIf: [
      {
        option: "B — Keep it internal",
        outcome: "Microsoft Azure launches in 2010, Google Cloud in 2011. Amazon's internal tools remain proprietary. By 2015, Amazon is the world's largest retailer — but cloud computing is a $200B market it does not participate in. AWS's actual 2023 revenue of $90B simply does not exist."
      },
      {
        option: "C — Sell to enterprise partner",
        outcome: "IBM or Microsoft gets a crucial 3-year head start in cloud computing. They likely dominate the enterprise market. Amazon gets $2-3B in licensing fees. A decade of missed compounding: $90B/year in AWS revenue gone forever."
      }
    ],
    verdictA: "You saw what Andy Jassy saw. AWS launched in 2006 and by 2023 generated $90B/yr — more profit than all of Amazon Retail. The CFO was wrong. First mover advantage in cloud was decisive.",
    verdictB: "You chose retail focus. Amazon would still be the world's largest retailer — but it would be a fundamentally different, smaller company. Sometimes the safe choice has a trillion-dollar opportunity cost.",
    verdictC: "You monetized without believing. The licensing deal would have generated early cash while handing a category-defining technology to a competitor. Strategic optionality sold at a discount is rarely a good trade.",
    verdict: "AWS launched publicly in 2006. By 2023, AWS generated $90B in revenue — more profitable than all of Amazon Retail. The CFO was wrong. First mover advantage in cloud was decisive. Lesson: Platform bets require believing in a world that doesn't exist yet.",
    chartData: [
      { name: "1999", rev: 1.6 },
      { name: "2000", rev: 2.7 },
      { name: "2001", rev: 3.1 },
      { name: "2002", rev: 3.9 },
      { name: "2003", rev: 5.3 }
    ],
    stakeholders: [
      { name: "Jeff Bezos", role: "CEO", position: "visionary", type: "neutral" },
      { name: "CFO", role: "Finance", position: "skeptical", type: "hostile" },
      { name: "Engineering", role: "Tech", position: "excited", type: "supportive" },
      { name: "Retail Division", role: "Core Biz", position: "worried", type: "hostile" },
      { name: "Investors", role: "Wall Street", position: "cautious", type: "neutral" }
    ],
  },
  {
    id: "infosys-1999",
    title: "INFOSYS 1999",
    subtitle: "Y2K is printing money but it ends in 12 months. Do you bet the company on what comes next?",
    company: "INFOSYS",
    badge: "CLASSIFIED",
    stats: [
      { label: "Revenue", value: "₹933Cr", prev: "₹604Cr" },
      { label: "Y2K Share", value: "45%", prev: "20%" },
      { label: "Employees", value: "15,356", prev: "10,000" }
    ],
    crisis: "Y2K consulting is printing money. Every corporation in the world needs Indian engineers to fix their COBOL date bugs before January 1, 2000. But Y2K ends in exactly 12 months. Your revenues will cliff. Do you use this cash-rich moment to bet on the next platform — internet infrastructure, ERP, or do you milk the Y2K cycle and hope for a soft landing?",
    revenueTrend: [
      { year: "1995", revenue: 121, growth: true },
      { year: "1996", revenue: 195, growth: true },
      { year: "1997", revenue: 356, growth: true },
      { year: "1998", revenue: 604, growth: true },
      { year: "1999", revenue: 933, growth: true },
    ],
    marketShare: [
      { name: "Infosys", value: 18 },
      { name: "TCS", value: 32 },
      { name: "Wipro", value: 16 },
      { name: "Other IT", value: 34 },
    ],
    crisisTimeline: [
      { date: "1997", event: "Y2K consulting becomes Infosys's fastest growing practice — revenue doubles" },
      { date: "Jan 1999", event: "Y2K revenues now 45% of total — dangerous concentration in a 12-month runway business" },
      { date: "Apr 1999", event: "SAP and Oracle announce aggressive India push — ERP market about to be contested" },
      { date: "Aug 1999", event: "Internal strategy session: three bets proposed for post-Y2K era" },
      { date: "Dec 1999", event: "Final call required before Y2K cliff arrives and the cash advantage begins to erode" },
    ],
    financialPressure: [
      { period: "1997", revenue: 356, y2kRevenue: 45 },
      { period: "1998", revenue: 604, y2kRevenue: 140 },
      { period: "1999 H1", revenue: 520, y2kRevenue: 230 },
      { period: "1999 H2", revenue: 413, y2kRevenue: 210 },
      { period: "2000 (proj)", revenue: 350, y2kRevenue: 0 },
    ],
    boardVoices: [
      {
        name: "Narayana Murthy",
        title: "Founder & CEO",
        avatar: "NM",
        argument: "We have earned the trust of Fortune 500 companies. That trust is the asset — not the Y2K code itself. The question is: what problem does the Fortune 500 have after Y2K? The answer is ERP integration. SAP is the operating system of the global enterprise. We need to be the implementation partner of choice before TCS gets there."
      },
      {
        name: "Nandan Nilekani",
        title: "Managing Director",
        avatar: "NN",
        argument: "Retraining 15,000 engineers takes 18 months minimum. We will bleed margin during the transition. My concern is the timing — we can't afford to hire expensive SAP talent and fund the retrain while Y2K revenues fall off simultaneously. We need to sequence this carefully. Revenue first, then capability."
      },
      {
        name: "Phaneesh Murthy",
        title: "VP Sales",
        avatar: "PM",
        argument: "I've spoken to 40 CIOs in the last quarter. Every single one of them has the same fear after Y2K: their ERP implementation is broken or incomplete. They trust Indian IT engineers to fix things quickly. We have a 6-month window before the big four consulting firms absorb this market. If we don't move now, we don't get another shot."
      }
    ],
    options: [
      {
        id: "A",
        title: "Bet heavily on SAP/ERP",
        rationale: "Use Y2K cash reserves to retrain engineers, acquire SAP certification, and position as the world's largest ERP implementation partner within 24 months.",
        risk: "HIGH",
        timeHorizon: "2-Year Bet",
        xp: 150
      },
      {
        id: "B",
        title: "Build IP-based software products",
        rationale: "The next phase of Indian IT must be products, not services. Use cash reserves to build proprietary software platforms for banking and insurance.",
        risk: "EXISTENTIAL",
        timeHorizon: "Decade Play",
        xp: 75
      },
      {
        id: "C",
        title: "Diversify geographically",
        rationale: "Open offices in Europe, Japan, and Australia to reduce US dependency and find new Y2K-style opportunities across markets.",
        risk: "MEDIUM",
        timeHorizon: "2-Year Bet",
        xp: 25
      }
    ],
    outcomeData: [
      { year: "2000", value: 882 },
      { year: "2001", value: 1959 },
      { year: "2002", value: 2604 },
      { year: "2004", value: 4761 },
      { year: "2006", value: 9028 },
    ],
    outcomePositive: true,
    whatIf: [
      {
        option: "B — Build IP products",
        outcome: "India did not have product management DNA in 1999. The talent gap was 10 years wide. Infosys's product bets would have been underfunded, under-marketed, and out-competed by US firms. The services business would have been neglected during the pivot, causing double damage. Indian IT product success had to wait for Freshworks in 2010."
      },
      {
        option: "C — Geographic diversification",
        outcome: "This would have been the safest option with the lowest upside. New geographies need 3-5 years to generate meaningful revenue. TCS and Wipro aggressively took the ERP space that Infosys left uncontested. By 2005, the ERP market would have been locked in — and Infosys would be a smaller, regionally diverse, strategically adrift company."
      }
    ],
    verdictA: "You saw the transition moment and used the cash advantage to own it. Infosys's ERP pivot was executed with clinical precision. Revenue grew 10x in 5 years. The Y2K cliff landed soft because the next platform was already contracted.",
    verdictB: "You bet on a product future that India wasn't ready for. The vision was correct — Indian product companies do emerge — but in 2000, the infrastructure, talent density, and go-to-market didn't exist. A decade too early is effectively wrong.",
    verdictC: "You bought safety by buying optionality. Geographic diversification works slowly. TCS took the ERP market. Infosys became smaller and less differentiated. Safe choices at inflection points carry invisible opportunity costs.",
    verdict: "Infosys pivoted aggressively into ERP (SAP, Oracle) and became a global enterprise services giant. The Y2K cliff was real but the pivot worked. Revenue grew 10x in 5 years. Lesson: Use a cash-rich moment to place the bet that only cash can afford.",
    chartData: [
      { name: "1995", rev: 121 },
      { name: "1996", rev: 195 },
      { name: "1997", rev: 356 },
      { name: "1998", rev: 604 },
      { name: "1999", rev: 933 }
    ],
    stakeholders: [
      { name: "Narayana Murthy", role: "Founder", position: "visionary", type: "supportive" },
      { name: "Nandan Nilekani", role: "CFO", position: "cautious", type: "neutral" },
      { name: "Clients", role: "Customers", position: "Y2K dependent", type: "hostile" },
      { name: "Employees", role: "Staff", position: "anxious", type: "neutral" },
      { name: "Wipro/TCS", role: "Competition", position: "moving fast", type: "hostile" }
    ],
  },
  {
    id: "zomato-2021",
    title: "ZOMATO 2021",
    subtitle: "Blinkit is burning ₹400Cr a month. Deepinder wants to acquire it. The Street thinks he's lost his mind.",
    company: "ZOMATO",
    badge: "BOARD EYES ONLY",
    stats: [
      { label: "Market Cap", value: "₹68K Cr", prev: "IPO" },
      { label: "Blinkit Burn", value: "₹400Cr/mo", prev: "Rising" },
      { label: "GMV", value: "₹12K Cr", prev: "" }
    ],
    crisis: "You just went public at ₹76 per share. Blinkit (formerly Grofers) is burning ₹400Cr a month and needs a lifeline. Deepinder Goyal wants to acquire it for ₹4,447Cr. Analysts say you're buying a sinking ship. The Street is furious. Shareholders are threatening revolt. But Deepinder sees 10-minute grocery delivery as the next moat. Who is right?",
    revenueTrend: [
      { year: "2018", revenue: 466, growth: true },
      { year: "2019", revenue: 1313, growth: true },
      { year: "2020", revenue: 2605, growth: true },
      { year: "2021", revenue: 1994, growth: false },
      { year: "2022", revenue: 4192, growth: true },
    ],
    marketShare: [
      { name: "Zomato", value: 45 },
      { name: "Swiggy", value: 42 },
      { name: "Dunzo", value: 7 },
      { name: "Others", value: 6 },
    ],
    crisisTimeline: [
      { date: "Jul 2021", event: "Zomato IPO at ₹76/share; stock surges 66% on listing day" },
      { date: "Oct 2021", event: "Blinkit pivot from grocery delivery to 10-minute delivery — cash burn accelerates" },
      { date: "Jan 2022", event: "Swiggy Instamart aggressively expanding in 25 cities; quick commerce race heats up" },
      { date: "Mar 2022", event: "Blinkit needs emergency funding or will shut down within 90 days" },
      { date: "Jun 2022", event: "Deepinder proposes ₹4,447Cr Blinkit acquisition; board must decide before competitors move" },
    ],
    financialPressure: [
      { period: "Q1 2022", revenue: 1001, burn: 1350 },
      { period: "Q2 2022", revenue: 1414, burn: 1500 },
      { period: "Q3 2022", revenue: 1756, burn: 1400 },
      { period: "Q4 2022", revenue: 2056, burn: 1200 },
      { period: "Q1 2023", revenue: 2056, burn: 900 },
    ],
    boardVoices: [
      {
        name: "Deepinder Goyal",
        title: "CEO & Founder",
        avatar: "DG",
        argument: "Groceries are bought 4x more frequently than restaurant food. The customer who uses Blinkit orders 25 times a month. The customer who uses Zomato orders 6 times. Quick commerce is the higher frequency product — and whoever owns frequency owns the consumer relationship. Swiggy Instamart is moving fast. If we don't buy Blinkit today, we will spend 3x building it from scratch in two years."
      },
      {
        name: "Akshant Goyal",
        title: "CFO",
        avatar: "AG",
        argument: "We are 14 months post-IPO and still not profitable on food delivery. Our shareholders bought a food delivery story. We are now proposing to acquire a quick commerce company burning ₹400Cr a month that has never been profitable in five years of operation. The risk is not just financial — it's credibility risk. If this fails, Deepinder cannot raise capital again."
      },
      {
        name: "SoftBank Representative",
        title: "Board Observer",
        avatar: "SB",
        argument: "We've seen this pattern in Korea with Coupang, in Turkey with Getir, in Germany with Gorillas. The quick commerce category produces one winner. The capital burn phase is always ugly. But the survivor captures 80% of the market. The question is not whether to play — it is whether Zomato has the balance sheet to survive long enough to win."
      }
    ],
    options: [
      {
        id: "A",
        title: "Acquire Blinkit now",
        rationale: "Pay ₹4,447Cr for the category leader in quick commerce before Swiggy locks in dominance. Accept short-term pain for long-term monopoly.",
        risk: "EXISTENTIAL",
        timeHorizon: "Decade Play",
        xp: 150
      },
      {
        id: "B",
        title: "Walk away, focus on profitability",
        rationale: "Preserve food delivery margins, satisfy existing shareholders, and let quick commerce play out before committing capital.",
        risk: "LOW",
        timeHorizon: "Quick Win",
        xp: 25
      },
      {
        id: "C",
        title: "Negotiate a structured JV instead",
        rationale: "Acquire 49% for ₹2,200Cr. Get board control without full liability. Evaluate for 12 months before full acquisition.",
        risk: "MEDIUM",
        timeHorizon: "2-Year Bet",
        xp: 75
      }
    ],
    outcomeData: [
      { year: "2022 Q3", value: 40 },
      { year: "2023 Q1", value: 55 },
      { year: "2023 Q3", value: 100 },
      { year: "2024 Q1", value: 180 },
      { year: "2024 Q3", value: 260 },
    ],
    outcomePositive: true,
    whatIf: [
      {
        option: "B — Walk away",
        outcome: "Swiggy Instamart, already in 25 cities, would have secured exclusive dark store deals in every major metro within 18 months. Zomato would have had to build its own quick commerce from zero — at 3x the cost and with 2-year market lag. Blinkit's customer data and operational playbook would have gone to a competitor. Zomato stock likely stays below ₹80 through 2024."
      },
      {
        option: "C — Structured JV",
        outcome: "Blinkit needed emergency capital, not a 12-month evaluation period. The JV structure would have given Swiggy time to lock up dark store locations. More critically: half-ownership means half-commitment in operations. Quick commerce requires absolute operational focus. A JV would have given Zomato the liability without the control."
      }
    ],
    verdictA: "You saw the category before the category was proven. Zomato acquired Blinkit in 2022. By 2024, Blinkit's GOV exceeded food delivery. The stock went from ₹40 to ₹260. Deepinder was right — and so were you.",
    verdictB: "You chose the investor-friendly answer. Protecting food delivery margins was the rational, defensible call. The problem: category leadership in quick commerce was permanently surrendered. Swiggy Instamart would have owned the next decade.",
    verdictC: "You tried to have it both ways. In winner-take-all markets, half-measures are expensive. The JV structure would have consumed management bandwidth while delivering neither operational control nor capital efficiency.",
    verdict: "Zomato acquired Blinkit in 2022 for ₹4,447Cr. By 2024, Blinkit became Zomato's fastest growing business. Stock recovered to ₹250+. Deepinder was right. Lesson: Conviction in a category that hasn't been proven requires tolerance for present-day losses.",
    chartData: [
      { name: "Jan", burn: 380, stock: 128 },
      { name: "Feb", burn: 420, stock: 115 },
      { name: "Mar", burn: 400, stock: 98 },
      { name: "Apr", burn: 450, stock: 75 },
      { name: "May", burn: 430, stock: 60 },
      { name: "Jun", burn: 400, stock: 55 }
    ],
    stakeholders: [
      { name: "Deepinder Goyal", role: "CEO", position: "committed", type: "supportive" },
      { name: "Inst. Investors", role: "Wall Street", position: "hostile", type: "hostile" },
      { name: "Albinder Dhindsa", role: "Blinkit CEO", position: "desperate", type: "neutral" },
      { name: "Analysts", role: "Market", position: "skeptical", type: "hostile" },
      { name: "SoftBank", role: "Investor", position: "cautious", type: "neutral" }
    ],
  },
  {
    id: "twitter-2022",
    title: "TWITTER 2022",
    subtitle: "Elon made a $44B offer you accepted. Now he wants out. Do you sue or negotiate?",
    company: "TWITTER",
    badge: "BOARD EYES ONLY",
    stats: [
      { label: "Offer Price", value: "$54.20/sh", prev: "Market: $38" },
      { label: "Company Revenue", value: "$5.1B", prev: "$3.7B" },
      { label: "Monetizable DAU", value: "238M", prev: "211M" }
    ],
    crisis: "It is July 2022. Elon Musk offered $54.20 per share — a 38% premium — to buy Twitter in April. The board accepted in 4 days. Now Musk is citing 'bot account concerns' to exit. He has tweeted deal criticism 18 times. His lawyers sent a formal termination letter. Your outside counsel says you have a strong case under Delaware law — the Material Adverse Change clause almost certainly does not apply. But suing one of the world's most powerful men means 18 months of litigation and stock parked at $32. The alternative is renegotiating to a lower price. The board's fiduciary duty is clear. What it demands is less so.",
    role: "BOARD CHAIR",
    objectives: ["Maximize shareholder value", "Minimize litigation uncertainty", "Execute fiduciary duty"],
    advisors: [
      { name: "Goldman Sachs (Financial)", opinion: "File suit. You win in Delaware. Force the $54.20." },
      { name: "Wilson Sonsini (Legal)", opinion: "Strong case but 18 months of pain. Consider renegotiating to $50-52." },
      { name: "Largest Institutional Holder", opinion: "We want the deal closed. Any price above $48 works. Don't let this drag into 2023." }
    ],
    choices: [
      {
        id: "sue",
        label: "SUE FOR $54.20",
        description: "File in Delaware Chancery Court for specific performance. Enforce the contract to the letter.",
        risk: "HIGH",
        rationale: "Delaware law strongly favors specific performance in signed merger agreements. Musk's public statements hurt his own case. Win probability: 65-70%. But litigation lasts 18 months and stock stays depressed throughout."
      },
      {
        id: "renegotiate",
        label: "RENEGOTIATE AT $51",
        description: "Open a backchannel. Accept a $3/share haircut to close the deal quickly and with certainty.",
        risk: "MEDIUM",
        rationale: "Shareholders get certainty and prompt payment. Deal closes in 30 days. But you're voluntarily surrendering $690M in value that was contractually owed — and shareholders may sue the board for it."
      },
      {
        id: "auction",
        label: "USE BREACH TO TRIGGER COMPETING BIDS",
        description: "Use Musk's announced withdrawal as leverage to run a formal auction process.",
        risk: "HIGH",
        rationale: "At Twitter's revenue multiples, there may be no other credible $44B buyer. Microsoft and Apple are unlikely at this scale. If no competing bid materializes, Twitter stock falls to $25 and the auction signals desperation."
      }
    ],
    verdict: {
      sue: "You file in Delaware. Judge Kathaleen McCormick sets an expedited October trial date. As discovery proceeds, Musk's legal arguments deteriorate — internal messages show he wanted out because Tesla stock fell 40% and he needed to unwind margin loans. Facing near-certain loss, he agrees to close at $54.20 on October 27. Shareholders receive the contractual price. The board delivered $3.2B in incremental value over renegotiation through legal courage.",
      renegotiate: "The renegotiation closes at $51.50. Deal closes October 15. Shareholders receive prompt payment with certainty. But three institutional investors file a derivative suit against the board for accepting below contract without litigating. The suit settles for $42M. The $51.50 was arguably commercially reasonable — but the optics of capitulating without a fight define the board's legacy.",
      auction: "No competing bid emerges at scale. Microsoft's board declines. Apple leaks through advisors they will not do social media at any price. The auction signals desperation. Musk's lawyers use the process as evidence Twitter has constructively accepted the contract termination. You end up in a weaker negotiating position and settle at $48.50 — lower than a direct renegotiation would have achieved."
    },
    stakeholders: [
      { name: "Elon Musk", role: "Acquirer", position: "exiting", type: "hostile" },
      { name: "Institutional Shareholders", role: "Investors", position: "impatient", type: "neutral" },
      { name: "Delaware Court", role: "Legal", position: "neutral", type: "neutral" },
      { name: "Twitter Management", role: "Internal", position: "uncertain", type: "neutral" },
      { name: "SEC", role: "Regulator", position: "watching", type: "neutral" }
    ],
  },
  {
    id: "byju-2023",
    title: "BYJU'S 2023",
    subtitle: "Auditors resigned. $553M is missing. You're the new CFO. Fight, fix, or flee?",
    company: "BYJU'S",
    badge: "CLASSIFIED",
    stats: [
      { label: "Peak Valuation", value: "$22B", prev: "2021" },
      { label: "Current Est. Value", value: "~$1B", prev: "Collapsing" },
      { label: "Unlocated Funds", value: "$553M", prev: "US Term Loan" }
    ],
    crisis: "It is January 2023. You have just been appointed CFO of Byju's — the world's most valuable edtech company at its 2021 peak of $22B. What you've found in week one: Deloitte has resigned as auditor citing inability to obtain sufficient information. FY22 financials — due September 2021 — still haven't been filed. A $1.2B US term loan has $553M that cannot be located in any subsidiary's accounts. The founder insists everything is fine. Three board members — from Prosus, Peak XV, and Chan-Zuckerberg Initiative — have already resigned. A US lender just filed suit for repayment. You have the title of CFO. You do not yet have the full picture. What is your first move?",
    role: "INCOMING CFO",
    objectives: ["Locate and account for the $553M", "File overdue financial statements", "Prevent insolvency while preserving value"],
    advisors: [
      { name: "Founder/CEO (Byju Raveendran)", opinion: "The funds are in a Florida subsidiary for strategic acquisitions. Everything is fine. File nothing that gives lenders legal leverage over us." },
      { name: "Remaining Board Members", opinion: "We need audited financials immediately or we face NCLT proceedings. Cooperate with lenders now." },
      { name: "US Lender's Counsel", opinion: "Cooperate fully and we'll grant 90 days. Don't cooperate and we accelerate the full $1.2B immediately." }
    ],
    choices: [
      {
        id: "cooperate",
        label: "FULL COOPERATION WITH LENDERS",
        description: "Locate and disclose the $553M. Engage a new auditor immediately. File overdue financials and accept lender oversight.",
        risk: "HIGH (PERSONALLY)",
        rationale: "Transparency may save the company but exposes the full extent of governance failure under the founder. He will resist. Your position may be terminated. But it is the only path that keeps the company alive long enough to restructure."
      },
      {
        id: "stall",
        label: "NEGOTIATE 6 MONTHS — FILE NOTHING YET",
        description: "Buy time from lenders through private negotiation. Use the runway to restructure quietly.",
        risk: "HIGH",
        rationale: "Preserves optionality and the founder's goodwill. But deepens the regulatory exposure. NCLT insolvency proceedings can be triggered by any creditor at any time during a stall."
      },
      {
        id: "resign",
        label: "RESIGN AFTER WEEK ONE",
        description: "You've seen enough. Walk away before this becomes personal liability.",
        risk: "LOW (PERSONALLY)",
        rationale: "The cleanest self-preservation option. Protects your professional reputation and personal finances. But your departure accelerates the company's collapse and may itself constitute abandonment of fiduciary duty under Indian company law."
      }
    ],
    verdict: {
      cooperate: "You force disclosure over the founder's explicit objection. The $553M is found — transferred to a Florida subsidiary for an acquisition that never closed and never disclosed. Lenders grant 90 days. A new audit firm is engaged. FY22 financials are filed in March 2023, showing a ₹8,245Cr loss. The company is crippled by the disclosure but survives as a smaller, restructured business. Your personal integrity is intact. The founder never speaks to you again.",
      stall: "Lenders interpret the stall as bad faith. They accelerate the full $1.2B. NCLT proceedings begin in April 2023. Byju's enters formal insolvency. Assets are sold in pieces — WhiteHat Jr goes to an Indian PE fund for ₹400Cr, a fraction of its ₹2,800Cr acquisition price. You are named in regulatory proceedings for the delayed filings that occurred during your tenure. The stall bought nothing.",
      resign: "You resign after 11 days. It is the fastest CFO exit in Indian startup history and is reported across every business outlet. Byju's stock on secondary markets falls another 40% on the news. The collapse accelerates. NCLT proceedings begin 3 months later. Your resignation protected you personally — but it did not prevent the outcome. It accelerated it, and your name is permanently attached to the chapter that ended Byju's as a going concern."
    },
    stakeholders: [
      { name: "Byju Raveendran", role: "Founder/CEO", position: "resistant", type: "hostile" },
      { name: "US Term Lenders", role: "Creditors", position: "aggressive", type: "hostile" },
      { name: "NCLT / Regulators", role: "Legal", position: "watching", type: "neutral" },
      { name: "Remaining Board", role: "Governance", position: "anxious", type: "supportive" },
      { name: "8,000 Employees", role: "Internal", position: "uncertain", type: "neutral" }
    ],
  }
];

export const problemRoomScenarios = [
  {
    id: "kova-foods",
    title: "KOVA FOODS",
    subtitle: "A D2C snack empire or an FMCG acquisition target?",
    category: "M&A · Consumer · India",
    overview: "Kova Foods is a direct-to-consumer healthy snack brand founded in 2019, selling makhana chips, seed bars, and protein laddoos to urban Indian millennials through Instagram, their own website, and Zepto. In four years they've built something rare in Indian FMCG: a brand with genuine repeat purchase loyalty and a 4.8-star average across 12,000 reviews.",
    overview2: "Revenue is ₹80 crore and growing at 60% year-on-year. But the unit economics have a problem: they're burning ₹2 crore per month to fund the growth — marketing, warehousing, and the cost of building their own supply chain. The founder, Shreya Kapoor, has been offered ₹320 crore (4x revenue) by a large FMCG conglomerate that wants the brand, the supply chain, and Shreya's team. The investors want an exit. Shreya wants to build a ₹1,000 crore brand independently.",
    financials: [
      { label: "Annual Revenue", value: "₹80Cr", change: "+60% YoY" },
      { label: "Monthly Burn", value: "₹2Cr", change: "Rising" },
      { label: "Gross Margin", value: "62%", change: "+4pp" },
      { label: "Runway", value: "14 months", change: "Tightening" },
    ],
    problem: "Shreya has 90 days to respond to the acquisition offer. Her lead investor, a Mumbai-based VC, has made clear they support the exit. Two of her three co-founders want the money. The acquirer is offering a 2-year earnout structure where Shreya leads the brand post-acquisition with full creative control. The alternative: raise a Series B, extend runway, and aim for ₹200Cr revenue in 2 years. What do you advise?",
    decisions: [
      {
        id: "A",
        title: "Accept the acquisition",
        rationale: "₹320Cr is a life-changing outcome. The earnout preserves creative control. Brand survival is not guaranteed independently.",
        risk: 20,
        reward: 55,
        riskLabel: "LOW",
        rewardLabel: "CERTAIN"
      },
      {
        id: "B",
        title: "Raise Series B and stay independent",
        rationale: "60% YoY growth is fundable. Indian D2C is a generational opportunity. Shreya is the moat, not the product.",
        risk: 70,
        reward: 90,
        riskLabel: "HIGH",
        rewardLabel: "ASYMMETRIC"
      },
      {
        id: "C",
        title: "Negotiate a strategic minority investment",
        rationale: "Take ₹50Cr from the FMCG conglomerate for 20% stake. Get distribution without giving up control. Buy time to reach ₹150Cr revenue.",
        risk: 45,
        reward: 70,
        riskLabel: "MEDIUM",
        rewardLabel: "BALANCED"
      },
      {
        id: "D",
        title: "Reject everything and cut burn",
        rationale: "Reduce marketing spend. Extend runway by 18 months. Reach breakeven on existing revenue. Negotiate from strength later.",
        risk: 35,
        reward: 40,
        riskLabel: "LOW-MEDIUM",
        rewardLabel: "MODEST"
      }
    ],
    consequences: {
      A: [
        "Kova launches in 8,000 modern trade outlets within 6 months. Revenue hits ₹200Cr in year 2 — but 70% is retailer-driven, not D2C. The brand begins to look like every other FMCG snack brand.",
        "Shreya stays for 18 months, leaves after creative differences. The acquirer restructures the product line. The 4.8-star community becomes a 3.9-star mass-market brand. The acquisition was a financial success, a brand tragedy.",
        "The investor returns 4x. The co-founders get liquidity. Shreya gets ₹64Cr personal payout and uses it to start a VC fund focused on women-led consumer brands. The story becomes a case study in what India builds next."
      ],
      B: [
        "Series B closes at ₹150Cr valuation in 6 months. Kova launches in 3 new product categories. Revenue reaches ₹180Cr by year 2. The acquisition offer is a distant memory.",
        "Burn accelerates to ₹4Cr/month to fund aggressive growth. A market slowdown in Q3 2025 makes the next raise difficult. Kova has 6 months of runway and needs a bridge round at unfavorable terms.",
        "Kova raises its Series C from a US impact fund. Revenue hits ₹350Cr by year 3. IPO conversations begin. Shreya becomes the face of Indian D2C. The original acquisition offer looks like highway robbery in hindsight."
      ],
      C: [
        "The strategic minority deal gives Kova access to 4,000 distribution touchpoints. Revenue grows 90% to ₹152Cr in year 1. The FMCG partner wants to increase stake — Shreya has leverage to negotiate.",
        "The conglomerate's sales team doesn't prioritize Kova products the way Shreya hoped. The distribution benefit is 60% of what was promised. But the brand integrity is intact and the VC runway anxiety is gone.",
        "The relationship sours over packaging decisions. The strategic partner exercises a right of first refusal on future fundraising. Kova is legally constrained in who it can bring as investors. The minority stake created a hidden veto player."
      ],
      D: [
        "Marketing cut from ₹1.8Cr to ₹0.6Cr per month. Customer acquisition cost rises as organic channels saturate. Revenue growth slows from 60% to 22%. Investors are concerned but willing to wait 12 months.",
        "Kova reaches cash-flow breakeven at ₹90Cr ARR. The business is now fundable on profitability, not just growth. Shreya raises ₹80Cr Series B at ₹400Cr valuation — 2.5x the original acquisition offer.",
        "The acquisition offer disappears during the 18-month cut-back period. The FMCG conglomerate acquires a competitor at 3x revenue. Kova is now in a stronger negotiating position — but the easiest exit window has closed."
      ]
    }
  },
  {
    id: "gridline",
    title: "GRIDLINE",
    subtitle: "A profitable B2B SaaS platform facing a price war it didn't start.",
    category: "B2B SaaS · Logistics · Competitive Response",
    overview: "Gridline builds logistics management software for mid-size Indian manufacturers — textile mills, auto-ancillary units, and food processing companies with 500-2,000 employees. Their product manages inbound raw materials, factory floor inventory, dispatch scheduling, and last-mile coordination with 3PL partners. Founded in 2017, they have 200 customers paying ₹6 lakh per year on average.",
    overview2: "ARR is ₹12 crore with 94% retention — one of the highest in Indian enterprise SaaS. But growth has stalled at 200 customers because the market is small, the sales cycle is long (6-8 months), and the product requires significant onboarding support. Six months ago, a US-based logistics SaaS player entered India with pricing at ₹3.6 lakh — a 40% discount to Gridline — and a US-backed marketing budget that Gridline cannot match.",
    financials: [
      { label: "ARR", value: "₹12Cr", change: "Flat for 3 quarters" },
      { label: "Retention", value: "94%", change: "Industry-leading" },
      { label: "Avg Contract", value: "₹6L/yr", change: "Stable" },
      { label: "Competitor Price", value: "₹3.6L/yr", change: "40% lower" },
    ],
    problem: "The US competitor has signed 18 customers in 6 months. None of Gridline's existing customers have churned yet — but two large prospects have chosen the competitor. The founder, Rahul Menon, is facing a board meeting where three options are being debated: match the competitor's price (destroying margins), differentiate aggressively with new product features, or retreat to a niche where the competitor has not entered (pharmaceutical manufacturers, who have stricter compliance needs). What do you recommend?",
    decisions: [
      {
        id: "A",
        title: "Match the competitor's price",
        rationale: "Stop the customer acquisition bleeding immediately. Sacrifice short-term margin to protect long-term customer base.",
        risk: 65,
        reward: 40,
        riskLabel: "HIGH",
        rewardLabel: "DEFENSIVE"
      },
      {
        id: "B",
        title: "Differentiate with compliance features for pharma",
        rationale: "Retreat to a defensible niche. Pharma manufacturers need FDA/cGMP-compliant logistics tracking — a complex need the US competitor hasn't built for.",
        risk: 50,
        reward: 80,
        riskLabel: "MEDIUM",
        rewardLabel: "HIGH"
      },
      {
        id: "C",
        title: "Raise prices and go premium",
        rationale: "Counter-intuitively go upmarket. Price at ₹12L/yr, reduce customer count target, add white-glove service and custom integrations.",
        risk: 55,
        reward: 75,
        riskLabel: "MEDIUM-HIGH",
        rewardLabel: "HIGH"
      },
      {
        id: "D",
        title: "Acquire the US competitor's Indian team",
        rationale: "If you can't beat them, hire them. Make an offer for the India GM and 3 sales people who built the 18-customer base.",
        risk: 40,
        reward: 60,
        riskLabel: "MEDIUM",
        rewardLabel: "STRATEGIC"
      }
    ],
    consequences: {
      A: [
        "Price cut to ₹3.6L executes in 30 days. Three at-risk prospects return. Gross margin drops from 78% to 61%. The board is unhappy but accepts the trade. The US competitor drops further to ₹2.4L in response.",
        "A price war in a market with 200 addressable customers is a race to zero. Within 18 months, both companies are burning cash with no clear winner. The US competitor gets an emergency capital infusion from its parent. Gridline is running out of runway.",
        "Gridline wins the price war by surviving longer. The US competitor withdraws from India after 2 years. Gridline reclaims its customers at original pricing. But 18 months of margin destruction has delayed profitability by 3 years."
      ],
      B: [
        "Gridline pivots 30% of engineering to pharma compliance features. The product is ready in 5 months. The first pharma customer closes at ₹18L/year — 3x average contract value. The US competitor has zero pharma presence.",
        "Pharma is a referral-heavy sector. One lighthouse customer (a top-10 Indian pharma manufacturer) opens 12 warm introductions. Gridline signs 8 pharma customers in year 1. ARR grows from ₹12Cr to ₹21Cr.",
        "The pharma niche becomes Gridline's identity. By year 3, they have 60 pharma customers, 40 legacy manufacturing customers, and an ARR of ₹40Cr. A strategic acquirer — a global pharma ERP company — values them at 8x ARR."
      ],
      C: [
        "Price increase to ₹12L announced. 40 of 200 customers decline to renew. The remaining 160 customers are paying more and getting more. Revenue actually increases despite customer count falling.",
        "Premium positioning attracts larger manufacturers — 2,000+ employee companies that the US competitor hasn't targeted. Average contract value rises to ₹15L. The enterprise segment has longer sales cycles but significantly less churn.",
        "Gridline becomes a ₹30Cr ARR business with 120 customers instead of 200. Lower volume, higher value, stronger margins. A PE firm acquires a 40% stake at ₹150Cr valuation to fund enterprise expansion."
      ],
      D: [
        "The India GM of the US competitor is approached. She's frustrated with corporate politics and receives a 2x salary offer plus equity. She brings her team of 3. The competitor's India expansion stalls immediately.",
        "The new team brings 8 of their 18 customer relationships. Gridline's ARR jumps to ₹17Cr in 6 months. The competitor sends a legal notice claiming trade secret violation. A 6-month distraction ensues.",
        "The legal matter resolves with a settlement. The acquired talent integrates and Gridline's sales velocity improves 4x. ARR hits ₹28Cr by year 2. The US competitor quietly exits India 18 months later."
      ]
    }
  },
  {
    id: "solara-mobility",
    title: "SOLARA MOBILITY",
    subtitle: "Two term sheets. One future. Which investor do you take?",
    category: "EV · Capital Strategy · Dilution",
    overview: "Solara Mobility is an electric two-wheeler startup based in Pune, founded by two ex-Bajaj engineers who saw that Indian commuters travel an average of 18 km per day — well within EV range — but are deterred by upfront cost and charging anxiety. Their answer: a swappable battery model where riders visit a kiosk (like a petrol pump) and exchange a depleted battery for a charged one in 90 seconds.",
    overview2: "The product works. Three thousand customers have pre-ordered after test rides at events across Pune, Nashik, and Nagpur. Manufacturing requires ₹50 crore to establish production at a Pune facility capable of 10,000 units per year. Two term sheets have arrived simultaneously. The founders need to choose one within 30 days.",
    financials: [
      { label: "Pre-Orders", value: "3,000 units", change: "Growing daily" },
      { label: "Unit Economics", value: "₹4,200 margin", change: "At scale" },
      { label: "Capex Required", value: "₹50Cr", change: "For production" },
      { label: "Runway", value: "4 months", change: "Critical" },
    ],
    problem: "Term Sheet 1: Yamaha India (strategic) offers ₹50Cr for 35% equity plus a board seat with veto rights on supply chain decisions. Term Sheet 2: Blume Ventures (VC) offers ₹50Cr for 28% equity, no operational control, but includes a 4-year forced exit clause (they must sell or IPO by 2028). Both are good partners. Both have fatal clauses. Which do you take — and can you negotiate?",
    decisions: [
      {
        id: "A",
        title: "Take Yamaha's term sheet",
        rationale: "The OEM relationship gives supply chain access, distribution, and manufacturing credibility. 35% dilution is high but the strategic value may justify it.",
        risk: 45,
        reward: 70,
        riskLabel: "MEDIUM",
        rewardLabel: "STRATEGIC"
      },
      {
        id: "B",
        title: "Take Blume's term sheet",
        rationale: "Financial independence is worth the extra 7% dilution savings. The 4-year exit clause is aggressive but manageable if growth is on track.",
        risk: 55,
        reward: 75,
        riskLabel: "MEDIUM-HIGH",
        rewardLabel: "HIGH"
      },
      {
        id: "C",
        title: "Negotiate Yamaha down to 25% without veto rights",
        rationale: "Counter-propose: ₹50Cr for 25% equity, no supply chain veto, but Yamaha gets preferred distribution rights in Maharashtra.",
        risk: 60,
        reward: 85,
        riskLabel: "HIGH",
        rewardLabel: "BEST CASE"
      },
      {
        id: "D",
        title: "Run a SAFE round to bridge while negotiating better terms",
        rationale: "Take ₹5Cr in convertible notes from angels to extend runway 3 months. Use that time to create a competitive tension between the two term sheets.",
        risk: 70,
        reward: 90,
        riskLabel: "HIGH",
        rewardLabel: "ASYMMETRIC"
      }
    ],
    consequences: {
      A: [
        "Yamaha's supply chain team deploys within 60 days. Manufacturing quality improves dramatically. The first 500 units are delivered in month 4. The veto on supply chain turns out to mean Yamaha insists on their component suppliers — adding ₹800 per unit in cost.",
        "Yamaha's board seat becomes contentious when Solara wants to enter Delhi. Yamaha sees Delhi as their own two-wheeler territory and blocks the expansion for 8 months. The strategic investor has become a strategic obstacle.",
        "By year 3, Solara is profitable and producing 8,000 units/year. Yamaha exercises its right of first refusal to increase stake to 51%. The founders retain 35% between them. The company is successful but no longer independently controlled."
      ],
      B: [
        "Blume deploys capital quickly. Production begins on Solara's own terms with their chosen suppliers. Unit economics are better without the Yamaha component mandate. 10,000 units/year capacity is reached in 14 months.",
        "The 4-year exit clause creates pressure as 2027 approaches. Solara is growing but not ready for an IPO. Blume begins pushing for a strategic sale. Two acquisition offers arrive — both below what the founders believe the company is worth.",
        "Solara IPOs on NSE in 2028 at ₹800Cr valuation. Blume's exit clause was ultimately met. The founders own 48% at IPO. Blume returns 16x on their investment. Everyone wins — just on a forced timeline."
      ],
      C: [
        "Yamaha's negotiating team walks. They came with a specific structure and Solara's counter was too far from their mandate. The deal collapses after 3 weeks of back-and-forth.",
        "Yamaha returns 6 weeks later with a revised offer: 29% equity, no supply chain veto, but with preferred distribution rights in 5 states. Solara accepts. This is the best outcome: strategic value without operational interference.",
        "The negotiation tactic works. Yamaha values the relationship more than the control clause. The final deal closes at 29% for ₹50Cr. Solara keeps full operational independence and gets distribution access in 12,000 Yamaha service centers across India."
      ],
      D: [
        "The SAFE round closes in 3 weeks — ₹4Cr from 6 angels. Runway extends by 90 days. Solara formally tells both investors they're evaluating multiple options and need 6 more weeks.",
        "Blume, aware of competition, removes the forced exit clause and drops to 26% for ₹50Cr. Yamaha drops to 30% but insists on the supply chain veto. Solara now has a genuinely better offer from Blume.",
        "Solara closes with Blume at 26% with no exit clause — the best possible outcome. The 3-month bridge cost the founders 2% in angel dilution but saved 9% in the institutional round. The SAFE strategy worked."
      ]
    }
  },
  {
    id: "lumen-health",
    title: "LUMEN HEALTH",
    subtitle: "800,000 users. No revenue. 18 months of runway. Three paths to monetization.",
    category: "Healthtech · Monetization · Ethics",
    overview: "Lumen Health is a telemedicine platform founded in 2021, allowing patients in Tier 2 and Tier 3 Indian cities to consult doctors via video, receive prescriptions, and order medicines from partner pharmacies. The platform is free. The founder, Dr. Ananya Krishnan, believed that removing the cost barrier was the fastest way to build trusted clinical relationships. It worked: 800,000 users, 94% monthly retention, and NPS of 71.",
    overview2: "The problem: free doesn't pay salaries. Lumen has ₹18 crore in the bank — 18 months of runway at current burn of ₹1 crore per month. The board has given Ananya 60 days to pick a monetization path and present a 36-month plan to profitability. Three serious options are on the table. One is fast, one is slow, one is dangerous.",
    financials: [
      { label: "Active Users", value: "800,000", change: "+15K/month" },
      { label: "Monthly Retention", value: "94%", change: "Best-in-class" },
      { label: "Monthly Burn", value: "₹1Cr", change: "Stable" },
      { label: "Runway", value: "18 months", change: "Shrinking" },
    ],
    problem: "Option 1: Freemium subscription at ₹199/month — unlimited consultations, priority booking, medicine delivery. Estimated 5-8% conversion rate among existing users. Fast revenue, potential churn risk from users who resist paying for something they got free. Option 2: B2B licensing to hospitals and insurance companies — charge ₹50/user/year for white-label platform access. Slower deal cycles, but sticky, high-margin contracts. Option 3: Sell anonymized health data to pharmaceutical companies — users have consented to anonymized research use in ToS. Potentially ₹15-20Cr in year 1. Ethically contested, legally permissible.",
    decisions: [
      {
        id: "A",
        title: "Launch freemium subscription",
        rationale: "Monetize the existing user relationship directly. 5% of 800,000 users paying ₹199/month is ₹8Cr/year — enough to reach profitability.",
        risk: 50,
        reward: 65,
        riskLabel: "MEDIUM",
        rewardLabel: "DIRECT"
      },
      {
        id: "B",
        title: "Pivot to B2B hospital licensing",
        rationale: "Enterprise contracts are sticky, high-value, and not dependent on individual user willingness to pay. One hospital contract = 50,000 patient interactions.",
        risk: 40,
        reward: 70,
        riskLabel: "LOW-MEDIUM",
        rewardLabel: "STABLE"
      },
      {
        id: "C",
        title: "Sell anonymized health data to pharma",
        rationale: "Fastest path to revenue. ₹15-20Cr in year 1 buys 3 more years of runway to figure out sustainable monetization.",
        risk: 80,
        reward: 50,
        riskLabel: "HIGH",
        rewardLabel: "SHORT-TERM"
      },
      {
        id: "D",
        title: "Build a hybrid: freemium + B2B simultaneously",
        rationale: "Don't pick. Both models can coexist. Launch freemium in 60 days while the B2B sales team targets 10 hospital pilots in parallel.",
        risk: 60,
        reward: 80,
        riskLabel: "MEDIUM-HIGH",
        rewardLabel: "HIGH"
      }
    ],
    consequences: {
      A: [
        "Freemium launches. 3.2% of users convert (lower than projected). That's 25,600 paying users at ₹199/month — ₹5.1Cr/year. Not enough for profitability, but meaningful first revenue signal.",
        "40,000 users who refused to pay delete the app in the first month. The churn is a warning shot: 5% of the user base lost because of a paywall. If the conversion trend doesn't improve, Lumen reaches profitability on a shrinking base.",
        "By month 8, the freemium model has found its equilibrium: 42,000 paying users, 730,000 free users, ₹8.4Cr ARR. Lumen is 65% of the way to profitability. A health insurance company reaches out to partner — they want to offer Lumen as a member benefit."
      ],
      B: [
        "First B2B contract closes in month 4 — a 200-bed hospital in Coimbatore paying ₹22L/year. The sales cycle was 3 months — within the expected range. The hospital uses Lumen for remote patient follow-ups and post-discharge care.",
        "By month 12, Lumen has 8 hospital contracts and 3 insurance partnerships. ARR from B2B: ₹2.8Cr. Better than freemium but slower. The runway has extended because burn is flat while revenue grows. The team is stable but growth is not venture-scale.",
        "At 24 months, Lumen has ₹9Cr in B2B ARR and is 3 months from profitability. A large hospital chain acquires a 40% stake for ₹25Cr, providing both capital and a direct pipeline to 45 hospitals. The company will likely be acquired within 3 years."
      ],
      C: [
        "The pharma data deal closes in 6 weeks. ₹18Cr upfront for 2 years of anonymized diagnostic data access. Runway extended to 36 months. The financial pressure disappears overnight.",
        "A journalist gets the ToS clause. The story runs in YourStory and gets picked up by The Hindu. 'Free health app selling your medical data to pharma companies.' The headline is technically inaccurate — users consented — but the framing is devastating. 180,000 users delete the app in 3 weeks.",
        "Lumen's NPS falls from 71 to 31. The pharma company adds a cancellation clause. Legal fights over data rights cost ₹2Cr in legal fees. Ananya spends 6 months in damage control instead of building the company. The fast money became the most expensive money in the business."
      ],
      D: [
        "Both tracks launch simultaneously. The freemium team and B2B team compete for engineering resources. Features are delayed. The freemium launch is late by 6 weeks. The B2B pipeline is slower because the product team is stretched.",
        "After 6 months, freemium is at 18,000 paying users (₹3.6Cr ARR) and B2B is at 4 hospital contracts (₹1.2Cr ARR). Combined: ₹4.8Cr ARR. Neither is performing as well as a focused single-track would have. But together, they create a diversified revenue base.",
        "At 18 months, the hybrid model has produced ₹12Cr ARR — below the single-track projections but above the worst case. The board is satisfied. A Series B raises ₹60Cr at ₹300Cr valuation. Both revenue streams scale together. Lumen becomes India's first profitable telemedicine company at month 28."
      ]
    }
  },
  {
    id: "terravia-logistics",
    title: "TERRAVIA LOGISTICS",
    subtitle: "An e-commerce logistics startup with unit economics that only work at a scale it hasn't reached yet.",
    category: "Logistics · Unit Economics · Series B",
    overview: "Terravia Logistics provides first-and-last-mile delivery for D2C brands in 6 Indian cities. Founded in 2020 by two former Delhivery operations executives, the company has built proprietary route optimization software and a network of 1,200 delivery partners (gig workers) across Mumbai, Pune, Bengaluru, Hyderabad, Chennai, and Delhi NCR. They deliver 85,000 packages per day and have a 97.2% on-time delivery rate — the highest in their competitive set.",
    overview2: "The problem: Terravia loses ₹14 per package today. At 85,000 daily shipments, that is a ₹1.19Cr daily loss. Their internal model shows the business becomes profitable at 220,000 packages per day — a scale they project reaching in 22 months with Series B capital. They have ₹9Cr in the bank — approximately 7 months of runway. A Series B term sheet has arrived from a top-tier VC for ₹120Cr at a ₹600Cr post-money valuation. There is one condition: reduce burn by 30% before the money wires.",
    financials: [
      { label: "Daily Shipments", value: "85,000", change: "Target: 220,000" },
      { label: "Loss Per Package", value: "₹14", change: "Breakeven at ₹0" },
      { label: "Daily Burn", value: "₹1.19Cr", change: "Must cut 30%" },
      { label: "Runway", value: "7 months", change: "Pre-Series B" }
    ],
    options: [
      {
        id: "A",
        title: "Cut 3 cities — consolidate to Mumbai, Bengaluru, Delhi only",
        rationale: "Density drives unit economics. Three cities at higher density will hit profitability faster than six cities at thin density. Exit Pune, Hyderabad, Chennai with 30 days notice to D2C brand clients.",
        risk: 55,
        reward: 75,
        riskLabel: "MEDIUM",
        rewardLabel: "HIGH"
      },
      {
        id: "B",
        title: "Renegotiate gig partner rates — reduce per-delivery payout by ₹8",
        rationale: "Gig partner costs are 61% of total COGS. A ₹8 reduction per delivery closes 57% of the per-package loss. Partners are price-takers in a supply-saturated market — they have no credible alternative at scale.",
        risk: 70,
        reward: 65,
        riskLabel: "HIGH",
        rewardLabel: "MEDIUM-HIGH"
      },
      {
        id: "C",
        title: "Add a ₹12 fuel surcharge — pass cost to D2C brand clients",
        rationale: "You are absorbing fuel and vehicle maintenance costs that should be client-borne. A ₹12 surcharge closes 86% of the per-package loss while preserving partner economics and city coverage.",
        risk: 60,
        reward: 70,
        riskLabel: "MEDIUM-HIGH",
        rewardLabel: "HIGH"
      },
      {
        id: "D",
        title: "Reject the 30% burn condition — counter at 15% over 6 months",
        rationale: "Operational cuts at this stage destroy the service quality metrics that make Terravia valuable. Counter-propose 15% burn reduction over 6 months via organic efficiency — not structural cuts.",
        risk: 65,
        reward: 80,
        riskLabel: "MEDIUM-HIGH",
        rewardLabel: "HIGH"
      }
    ],
    consequences: {
      A: [
        "You exit Pune, Hyderabad, and Chennai within 30 days. Fourteen D2C clients who operated across all 6 cities reduce their Terravia volume by 40% — they need a single national partner, not a 3-city one. Monthly shipment volume falls from 85,000/day to 64,000/day.",
        "The burn reduction is real — from ₹1.19Cr to ₹0.82Cr per day. The VC confirms the 30% threshold is met. Series B wires. But you've structurally shrunk the business in pursuit of the term sheet condition. The path to 220,000 daily shipments now takes 31 months instead of 22.",
        "At 18 months post-Series B: 140,000 daily shipments, losses narrowed to ₹6/package. The 3-city density strategy is working — Mumbai is near breakeven. But two national logistics players have signed the D2C clients you dropped, and re-acquiring them will cost marketing budget you don't have."
      ],
      B: [
        "You communicate the rate reduction to delivery partners with 15 days notice. 340 of your 1,200 partners (28%) resign within a week — they join Swiggy Instamart's new courier arm. Service capacity in Pune and Hyderabad falls below viable levels.",
        "On-time delivery rate falls from 97.2% to 91.4% over 30 days. Three large D2C clients trigger SLA breach clauses and renegotiate to lower rates. The burn reduction is achieved — but through service degradation that reduces revenue simultaneously.",
        "The VC notices the SLA deterioration in due diligence and renegotiates the term sheet from ₹600Cr post-money to ₹420Cr. You achieved the 30% burn target but destroyed the quality moat that made Terravia fundable. The round closes at a 30% valuation haircut."
      ],
      C: [
        "You announce the ₹12 fuel surcharge to D2C clients with 21 days notice. Eight of your 47 clients — mostly bootstrapped D2C brands with thin margins — immediately begin testing alternative logistics providers. Three switch within 45 days.",
        "Net volume reduction from client exits: 9,000 packages/day. But the surcharge revenue from the remaining 76,000 daily shipments improves per-package economics by ₹12. Your loss narrows from ₹14 to ₹2 per package. Burn falls 85% — far exceeding the 30% VC condition.",
        "Series B closes at full ₹600Cr valuation. The 8 churned clients are replaced within 3 months as word spreads about your delivery reliability. At 14 months: 195,000 daily shipments, approaching breakeven. The surcharge becomes the industry standard — two competitors implement their own version 6 months later."
      ],
      D: [
        "You counter at 15% burn reduction over 6 months. The VC's partner takes 72 hours to respond. They come back: 22% over 4 months as a compromise. You accept. The runway implications are tight — you need to hit the efficiency milestones exactly.",
        "You achieve 19% burn reduction over 4 months through route optimization improvements, vehicle utilization increases, and two small operational restructurings. You miss the 22% target by 3 points. The VC extends the measurement period by 45 days.",
        "Series B closes 6 months after the initial term sheet — longer than planned. But no structural damage was done to the operation. At 20 months: 210,000 daily shipments, ₹2 loss per package. You are 3 months from breakeven and your service metrics are pristine. The long negotiation was worth preserving the quality moat."
      ]
    }
  },
  {
    id: "novara-fintech",
    title: "NOVARA FINTECH",
    subtitle: "A profitable neobank with a regulator asking uncomfortable questions about its lending book.",
    category: "Fintech · Regulatory Risk · Governance",
    overview: "Novara is a digital lending and neobanking platform founded in 2019, serving 2.1 million customers in India with personal loans (₹50,000–₹5L), savings accounts (via banking partner), and a co-branded credit card. The company has grown to ₹380Cr in annual revenue and achieved its first profitable year in FY23 with ₹22Cr net profit. It holds an NBFC license from RBI and processes ₹120Cr in monthly loan disbursals.",
    overview2: "The problem arrived as a 12-page letter from the Reserve Bank of India's Department of Supervision. The RBI has flagged three concerns: (1) Novara's average interest rate of 31.4% APR on personal loans may constitute 'usurious pricing' under forthcoming digital lending guidelines; (2) Novara's recovery partner — Shakti Collections — has received 847 consumer complaints in 6 months for aggressive collection tactics; (3) Novara's KYC process for 340,000 customers in Tier 3 cities relied on a video-KYC vendor whose compliance certification has since been revoked. The RBI has given 60 days to respond. Novara's investors expect a Series C announcement next quarter.",
    financials: [
      { label: "Annual Revenue", value: "₹380Cr", change: "+42% YoY" },
      { label: "Net Profit (FY23)", value: "₹22Cr", change: "First profitable year" },
      { label: "Avg Loan Rate", value: "31.4% APR", change: "RBI questioning" },
      { label: "KYC at Risk", value: "340,000 customers", change: "Compliance gap" }
    ],
    options: [
      {
        id: "A",
        title: "Full voluntary compliance — fix all three issues before the 60-day deadline",
        rationale: "Address each RBI concern proactively: cap rates at 28% APR, terminate Shakti Collections immediately, re-KYC the 340,000 affected customers. Get ahead of the regulator.",
        risk: 50,
        reward: 80,
        riskLabel: "MEDIUM",
        rewardLabel: "HIGH"
      },
      {
        id: "B",
        title: "Respond defensively — argue all three issues are compliant under current rules",
        rationale: "Hire a senior regulatory counsel. Submit a detailed legal response arguing that current RBI guidelines don't prohibit any of Novara's practices. Buy time while the rules are still being formulated.",
        risk: 75,
        reward: 55,
        riskLabel: "HIGH",
        rewardLabel: "MEDIUM"
      },
      {
        id: "C",
        title: "Fix the collection agency issue immediately — negotiate on rates and KYC",
        rationale: "The collection complaints are the highest-visibility, highest-reputational-risk issue. Fix it first. Then negotiate with the RBI on a timeline for rate adjustments and KYC remediation.",
        risk: 40,
        reward: 70,
        riskLabel: "LOW-MEDIUM",
        rewardLabel: "HIGH"
      },
      {
        id: "D",
        title: "Delay the Series C announcement — use the capital raise to fund compliance",
        rationale: "Don't announce the Series C with a regulatory overhang. Raise the round with full RBI compliance as a selling point. Frame it as risk management maturity, not regulatory pressure.",
        risk: 35,
        reward: 65,
        riskLabel: "LOW-MEDIUM",
        rewardLabel: "MEDIUM-HIGH"
      }
    ],
    consequences: {
      A: [
        "You cap rates at 27.9% APR — below the RBI's implied threshold. Terminating Shakti Collections costs ₹4.2Cr in contract breakage and requires onboarding a new recovery partner. The re-KYC of 340,000 customers takes 9 weeks and costs ₹6.8Cr in operational expense.",
        "The total compliance cost is ₹18Cr — nearly erasing your FY23 profit. But your RBI response is exemplary. The regulator's 60-day follow-up note commends Novara's 'proactive remediation approach.' Your NBFC license review, which you didn't know was pending, is approved without conditions.",
        "Series C closes 3 months later at ₹1,800Cr valuation — a 40% premium over your last round. Two lead investors cite the RBI compliance handling as evidence of management quality. The ₹18Cr compliance cost returned multiples in investor confidence."
      ],
      B: [
        "You submit a 47-page legal response arguing compliance under current guidelines. RBI's supervisory team reads it and is not satisfied. A second letter arrives in 45 days, more specific than the first, asking for detailed loan-by-loan data on the 340,000 KYC customers.",
        "The legal defense posture has escalated the situation. RBI schedules an on-site inspection of Novara's operations — a step they take only when initial responses are unsatisfactory. The inspection lasts 3 weeks. During this period, your Series C investors put the term sheet on hold.",
        "The inspection finds no criminal violations but issues a formal corrective action direction requiring rate caps, partner replacement, and full re-KYC within 90 days — exactly what Option A would have delivered voluntarily. The delay cost 5 months, ₹12Cr in legal fees, and the Series C at the original valuation. You close the round at 25% lower valuation."
      ],
      C: [
        "You terminate Shakti Collections within 7 days. A public statement acknowledging the consumer complaints and announcing a new, TRAI-compliant recovery partner is well-received by consumer advocacy groups. The RBI's supervision team acknowledges the swift action in an interim note.",
        "On rates and KYC, you negotiate a 90-day timeline. The RBI accepts this as a good-faith gesture given the immediate collection action. You use the 90 days to implement rate tiers — new customers at 28.9%, existing customers grandfathered — and complete KYC re-verification for 280,000 of the 340,000 customers.",
        "The remaining 60,000 customers cannot be re-verified and must be offboarded — a 3% loan book reduction. Series C proceeds with the regulatory situation characterized as 'being actively managed.' Lead investors negotiate a 10% valuation discount versus their initial offer but close the round. The pragmatic approach preserved the business while managing stakeholder expectations honestly."
      ],
      D: [
        "You delay the Series C announcement by 4 months. Your existing investors are frustrated — two had planned to mark up their positions in the new round. You spend those 4 months executing full compliance: rate caps, partner replacement, complete re-KYC.",
        "The RBI closes its inquiry with a clean chit letter — a document that will become the most valuable 2-page PDF in Novara's fundraising deck. Your CFO builds a 'Regulatory Clean Bill' slide for the Series C pitch.",
        "Series C closes at a 15% premium to the original pre-regulatory-letter valuation. Three new investors specifically cite the clean RBI record as a competitive moat — other fintechs in the space are under ongoing scrutiny. The delay was frustrating but transformed a liability into a differentiator."
      ]
    }
  }
];
