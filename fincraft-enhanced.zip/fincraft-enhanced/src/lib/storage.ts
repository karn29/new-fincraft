export interface UserProfile {
  xp: number;
  streak: number;
  lastPlayed: number | null;
  decisions: Decision[];
  completedMarket: string[];
  completedBoardroom: string[];
  badges: string[];
  fingerprint: {
    riskAppetite: number;
    innovationBias: number;
    lossTolerance: number;
    contrarianScore: number;
    decisionSpeed: number;
    indiaInstinct: number;
  };
}

export interface Decision {
  scenario: string;
  eventIndex: number;
  choice: string;
  xpEarned: number;
  timestamp: number;
}

const STORAGE_KEY = "fincraft_profile";

const defaultProfile: UserProfile = {
  xp: 0,
  streak: 0,
  lastPlayed: null,
  decisions: [],
  completedMarket: [],
  completedBoardroom: [],
  badges: [],
  fingerprint: {
    riskAppetite: 50,
    innovationBias: 50,
    lossTolerance: 50,
    contrarianScore: 50,
    decisionSpeed: 50,
    indiaInstinct: 50
  }
};

export const getProfile = (): UserProfile => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) return defaultProfile;
    return JSON.parse(data);
  } catch (e) {
    return defaultProfile;
  }
};

export const saveProfile = (profile: UserProfile): void => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
};

export const addXP = (amount: number): UserProfile => {
  const profile = getProfile();
  profile.xp += amount;
  
  // Streak logic
  const now = Date.now();
  const ONE_DAY = 24 * 60 * 60 * 1000;
  if (profile.lastPlayed) {
    const timeSinceLast = now - profile.lastPlayed;
    if (timeSinceLast > ONE_DAY && timeSinceLast < ONE_DAY * 2) {
      profile.streak += 1;
    } else if (timeSinceLast >= ONE_DAY * 2) {
      profile.streak = 1;
    }
  } else {
    profile.streak = 1;
  }
  profile.lastPlayed = now;
  
  saveProfile(profile);
  return profile;
};

export const recordDecision = (decision: Decision): UserProfile => {
  const profile = getProfile();
  profile.decisions.push(decision);

  // Update fingerprint based on decisions
  const fp = profile.fingerprint;
  const choice = decision.choice.toUpperCase();
  
  // Risk appetite
  if (choice.includes("BUY") || choice.includes("DOUBLE DOWN") || choice.includes("ACQUIRE")) {
    fp.riskAppetite = Math.min(100, fp.riskAppetite + 3);
  } else if (choice.includes("SELL") || choice.includes("CASH") || choice.includes("WALK AWAY")) {
    fp.riskAppetite = Math.max(0, fp.riskAppetite - 2);
  }

  // Loss tolerance
  if (choice.includes("HOLD") || choice.includes("STAY") || choice.includes("NERVE")) {
    fp.lossTolerance = Math.min(100, fp.lossTolerance + 3);
  } else if (choice.includes("PANIC") || choice.includes("FROZEN")) {
    fp.lossTolerance = Math.max(0, fp.lossTolerance - 4);
  }

  // Contrarian score (going against consensus earns higher XP)
  if (decision.xpEarned >= 150) {
    fp.contrarianScore = Math.min(100, fp.contrarianScore + 2);
  } else if (decision.xpEarned <= 25) {
    fp.contrarianScore = Math.max(0, fp.contrarianScore - 1);
  }

  // Innovation bias
  if (choice.includes("AWS") || choice.includes("TECH") || choice.includes("IT SECTOR") || choice.includes("ERP")) {
    fp.innovationBias = Math.min(100, fp.innovationBias + 4);
  }

  // India instinct
  if (decision.scenario === "1991" || decision.scenario === "1992") {
    fp.indiaInstinct = Math.min(100, fp.indiaInstinct + 4);
  }
  if (decision.scenario === "zomato-2021" || decision.scenario === "infosys-1999") {
    fp.indiaInstinct = Math.min(100, fp.indiaInstinct + 3);
  }

  // Decision speed — more decisions = faster thinker proxy
  fp.decisionSpeed = Math.min(100, fp.decisionSpeed + 1);

  saveProfile(profile);
  return profile;
};

export const markScenarioComplete = (type: 'market' | 'boardroom', id: string): UserProfile => {
  const profile = getProfile();
  if (type === 'market' && !profile.completedMarket.includes(id)) {
    profile.completedMarket.push(id);
  } else if (type === 'boardroom' && !profile.completedBoardroom.includes(id)) {
    profile.completedBoardroom.push(id);
  }
  saveProfile(profile);
  return profile;
};

export const unlockBadge = (badgeId: string): boolean => {
  const profile = getProfile();
  if (!profile.badges.includes(badgeId)) {
    profile.badges.push(badgeId);
    saveProfile(profile);
    return true; // Newly unlocked
  }
  return false;
};
