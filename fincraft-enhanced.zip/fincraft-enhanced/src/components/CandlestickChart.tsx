import React from "react";
import { motion } from "framer-motion";

export default function CandlestickChart() {
  const generateCandles = () => {
    const candles = [];
    let currentY = 150;
    
    for (let i = 0; i < 40; i++) {
      const isGreen = Math.random() > 0.5;
      const height = Math.random() * 40 + 10;
      const wickHeight = height + Math.random() * 20;
      
      const yOffset = isGreen ? currentY - height : currentY;
      currentY = isGreen ? currentY - height + (Math.random() * 10 - 5) : currentY + height + (Math.random() * 10 - 5);
      
      // Ensure it stays within bounds roughly
      if (currentY < 50) currentY += 50;
      if (currentY > 250) currentY -= 50;

      candles.push({
        x: i * 25,
        y: yOffset,
        h: height,
        w: 12,
        isGreen,
        wickY: yOffset - (wickHeight - height)/2,
        wickH: wickHeight
      });
    }
    return candles;
  };

  const candles = React.useMemo(() => generateCandles(), []);

  return (
    <div className="absolute inset-0 overflow-hidden opacity-20 pointer-events-none filter blur-[1px]">
      <motion.svg 
        viewBox="0 0 1000 300" 
        preserveAspectRatio="none" 
        className="w-full h-full"
        initial={{ x: "0%" }}
        animate={{ x: "-50%" }}
        transition={{ repeat: Infinity, duration: 30, ease: "linear" }}
      >
        {/* Draw candles twice for seamless loop */}
        {[...candles, ...candles.map(c => ({...c, x: c.x + 1000}))].map((c, i) => (
          <g key={i}>
            <rect
              x={c.x + c.w / 2 - 1}
              y={c.wickY}
              width={2}
              height={c.wickH}
              fill={c.isGreen ? "#00FF88" : "#FF2D55"}
              opacity={0.6}
            />
            <rect
              x={c.x}
              y={c.y}
              width={c.w}
              height={c.h}
              fill={c.isGreen ? "#00FF88" : "#FF2D55"}
            />
          </g>
        ))}
      </motion.svg>
      {/* Gradient overlay to fade edges */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#07080D] via-transparent to-[#07080D]" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#07080D] via-transparent to-[#07080D]" />
    </div>
  );
}