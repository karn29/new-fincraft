import React from "react";
import { motion } from "framer-motion";

interface DecisionPoint {
  label: string;
  aligned: boolean; // true = green, false = red
}

export default function DecisionTimeline({ decisions }: { decisions: DecisionPoint[] }) {
  return (
    <div className="w-full relative py-8">
      {/* Background line */}
      <div className="absolute top-1/2 left-0 w-full h-[2px] bg-[#1E2028] -translate-y-1/2" />
      
      <div className="relative flex justify-between items-center w-full">
        {decisions.map((dec, i) => (
          <div key={i} className="flex flex-col items-center gap-2 relative">
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: i * 0.2, type: "spring" }}
              className={`w-4 h-4 rounded-full z-10 border-2 border-[#07080D] shadow-[0_0_10px_rgba(0,0,0,0.5)] ${
                dec.aligned ? "bg-primary" : "bg-destructive"
              }`}
            />
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.2 + 0.1 }}
              className="absolute top-6 w-24 text-center"
            >
              <div className="text-[10px] font-ibm text-gray-400 uppercase leading-tight">
                {dec.label}
              </div>
            </motion.div>
          </div>
        ))}
      </div>
    </div>
  );
}