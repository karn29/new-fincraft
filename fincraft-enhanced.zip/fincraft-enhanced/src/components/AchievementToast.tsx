import { toast } from "sonner";
import React from "react";

export const showAchievement = (title: string, description: string) => {
  toast.custom((t) => (
    <div className="bg-[#12141A] border border-primary p-4 shadow-[0_0_15px_rgba(0,255,136,0.1)] font-ibm w-80 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-primary" />
      <div className="flex gap-4 items-start">
        <div className="text-2xl pt-1">🏆</div>
        <div>
          <div className="text-xs text-primary font-bold mb-1 tracking-wider uppercase">BADGE UNLOCKED</div>
          <div className="text-sm text-white mb-1 uppercase tracking-wide">{title}</div>
          <div className="text-xs text-gray-400">{description}</div>
        </div>
      </div>
    </div>
  ), { duration: 5000 });
};