import React from "react";
import { motion } from "framer-motion";

interface Sector {
  name: string;
  value: number; // -100 to 100
}

export default function SectorHeatmap({ sectors }: { sectors: Sector[] }) {
  const getColor = (value: number) => {
    if (value > 0) {
      // Scale opacity/lightness for green
      const opacity = Math.max(0.2, value / 100);
      return `rgba(0, 255, 136, ${opacity})`;
    } else {
      // Scale opacity/lightness for red
      const opacity = Math.max(0.2, Math.abs(value) / 100);
      return `rgba(255, 45, 85, ${opacity})`;
    }
  };

  return (
    <div className="grid grid-cols-4 gap-1 w-full max-w-sm">
      {sectors.map((sector, i) => (
        <motion.div
          key={sector.name}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8 + i * 0.05 }}
          className="aspect-square flex flex-col items-center justify-center border border-[#1E2028] p-2 text-center"
          style={{ backgroundColor: getColor(sector.value) }}
        >
          <div className="text-[10px] font-ibm uppercase tracking-tighter text-white mix-blend-overlay">
            {sector.name}
          </div>
          <div className="text-xs font-ibm font-bold text-white mix-blend-overlay mt-1">
            {sector.value > 0 ? "+" : ""}{sector.value}%
          </div>
        </motion.div>
      ))}
    </div>
  );
}