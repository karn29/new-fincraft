import React from "react";
import { motion } from "framer-motion";

export default function FearGreedGauge({ value }: { value: number }) {
  // Value 0 = Extreme Fear (Red), 100 = Extreme Greed (Green)
  // SVG Arc from 180deg to 0deg
  
  const rotation = -90 + (value / 100) * 180;
  
  let label = "NEUTRAL";
  let color = "#F5A623"; // Amber
  
  if (value <= 25) { label = "EXTREME FEAR"; color = "#FF2D55"; }
  else if (value <= 45) { label = "FEAR"; color = "#FF2D55"; }
  else if (value >= 75) { label = "EXTREME GREED"; color = "#00FF88"; }
  else if (value >= 55) { label = "GREED"; color = "#00FF88"; }

  return (
    <div className="relative w-48 h-28 flex flex-col items-center justify-end overflow-hidden">
      <svg viewBox="0 0 200 100" className="w-full">
        {/* Background Arc */}
        <path
          d="M 10 90 A 80 80 0 0 1 190 90"
          fill="none"
          stroke="#1E2028"
          strokeWidth="15"
          strokeLinecap="round"
        />
        {/* Gradient Arc (simulated with multiple paths or definition) */}
        <defs>
          <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#FF2D55" />
            <stop offset="50%" stopColor="#F5A623" />
            <stop offset="100%" stopColor="#00FF88" />
          </linearGradient>
        </defs>
        <path
          d="M 10 90 A 80 80 0 0 1 190 90"
          fill="none"
          stroke="url(#gaugeGradient)"
          strokeWidth="15"
          strokeLinecap="round"
          opacity={0.8}
        />
        
        {/* Center dot */}
        <circle cx="100" cy="90" r="6" fill="#FFF" />
      </svg>
      
      {/* Animated Pointer */}
      <motion.div
        className="absolute bottom-0 left-1/2 w-1 h-20 bg-white origin-bottom rounded-t-full z-10"
        style={{ marginLeft: "-2px" }}
        initial={{ rotate: -90 }}
        animate={{ rotate: rotation }}
        transition={{ type: "spring", stiffness: 50, damping: 15, delay: 0.5 }}
      />
      
      <div className="absolute bottom-2 left-0 w-full text-center">
        <div className="text-xs font-ibm text-gray-400">FEAR / GREED</div>
        <div className="text-sm font-bold font-ibm" style={{ color }}>{value} — {label}</div>
      </div>
    </div>
  );
}