import React, { useEffect, useState } from "react";
import { getProfile } from "@/lib/storage";

export default function XPBar() {
  const [profile, setProfile] = useState(() => getProfile());

  useEffect(() => {
    const handleStorageChange = () => {
      setProfile(getProfile());
    };
    
    window.addEventListener("storage", handleStorageChange);
    // Custom event for internal updates
    window.addEventListener("profile_updated", handleStorageChange);
    
    return () => {
      window.removeEventListener("storage", handleStorageChange);
      window.removeEventListener("profile_updated", handleStorageChange);
    };
  }, []);

  const level = Math.floor(profile.xp / 500) + 1;
  const currentLevelXP = profile.xp % 500;
  const progressPercent = (currentLevelXP / 500) * 100;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 h-10 bg-[#07080D] border-b border-[#1E2028] flex items-center justify-between px-4 font-ibm text-xs text-white">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="bg-primary/20 text-primary px-2 py-0.5 rounded border border-primary/30">
            LVL {level}
          </div>
          <div className="w-32 h-2 bg-[#12141A] rounded overflow-hidden">
            <div 
              className="h-full bg-primary transition-all duration-500 ease-out" 
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <div className="text-gray-400">
            {profile.xp.toLocaleString()} / {(level * 500).toLocaleString()} XP
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-gray-400">STREAK</span>
        <span className="text-orange-500 font-bold">🔥 {profile.streak}</span>
      </div>
    </div>
  );
}