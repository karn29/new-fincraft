import React, { useState, useEffect, useRef } from "react";
import { Link, useParams } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import XPBar from "@/components/XPBar";
import FearGreedGauge from "@/components/FearGreedGauge";
import SectorHeatmap from "@/components/SectorHeatmap";
import { marketScenarios, CompanyDossier } from "@/lib/scenarios";
import { addXP, recordDecision, markScenarioComplete, unlockBadge } from "@/lib/storage";

const DONUT_COLORS = ["#00FF88", "#FF2D55", "#F5A623", "#4ECDC4", "#A78BFA", "#FB923C"];

export default function MarketSimulation() {
  const { scenarioId } = useParams<{ scenarioId: string }>();
  const scenario = marketScenarios.find((s) => s.id === scenarioId);

  const [phase, setPhase] = useState<"briefing" | "dossier" | "allocate" | "result">("briefing");
  const [briefingText, setBriefingText] = useState("");
  const [openDossier, setOpenDossier] = useState<CompanyDossier | null>(null);
  const [allocations, setAllocations] = useState<Record<string, number>>({});
  const [portfolioValue, setPortfolioValue] = useState(scenario?.startingPortfolio || 100000);

  useEffect(() => {
    if (!scenario) return;
    let i = 0;
    const text = scenario.brief;
    const interval = setInterval(() => {
      setBriefingText(text.slice(0, i));
      i++;
      if (i > text.length) clearInterval(interval);
    }, 18);
    return () => clearInterval(interval);
  }, [scenario]);

  useEffect(() => {
    if (!scenario) return;
    const initial: Record<string, number> = {};
    scenario.companies.forEach((c: CompanyDossier) => { initial[c.id] = 0; });
    setAllocations(initial);
  }, [scenario]);

  if (!scenario) return <div className="text-white p-10 font-ibm bg-[#07080D] min-h-screen">SCENARIO NOT FOUND.</div>;

  const totalAllocated = Object.values(allocations).reduce((a, b) => a + b, 0);
  const remaining = 100 - totalAllocated;

  const handleSlider = (id: string, val: number) => {
    const current = allocations[id];
    const others = totalAllocated - current;
    const maxAllowable = Math.min(40, 100 - others);
    const clamped = Math.min(val, maxAllowable);
    setAllocations(prev => ({ ...prev, [id]: clamped }));
  };

  const handleSubmitAllocation = () => {
    if (totalAllocated !== 100) return;
    // Calculate portfolio performance based on allocations
    let finalValue = scenario.startingPortfolio;
    let totalXP = 0;

    scenario.companies.forEach((company: CompanyDossier) => {
      const pct = (allocations[company.id] || 0) / 100;
      const returnPct = company.sectorReturn / 100;
      finalValue += scenario.startingPortfolio * pct * returnPct;

      // XP based on contrarian bets (putting money into declining sectors = low XP, rising = higher XP)
      const alloc = allocations[company.id] || 0;
      if (alloc > 0 && company.sectorReturn > 0) totalXP += Math.ceil(alloc * 2);
      else if (alloc > 0 && company.sectorReturn < 0) totalXP += Math.ceil(alloc * 0.5);
    });

    setPortfolioValue(finalValue);
    addXP(Math.max(50, Math.min(300, totalXP)));
    window.dispatchEvent(new Event("profile_updated"));

    recordDecision({
      scenario: scenario.id,
      eventIndex: 0,
      choice: `Allocated: ${scenario.companies.map((c: CompanyDossier) => `${c.name}(${allocations[c.id] || 0}%)`).join(", ")}`,
      xpEarned: Math.max(50, Math.min(300, totalXP)),
      timestamp: Date.now()
    });

    const updated = markScenarioComplete("market", scenario.id);
    const indianScenarios = ["1991", "1992"];
    if (indianScenarios.filter(id => updated.completedMarket.includes(id)).length >= 2) {
      if (unlockBadge("india_bull")) toast("INDIA BULL UNLOCKED", { description: "Completed all Indian market scenarios" });
    }
    if (updated.completedMarket.length >= 4) {
      if (unlockBadge("market_historian")) toast("MARKET HISTORIAN UNLOCKED", { description: "All 4 market scenarios debriefed" });
    }

    setPhase("result");
  };

  const getReturn = () => ((portfolioValue - scenario.startingPortfolio) / scenario.startingPortfolio) * 100;
  const formatCur = (v: number) => scenario.currency + v.toLocaleString(undefined, { maximumFractionDigits: 0 });

  const donutData = scenario.companies
    .filter((c: CompanyDossier) => (allocations[c.id] || 0) > 0)
    .map((c: CompanyDossier, i: number) => ({ name: c.name, value: allocations[c.id], color: DONUT_COLORS[i] }));

  if (donutData.length === 0 && remaining > 0) {
    donutData.push({ name: "Unallocated", value: remaining, color: "#1E2028" });
  }

  return (
    <div className="min-h-[100dvh] w-full bg-[#07080D] text-white flex flex-col pt-10">
      <XPBar />

      {/* Dossier Overlay */}
      <AnimatePresence>
        {openDossier && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
            onClick={() => setOpenDossier(null)}
          >
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              className="bg-[#0D0F15] border border-[#1E2028] max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              onClick={e => e.stopPropagation()}
            >
              <div className="h-1 bg-primary w-full" />
              <div className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <div className="text-primary font-ibm text-[10px] tracking-widest mb-1">COMPANY DOSSIER — {openDossier.sector.toUpperCase()}</div>
                    <h2 className="text-2xl font-syne font-bold text-white">{openDossier.name}</h2>
                    <div className="text-gray-500 font-ibm text-xs mt-1">EST. {openDossier.founded}</div>
                  </div>
                  <button onClick={() => setOpenDossier(null)} className="text-gray-500 hover:text-white font-ibm text-xs border border-[#1E2028] px-3 py-1">✕ CLOSE</button>
                </div>

                <p className="font-lora text-gray-300 text-sm leading-relaxed mb-8 italic">
                  {openDossier.description}
                </p>

                {/* Financial Snapshot */}
                <div className="mb-6">
                  <div className="text-[10px] font-ibm text-gray-500 tracking-widest mb-3">FINANCIAL SNAPSHOT</div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {[
                      { label: "Revenue", value: openDossier.revenue, change: openDossier.revenueChange },
                      { label: "Profit Margin", value: openDossier.profitMargin, change: "" },
                      { label: "Debt / Equity", value: openDossier.debtToEquity, change: "" },
                      { label: "Market Cap", value: openDossier.marketCap, change: "" },
                    ].map((s, i) => (
                      <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                        className="bg-[#12141A] border border-[#1E2028] p-4 text-center">
                        <div className="text-[10px] font-ibm text-gray-500 mb-1 uppercase">{s.label}</div>
                        <div className="text-lg font-ibm font-bold text-white">{s.value}</div>
                        {s.change && <div className="text-[10px] font-ibm text-primary mt-1">{s.change}</div>}
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Business Model */}
                <div className="mb-6">
                  <div className="text-[10px] font-ibm text-gray-500 tracking-widest mb-3">REVENUE BREAKDOWN</div>
                  <div className="space-y-2">
                    {openDossier.model.map((m, i) => (
                      <div key={i}>
                        <div className="flex justify-between text-xs font-ibm mb-1">
                          <span className="text-gray-400">{m.label}</span>
                          <span className="text-primary">{m.pct}%</span>
                        </div>
                        <div className="h-1.5 bg-[#1E2028] rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${m.pct}%` }}
                            transition={{ duration: 0.6, delay: i * 0.1 }}
                            className="h-full bg-primary/70 rounded-full"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Sector performance signal */}
                <div className={`border p-4 ${openDossier.sectorReturn > 0 ? "border-primary/30 bg-primary/5" : "border-destructive/30 bg-destructive/5"}`}>
                  <div className="text-[10px] font-ibm text-gray-500 mb-1 tracking-wider">HISTORICAL SECTOR RETURN ({scenario.date.split(",").pop()?.trim()})</div>
                  <div className={`text-2xl font-ibm font-bold ${openDossier.sectorReturn > 0 ? "text-primary" : "text-destructive"}`}>
                    {openDossier.sectorReturn > 0 ? "+" : ""}{openDossier.sectorReturn}%
                  </div>
                  <div className="text-[10px] font-ibm text-gray-500 mt-1">This is what happened. You don't know this yet.</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {/* BRIEFING */}
        {phase === "briefing" && (
          <motion.div key="briefing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex-1 flex flex-col items-center justify-center p-6 max-w-5xl mx-auto w-full">
            <div className="w-full bg-[#0D0F15] border border-[#1E2028] p-8 shadow-2xl relative">
              <div className="absolute top-0 left-0 w-full h-1 bg-primary/60" />
              <div className="flex flex-col md:flex-row gap-10">
                <div className="flex-1">
                  <div className="text-primary font-ibm text-xs tracking-widest mb-4">INTELLIGENCE BRIEFING // {scenario.date}</div>
                  <h1 className="text-3xl md:text-5xl font-syne font-bold uppercase mb-6 text-white">{scenario.title}</h1>
                  <p className="font-lora text-base text-gray-300 leading-relaxed min-h-[120px]">
                    {briefingText}
                    <span className="animate-cursor-blink text-primary ml-1">█</span>
                  </p>
                  <button onClick={() => setPhase("dossier")}
                    className="mt-8 px-6 py-3 bg-primary text-[#07080D] font-ibm font-bold text-sm hover:bg-white transition-colors">
                    &gt;_ ACCESS COMPANY INTELLIGENCE
                  </button>
                </div>
                <div className="w-full md:w-64 flex flex-col gap-8">
                  <FearGreedGauge value={scenario.fearGreed} />
                  <div>
                    <div className="text-[10px] font-ibm text-gray-500 mb-2 tracking-wider">SECTOR MOMENTUM</div>
                    <SectorHeatmap sectors={scenario.sectors} />
                  </div>
                </div>
              </div>
              <div className="mt-8 border-t border-[#1E2028] pt-4 overflow-hidden relative">
                <div className="absolute left-0 top-4 bottom-0 w-12 bg-gradient-to-r from-[#0D0F15] to-transparent z-10" />
                <div className="absolute right-0 top-4 bottom-0 w-12 bg-gradient-to-l from-[#0D0F15] to-transparent z-10" />
                <motion.div className="flex whitespace-nowrap gap-8 text-xs font-ibm text-gray-400"
                  animate={{ x: [0, -1000] }} transition={{ repeat: Infinity, duration: 20, ease: "linear" }}>
                  {[...scenario.news, ...scenario.news].map((n, i) => (
                    <span key={i} className="uppercase flex items-center gap-2">
                      <span className="text-primary">◆</span> {n}
                    </span>
                  ))}
                </motion.div>
              </div>
            </div>
          </motion.div>
        )}

        {/* DOSSIER PHASE */}
        {phase === "dossier" && (
          <motion.div key="dossier" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex-1 p-6 max-w-6xl mx-auto w-full">
            <div className="mb-8 flex items-end justify-between">
              <div>
                <div className="text-primary font-ibm text-xs tracking-widest mb-2">COMPANY INTELLIGENCE // {scenario.title}</div>
                <h2 className="text-3xl font-syne font-bold text-white">SELECT YOUR INVESTMENTS</h2>
                <p className="font-lora text-gray-400 text-sm mt-2 italic">
                  Read each company's dossier before you commit capital. Click any card to open the full intelligence file.
                </p>
              </div>
              <button onClick={() => setPhase("allocate")}
                className="px-6 py-3 border border-primary text-primary font-ibm text-xs font-bold hover:bg-primary hover:text-[#07080D] transition-colors">
                PROCEED TO ALLOCATION →
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {scenario.companies.map((company: CompanyDossier, i: number) => (
                <motion.button
                  key={company.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  onClick={() => setOpenDossier(company)}
                  className="text-left border border-[#1E2028] bg-[#0D0F15] p-6 hover:border-primary/60 hover:bg-primary/5 transition-all group relative overflow-hidden"
                >
                  <div className="absolute top-0 left-0 w-0 group-hover:w-full h-0.5 bg-primary transition-all duration-500" />
                  <div className="text-[10px] font-ibm text-gray-500 tracking-widest mb-1">{company.sector.toUpperCase()}</div>
                  <h3 className="text-lg font-syne font-bold text-white mb-2 group-hover:text-primary transition-colors">{company.name}</h3>
                  <p className="text-xs font-ibm text-gray-500 mb-4 line-clamp-2">
                    {company.description.split(".")[0]}.
                  </p>
                  <div className="flex justify-between items-center border-t border-[#1E2028] pt-3">
                    <span className="text-[10px] font-ibm text-gray-600">REV: {company.revenue}</span>
                    <span className="text-[10px] font-ibm text-primary group-hover:translate-x-1 transition-transform">READ DOSSIER →</span>
                  </div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* ALLOCATE PHASE */}
        {phase === "allocate" && (
          <motion.div key="allocate" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex-1 p-6 max-w-6xl mx-auto w-full">
            <div className="mb-8">
              <div className="text-primary font-ibm text-xs tracking-widest mb-2">CAPITAL ALLOCATION // {scenario.title}</div>
              <h2 className="text-3xl font-syne font-bold text-white">DEPLOY YOUR CAPITAL</h2>
              <p className="font-lora text-gray-400 text-sm mt-2 italic">
                Allocate 100% of your portfolio. Max 40% per position. Every percentage point is a decision.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left: Sliders */}
              <div className="lg:col-span-2 space-y-4">
                {scenario.companies.map((company: CompanyDossier, i: number) => {
                  const alloc = allocations[company.id] || 0;
                  const othersTotal = totalAllocated - alloc;
                  const maxAllowable = Math.min(40, 100 - othersTotal);
                  return (
                    <motion.div key={company.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="bg-[#0D0F15] border border-[#1E2028] p-5"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="text-[10px] font-ibm text-gray-500">{company.sector.toUpperCase()}</div>
                          <button onClick={() => setOpenDossier(company)} className="text-sm font-syne font-bold text-white hover:text-primary transition-colors text-left">
                            {company.name}
                          </button>
                        </div>
                        <div className="flex items-center gap-3">
                          <input
                            type="number"
                            min={0}
                            max={maxAllowable}
                            value={alloc}
                            onChange={e => handleSlider(company.id, Number(e.target.value))}
                            className="w-16 bg-[#12141A] border border-[#1E2028] text-white font-ibm text-center text-sm py-1 focus:border-primary outline-none"
                          />
                          <span className="text-gray-500 font-ibm text-xs">%</span>
                        </div>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={maxAllowable}
                        value={alloc}
                        onChange={e => handleSlider(company.id, Number(e.target.value))}
                        className="w-full h-1 appearance-none cursor-pointer"
                        style={{
                          background: `linear-gradient(to right, ${alloc > 0 ? "#00FF88" : "#1E2028"} ${alloc / 40 * 100}%, #1E2028 0%)`
                        }}
                      />
                      <div className="flex justify-between mt-1">
                        <span className="text-[10px] font-ibm text-gray-600">0%</span>
                        <span className="text-[10px] font-ibm text-gray-600">MAX 40%</span>
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              {/* Right: Donut + summary */}
              <div className="space-y-4">
                <div className="bg-[#0D0F15] border border-[#1E2028] p-6">
                  <div className="text-[10px] font-ibm text-gray-500 tracking-widest mb-4">PORTFOLIO COMPOSITION</div>
                  <ResponsiveContainer width="100%" height={180}>
                    <PieChart>
                      <Pie data={donutData} dataKey="value" cx="50%" cy="50%" innerRadius={50} outerRadius={80} strokeWidth={0}>
                        {donutData.map((entry, i) => (
                          <Cell key={i} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ background: "#12141A", border: "1px solid #1E2028", fontFamily: "IBM Plex Mono", fontSize: 10 }} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="mt-3 space-y-1">
                    {donutData.filter(d => d.name !== "Unallocated").map((d, i) => (
                      <div key={i} className="flex items-center gap-2 text-[10px] font-ibm">
                        <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: d.color }} />
                        <span className="text-gray-400 truncate">{d.name}</span>
                        <span className="text-white ml-auto">{d.value}%</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className={`border p-5 ${totalAllocated === 100 ? "border-primary/40 bg-primary/5" : "border-[#1E2028] bg-[#0D0F15]"}`}>
                  <div className="text-[10px] font-ibm text-gray-500 tracking-widest mb-2">ALLOCATED</div>
                  <div className={`text-4xl font-ibm font-bold mb-1 ${totalAllocated === 100 ? "text-primary" : totalAllocated > 100 ? "text-destructive" : "text-white"}`}>
                    {totalAllocated}%
                  </div>
                  <div className="text-xs font-ibm text-gray-500">
                    {remaining > 0 ? `${remaining}% remaining` : remaining < 0 ? "OVER-ALLOCATED" : "FULLY ALLOCATED"}
                  </div>
                </div>

                <button
                  onClick={handleSubmitAllocation}
                  disabled={totalAllocated !== 100}
                  className="w-full py-4 bg-primary text-[#07080D] font-ibm font-bold text-sm disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white transition-colors"
                >
                  {totalAllocated !== 100 ? `ALLOCATE REMAINING ${remaining}%` : "▶ DEPLOY CAPITAL"}
                </button>

                <button onClick={() => setPhase("dossier")} className="w-full py-2 border border-[#1E2028] text-gray-500 font-ibm text-xs hover:text-white hover:border-gray-400 transition-colors">
                  ← BACK TO DOSSIERS
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* RESULT */}
        {phase === "result" && (
          <motion.div key="result" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="flex-1 flex flex-col items-center p-6 max-w-4xl mx-auto w-full pb-20">
            <div className="text-center mb-10 mt-8">
              <div className="text-primary font-ibm text-xs tracking-widest mb-2">SIMULATION COMPLETE</div>
              <h1 className="text-5xl font-syne font-bold uppercase text-white">DEBRIEF</h1>
            </div>

            {/* Portfolio results */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full mb-10">
              <div className="bg-[#0D0F15] border border-[#1E2028] p-6 text-center">
                <div className="text-[10px] font-ibm text-gray-500 mb-2 tracking-wider">FINAL PORTFOLIO</div>
                <div className={`text-3xl font-ibm font-bold ${getReturn() >= 0 ? "text-primary" : "text-destructive"}`}>
                  {formatCur(portfolioValue)}
                </div>
                <div className="text-sm font-ibm mt-2 text-gray-400">{getReturn() > 0 ? "+" : ""}{getReturn().toFixed(2)}%</div>
              </div>
              <div className="bg-[#0D0F15] border border-[#1E2028] p-6 text-center">
                <div className="text-[10px] font-ibm text-gray-500 mb-2 tracking-wider">MARKET BENCHMARK</div>
                <div className="text-3xl font-ibm font-bold text-white">{scenario.benchmark > 0 ? "+" : ""}{scenario.benchmark}%</div>
              </div>
              <div className="bg-[#0D0F15] border border-[#1E2028] p-6 text-center">
                <div className="text-[10px] font-ibm text-gray-500 mb-2 tracking-wider">ALPHA GENERATED</div>
                <div className={`text-3xl font-ibm font-bold ${getReturn() - scenario.benchmark >= 0 ? "text-primary" : "text-destructive"}`}>
                  {getReturn() - scenario.benchmark > 0 ? "+" : ""}{(getReturn() - scenario.benchmark).toFixed(2)}%
                </div>
              </div>
            </div>

            {/* Allocation breakdown */}
            <div className="w-full bg-[#0D0F15] border border-[#1E2028] p-8 mb-8">
              <h3 className="text-xs font-ibm text-gray-500 mb-6 tracking-widest">YOUR ALLOCATION vs WHAT HAPPENED</h3>
              <div className="space-y-4">
                {scenario.companies.map((c: CompanyDossier) => {
                  const alloc = allocations[c.id] || 0;
                  const impact = (scenario.startingPortfolio * alloc / 100) * (c.sectorReturn / 100);
                  return (
                    <div key={c.id} className="grid grid-cols-[1fr_80px_80px_100px] items-center gap-4 text-xs font-ibm">
                      <div>
                        <div className="text-white font-bold">{c.name}</div>
                        <div className="text-gray-500 text-[10px]">{c.sector}</div>
                      </div>
                      <div className="text-gray-400 text-right">{alloc}% alloc</div>
                      <div className={`text-right font-bold ${c.sectorReturn >= 0 ? "text-primary" : "text-destructive"}`}>
                        {c.sectorReturn > 0 ? "+" : ""}{c.sectorReturn}%
                      </div>
                      <div className={`text-right font-bold ${impact >= 0 ? "text-primary" : "text-destructive"}`}>
                        {impact > 0 ? "+" : ""}{formatCur(Math.round(impact))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="w-full bg-[#0D0F15] border border-[#1E2028] p-8 mb-8 relative overflow-hidden">
              <div className="absolute right-0 top-0 text-[120px] opacity-5 font-syne pointer-events-none select-none -mt-8">"</div>
              <h3 className="text-xs font-ibm text-primary mb-4 tracking-wider">THE REALITY // {scenario.referenceInvestor}</h3>
              <p className="font-lora text-xl text-gray-200 italic leading-relaxed relative z-10">"{scenario.referenceQuote}"</p>
            </div>

            <Link href="/market" className="px-8 py-4 border border-[#1E2028] hover:border-primary text-white hover:text-primary font-ibm font-bold tracking-widest text-sm transition-colors">
              &lt; RETURN TO CLASSIFIED FILES
            </Link>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
