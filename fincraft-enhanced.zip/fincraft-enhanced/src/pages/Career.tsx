import React, { useEffect, useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer } from "recharts";
import XPBar from "@/components/XPBar";
import { getProfile, UserProfile } from "@/lib/storage";
import { marketScenarios, boardroomScenarios } from "@/lib/scenarios";

const BADGE_DEFS = [
  { id: "contrarian_hawk", label: "CONTRARIAN HAWK", desc: "Bet against consensus and won" },
  { id: "black_swan_survivor", label: "BLACK SWAN SURVIVOR", desc: "Held through a 40% drawdown" },
  { id: "india_bull", label: "INDIA BULL", desc: "Completed all 3 Indian scenarios" },
  { id: "boardroom_legend", label: "BOARDROOM LEGEND", desc: "Completed all 4 boardrooms" },
  { id: "first_principles", label: "FIRST PRINCIPLES THINKER", desc: "Never chose consensus option" },
  { id: "market_historian", label: "MARKET HISTORIAN", desc: "Completed all 4 market scenarios" },
];

function getArchetype(fp: UserProfile["fingerprint"]): string {
  if (fp.riskAppetite > 70 && fp.contrarianScore > 60) return "CONTRARIAN HAWK";
  if (fp.riskAppetite > 70 && fp.innovationBias > 70) return "ASYMMETRIC THINKER";
  if (fp.riskAppetite < 30 && fp.lossTolerance < 30) return "CAPITAL PRESERVATIONIST";
  if (fp.lossTolerance > 70 && fp.contrarianScore > 60) return "BLACK SWAN NAVIGATOR";
  if (fp.indiaInstinct > 70) return "INDIA BULL";
  return "PATTERN ANALYST";
}

export default function Career() {
  const [profile, setProfile] = useState(getProfile);

  useEffect(() => {
    const refresh = () => setProfile(getProfile());
    window.addEventListener("profile_updated", refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("profile_updated", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const archetype = getArchetype(profile.fingerprint);
  const level = Math.floor(profile.xp / 500) + 1;
  const totalSimulations = profile.completedMarket.length + profile.completedBoardroom.length;
  const canReport = totalSimulations >= 2;

  const radarData = [
    { subject: "RISK", value: profile.fingerprint.riskAppetite, fullMark: 100 },
    { subject: "INNOVATION", value: profile.fingerprint.innovationBias, fullMark: 100 },
    { subject: "LOSS TOLERANCE", value: profile.fingerprint.lossTolerance, fullMark: 100 },
    { subject: "CONTRARIAN", value: profile.fingerprint.contrarianScore, fullMark: 100 },
    { subject: "SPEED", value: profile.fingerprint.decisionSpeed, fullMark: 100 },
    { subject: "INDIA", value: profile.fingerprint.indiaInstinct, fullMark: 100 },
  ];

  return (
    <div className="min-h-[100dvh] w-full bg-[#07080D] text-white flex flex-col pt-16 px-6 pb-16">
      <XPBar />

      <div className="max-w-5xl mx-auto w-full">
        <header className="mb-10 border-b border-[#1E2028] pb-6">
          <Link href="/" className="inline-block text-xs font-ibm text-gray-500 hover:text-primary mb-6 transition-colors">
            &lt; RETURN TO SECURE CHANNEL
          </Link>
          <h1 className="text-4xl md:text-5xl font-syne font-bold tracking-wider mb-2">CAREER DOSSIER</h1>
          <div className="text-primary font-ibm text-sm tracking-widest">FINANCIAL IDENTITY PROFILE</div>
        </header>

        {/* Archetype + Radar */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-[#12141A] border border-[#1E2028] p-8 flex flex-col justify-between">
            <div>
              <div className="text-[10px] font-ibm text-gray-500 mb-3 tracking-widest">FINANCIAL ARCHETYPE</div>
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-3xl md:text-4xl font-syne font-bold text-primary mb-4 tracking-wide"
              >
                {archetype}
              </motion.div>
              <div className="text-sm font-lora text-gray-400 mb-6 leading-relaxed">
                Based on your decision patterns across all simulations.
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3 border-t border-[#1E2028] pt-6">
              <div className="text-center">
                <div className="text-2xl font-ibm font-bold text-white">{profile.xp.toLocaleString()}</div>
                <div className="text-[10px] font-ibm text-gray-500 mt-1">TOTAL XP</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-ibm font-bold text-white">{level}</div>
                <div className="text-[10px] font-ibm text-gray-500 mt-1">LEVEL</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-ibm font-bold text-white">{totalSimulations}</div>
                <div className="text-[10px] font-ibm text-gray-500 mt-1">SIMULATIONS</div>
              </div>
            </div>
          </div>

          <div className="bg-[#12141A] border border-[#1E2028] p-4">
            <div className="text-[10px] font-ibm text-gray-500 mb-2 tracking-widest">FINANCIAL FINGERPRINT</div>
            <ResponsiveContainer width="100%" height={250}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#1E2028" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: "#9ca3af", fontSize: 9, fontFamily: "'IBM Plex Mono', monospace" }} />
                <Radar
                  name="Fingerprint"
                  dataKey="value"
                  stroke="#00FF88"
                  fill="#00FF88"
                  fillOpacity={0.15}
                  strokeWidth={2}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Badges */}
        <div className="bg-[#12141A] border border-[#1E2028] p-8 mb-8">
          <div className="text-[10px] font-ibm text-gray-500 mb-6 tracking-widest">COMMENDATIONS</div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {BADGE_DEFS.map((badge) => {
              const earned = profile.badges.includes(badge.id);
              return (
                <div
                  key={badge.id}
                  className={`border p-4 transition-all ${earned ? "border-primary/40 bg-primary/5" : "border-[#1E2028] opacity-40"}`}
                >
                  <div className={`text-xs font-ibm font-bold mb-1 ${earned ? "text-primary" : "text-gray-600"}`}>
                    {earned ? "★" : "○"} {badge.label}
                  </div>
                  <div className="text-[10px] font-ibm text-gray-500">{badge.desc}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Simulation History */}
        <div className="bg-[#12141A] border border-[#1E2028] p-8 mb-8">
          <div className="text-[10px] font-ibm text-gray-500 mb-6 tracking-widest">SIMULATION HISTORY</div>
          {profile.completedMarket.length === 0 && profile.completedBoardroom.length === 0 ? (
            <p className="font-ibm text-sm text-gray-600">No simulations completed yet. Your record will appear here.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full font-ibm text-xs">
                <thead>
                  <tr className="border-b border-[#1E2028] text-gray-500 text-left">
                    <th className="pb-3 pr-4">SCENARIO</th>
                    <th className="pb-3 pr-4">TYPE</th>
                    <th className="pb-3 pr-4">STATUS</th>
                  </tr>
                </thead>
                <tbody>
                  {profile.completedMarket.map((id) => {
                    const s = marketScenarios.find(x => x.id === id);
                    return s ? (
                      <tr key={id} className="border-b border-[#1E2028]/50">
                        <td className="py-3 pr-4 text-white">{s.title}</td>
                        <td className="py-3 pr-4 text-primary">MARKET</td>
                        <td className="py-3 text-green-400">DEBRIEFED</td>
                      </tr>
                    ) : null;
                  })}
                  {profile.completedBoardroom.map((id) => {
                    const s = boardroomScenarios.find(x => x.id === id);
                    return s ? (
                      <tr key={id} className="border-b border-[#1E2028]/50">
                        <td className="py-3 pr-4 text-white">{s.title}</td>
                        <td className="py-3 pr-4 text-amber-500">BOARDROOM</td>
                        <td className="py-3 text-green-400">VERDICT DELIVERED</td>
                      </tr>
                    ) : null;
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Report CTA */}
        <div className="text-center">
          {canReport ? (
            <Link
              href="/report"
              className="inline-block px-10 py-4 bg-primary text-[#07080D] font-ibm font-bold text-sm tracking-widest hover:bg-white transition-colors"
              data-testid="btn-generate-report"
            >
              &gt;_ GENERATE MY INVESTOR REPORT
            </Link>
          ) : (
            <div className="border border-[#1E2028] p-6 text-center">
              <div className="text-xs font-ibm text-gray-500">COMPLETE 2+ SIMULATIONS TO UNLOCK YOUR INVESTOR REPORT</div>
              <div className="text-primary font-ibm text-sm mt-2">{totalSimulations}/2 completed</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
