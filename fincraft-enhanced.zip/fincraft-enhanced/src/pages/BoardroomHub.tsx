import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import XPBar from "@/components/XPBar";
import { boardroomScenarios } from "@/lib/scenarios";
import { getProfile } from "@/lib/storage";

export default function BoardroomHub() {
  const [, setLocation] = useLocation();
  const profile = getProfile();
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const handleEnter = (scenarioId: string, mode: "solo" | "challenge") => {
    setLocation(`/boardroom/${scenarioId}?mode=${mode}`);
  };

  return (
    <div className="min-h-[100dvh] w-full bg-[#07080D] text-white flex flex-col pt-16 px-6 pb-12">
      <XPBar />

      <div className="max-w-6xl mx-auto w-full">
        <header className="mb-12 border-b border-[#1E2028] pb-6">
          <Link href="/" className="inline-block text-xs font-ibm text-gray-500 hover:text-primary mb-6 transition-colors">
            &lt; RETURN TO SECURE CHANNEL
          </Link>
          <h1 className="text-4xl md:text-5xl font-syne font-bold tracking-wider mb-2">BOARDROOM SIMULATOR</h1>
          <div className="text-primary font-ibm text-sm tracking-widest uppercase">EXECUTIVE BRIEFING FILES — BOARD EYES ONLY</div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {boardroomScenarios.map((scenario, i) => {
            const isCompleted = profile.completedBoardroom.includes(scenario.id);
            const stampText = scenario.subtitle.includes("BOARD EYES ONLY") ? "BOARD EYES ONLY" : "CLASSIFIED";
            const stampColor = scenario.subtitle.includes("BOARD EYES ONLY") ? "border-amber-500 text-amber-500" : "border-destructive text-destructive";

            return (
              <motion.div
                key={scenario.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                onMouseEnter={() => setHoveredId(scenario.id)}
                onMouseLeave={() => setHoveredId(null)}
                className="relative border border-[#1E2028] bg-[#12141A] overflow-hidden"
                style={{
                  boxShadow: hoveredId === scenario.id ? "0 0 30px rgba(0,255,136,0.08)" : "none",
                  borderColor: hoveredId === scenario.id ? "rgba(0,255,136,0.3)" : undefined,
                  transition: "box-shadow 0.3s, border-color 0.3s"
                }}
              >
                {isCompleted && (
                  <div className="absolute top-4 left-4 text-[10px] font-ibm bg-primary/20 text-primary px-2 py-1 border border-primary/30 z-10">
                    VERDICT DELIVERED
                  </div>
                )}

                <div className={`absolute top-4 right-4 text-[9px] font-ibm px-2 py-1 border ${stampColor} transform rotate-[-2deg] z-10`}>
                  {stampText}
                </div>

                <div className="p-6 pt-12">
                  <div className="text-gray-500 font-ibm text-xs mb-1 tracking-widest">
                    {scenario.company} · EXECUTIVE BRIEFING
                  </div>
                  <h2 className="text-2xl font-syne font-bold uppercase mb-4 tracking-wide text-white">
                    {scenario.title}
                  </h2>

                  <div className="flex gap-3 mb-6">
                    {scenario.stats.slice(0, 3).map((stat, si) => (
                      <div key={si} className="flex-1 border border-[#1E2028] p-2 text-center">
                        <div className="text-[9px] font-ibm text-gray-500 mb-1 uppercase">{stat.label}</div>
                        <div className="text-sm font-ibm font-bold text-white">{stat.value}</div>
                        {stat.prev && <div className="text-[9px] font-ibm text-gray-600">prev: {stat.prev}</div>}
                      </div>
                    ))}
                  </div>

                  <p className="font-lora text-gray-400 text-sm leading-relaxed mb-6 line-clamp-2">
                    {scenario.crisis.split(".")[0] + "."}
                  </p>

                  <div className="flex gap-3 border-t border-[#1E2028] pt-4">
                    <button
                      data-testid={`solo-${scenario.id}`}
                      onClick={() => handleEnter(scenario.id, "solo")}
                      className="flex-1 py-3 border border-primary text-primary font-ibm text-xs font-bold tracking-widest hover:bg-primary hover:text-[#07080D] transition-colors"
                    >
                      &gt;_ SOLO MODE
                    </button>
                    <button
                      data-testid={`challenge-${scenario.id}`}
                      onClick={() => handleEnter(scenario.id, "challenge")}
                      className="flex-1 py-3 border border-[#1E2028] text-gray-400 font-ibm text-xs font-bold tracking-widest hover:border-white hover:text-white transition-colors"
                    >
                      &gt;_ CHALLENGE MODE
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
