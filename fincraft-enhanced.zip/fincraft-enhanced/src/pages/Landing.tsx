import React from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import CandlestickChart from "@/components/CandlestickChart";
import XPBar from "@/components/XPBar";

const STATS = [
  { value: "6", label: "Market Crises", sub: "1929 · 1991 · 1992 · 2000 · 2008 · 2020" },
  { value: "6", label: "Boardroom Cases", sub: "Netflix · Amazon · Infosys · Zomato · Twitter · Byju's" },
  { value: "6", label: "Problem Rooms", sub: "First-principles · No historical answer" },
  { value: "∞", label: "Wrong Decisions", sub: "Each with real consequences" },
];

const MODES = [
  {
    href: "/market",
    label: ">_ THE MARKET",
    colorClass: "text-primary",
    desc: "Allocate capital across real historical crashes. 1929. Dot-com. 2008. Covid. Your portfolio, your call.",
  },
  {
    href: "/boardroom",
    label: ">_ THE BOARDROOM",
    colorClass: "text-white",
    desc: "You are in the room where the decision happens. Netflix 2011. Amazon 2003. Twitter 2022. Make the call.",
  },
  {
    href: "/problem",
    label: ">_ THE PROBLEM ROOM",
    colorClass: "text-amber-400",
    desc: "Fictional companies. Real business problems. No historical answer. Pure first-principles judgment.",
    badge: "NEW",
  },
];

export default function Landing() {
  return (
    <div className="min-h-[100dvh] w-full bg-[#07080D] text-white relative overflow-hidden flex flex-col">
      <XPBar />
      <CandlestickChart />

      {/* Hero */}
      <div className="z-10 flex flex-col items-center text-center px-4 max-w-4xl mx-auto mt-24 mb-16">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-6xl md:text-8xl lg:text-[96px] font-syne font-bold tracking-[0.1em] uppercase mb-4"
        >
          FINCRAFT<span className="animate-cursor-blink text-primary">_</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="text-lg md:text-xl font-lora text-gray-400 mb-3 max-w-2xl"
        >
          Every crisis was predictable.
        </motion.p>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7, duration: 0.8 }}
          className="text-lg md:text-xl font-lora text-gray-300 mb-14 max-w-2xl"
        >
          The question is whether you were in the room.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto mb-4"
        >
          <Link href="/market"
            className="group relative inline-flex items-center justify-center px-8 py-4 font-ibm font-bold tracking-widest text-sm text-primary border border-primary bg-[#07080D] hover:bg-primary hover:text-[#07080D] transition-colors duration-300 w-full sm:w-auto overflow-hidden">
            <span className="relative z-10">&gt;_ THE MARKET</span>
          </Link>
          <Link href="/boardroom"
            className="group relative inline-flex items-center justify-center px-8 py-4 font-ibm font-bold tracking-widest text-sm text-white border border-[#1E2028] bg-[#0D0F15] hover:border-white transition-colors duration-300 w-full sm:w-auto">
            <span className="relative z-10">&gt;_ THE BOARDROOM</span>
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.5 }}
          className="w-full sm:w-auto mb-12"
        >
          <Link href="/problem"
            className="group inline-flex items-center justify-center w-full sm:w-auto px-8 py-4 font-ibm font-bold tracking-widest text-sm text-amber-400 border border-amber-400/40 bg-amber-400/5 hover:bg-amber-400/10 hover:border-amber-400 transition-all duration-300">
            <span className="mr-2 text-amber-400/60">◈</span>
            &gt;_ THE PROBLEM ROOM
            <span className="ml-3 text-[10px] font-ibm text-amber-400/50 border border-amber-400/30 px-2 py-0.5">NEW</span>
          </Link>
          <p className="text-[10px] font-ibm text-gray-600 mt-2">First principles. No historical answer. Pure judgment.</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6 }}
          className="flex gap-6 mb-4"
        >
          <Link href="/career" className="text-xs font-ibm text-gray-600 hover:text-white transition-colors underline decoration-dashed underline-offset-4">
            CAREER DOSSIER
          </Link>
          <Link href="/report" className="text-xs font-ibm text-gray-600 hover:text-white transition-colors underline decoration-dashed underline-offset-4">
            INVESTOR REPORT
          </Link>
        </motion.div>
      </div>

      {/* Stats bar */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.8, duration: 0.6 }}
        className="z-10 border-y border-[#1E2028] bg-[#0A0B10]/80 backdrop-blur"
      >
        <div className="max-w-5xl mx-auto px-6 py-8 grid grid-cols-2 md:grid-cols-4 gap-6">
          {STATS.map((s) => (
            <div key={s.label} className="text-center">
              <div className="text-3xl md:text-4xl font-syne font-bold text-primary mb-1">{s.value}</div>
              <div className="text-xs font-ibm text-white tracking-widest uppercase mb-1">{s.label}</div>
              <div className="text-[10px] font-ibm text-gray-600">{s.sub}</div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Mode cards */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 0.8 }}
        className="z-10 max-w-5xl mx-auto px-6 py-16 w-full"
      >
        <div className="text-center mb-10">
          <div className="text-xs font-ibm text-gray-600 tracking-[0.3em] uppercase mb-3">Three Arenas</div>
          <h2 className="text-2xl md:text-3xl font-syne font-bold tracking-wide">Choose Your Simulation</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {MODES.map((mode, i) => (
            <motion.div
              key={mode.href}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 2.1 + i * 0.1 }}
            >
              <Link href={mode.href}
                className="group block border border-[#1E2028] bg-[#0D0F15] p-6 hover:border-primary/40 transition-all duration-300 h-full relative overflow-hidden">
                <div className="absolute top-0 left-0 w-0 group-hover:w-full h-px bg-primary transition-all duration-500" />
                <div className={`font-ibm font-bold text-sm tracking-widest mb-4 flex items-center gap-2 ${mode.colorClass}`}>
                  {mode.label}
                  {mode.badge && (
                    <span className="text-[9px] border border-amber-400/30 text-amber-400/70 px-1.5 py-0.5">{mode.badge}</span>
                  )}
                </div>
                <p className="font-lora text-gray-500 text-sm leading-relaxed">{mode.desc}</p>
                <div className="mt-4 text-xs font-ibm text-gray-700 group-hover:text-primary transition-colors">ENTER &gt;</div>
              </Link>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* How it works */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.3, duration: 0.8 }}
        className="z-10 border-t border-[#1E2028] bg-[#0A0B10]/60 w-full"
      >
        <div className="max-w-5xl mx-auto px-6 py-16">
          <div className="text-center mb-10">
            <div className="text-xs font-ibm text-gray-600 tracking-[0.3em] uppercase mb-3">How It Works</div>
            <h2 className="text-2xl font-syne font-bold tracking-wide">Learn Finance By Doing Finance</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {[
              {
                num: "01",
                title: "Read the Brief",
                body: "Every scenario opens with a classified intelligence file. Real data. Real stakes. Reconstructed from history or engineered from first principles.",
              },
              {
                num: "02",
                title: "Make the Decision",
                body: "Allocate capital across companies, vote on boardroom motions, or pick a strategic path. No hints. No safety nets. Your judgment only.",
              },
              {
                num: "03",
                title: "See the Consequences",
                body: "Watch what actually happened — or what would have happened. Earn XP, unlock badges, build your career dossier.",
              },
            ].map((step) => (
              <div key={step.num} className="border border-[#1E2028] bg-[#0D0F15] p-6">
                <div className="text-3xl font-ibm font-bold text-primary/30 mb-3">{step.num}</div>
                <div className="font-syne font-bold text-sm tracking-wider uppercase mb-3">{step.title}</div>
                <p className="font-lora text-gray-500 text-sm leading-relaxed">{step.body}</p>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Footer */}
      <footer className="z-10 border-t border-[#1E2028] py-8 px-6 text-center">
        <div className="text-[10px] font-ibm text-gray-700 tracking-widest">
          FINCRAFT · GAMIFIED FINANCE EDUCATION · ALL SCENARIOS ARE EDUCATIONAL SIMULATIONS
        </div>
      </footer>
    </div>
  );
}
