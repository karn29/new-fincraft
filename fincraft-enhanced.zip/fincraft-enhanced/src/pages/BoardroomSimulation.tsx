import React, { useState, useEffect, useCallback } from "react";
import { Link, useParams } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  PieChart, Pie, Cell, XAxis, YAxis, ResponsiveContainer, Tooltip, Legend
} from "recharts";
import XPBar from "@/components/XPBar";
import { boardroomScenarios } from "@/lib/scenarios";
import { addXP, markScenarioComplete, unlockBadge } from "@/lib/storage";
import { toast } from "sonner";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, PolarRadiusAxis } from "recharts";
import { getProfile } from "@/lib/storage";

function getAggregate(scenarioId: string, optionId: string) {
  const seed = scenarioId.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  const base = [
    Math.abs((seed * 13) % 40) + 20,
    Math.abs((seed * 7) % 30) + 15,
    Math.abs((seed * 3) % 25) + 10,
  ];
  const total = base.reduce((a, b) => a + b, 0);
  const pcts = base.map(v => Math.round((v / total) * 100));
  const idx = ["A", "B", "C"].indexOf(optionId);
  return idx >= 0 ? pcts[idx] : pcts[0];
}

type EntryStep = "walkin" | "seat" | "agenda" | "slides";

const SEAT_NAMES = ["CEO", "CFO", "CTO", "Board Chair", "Ext. Advisor"];
const PIE_COLORS = ["#00FF88", "#FF2D55", "#F5A623", "#4ECDC4"];

const slideVariants = {
  enter: (d: number) => ({ x: d > 0 ? 80 : -80, opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (d: number) => ({ x: d > 0 ? -80 : 80, opacity: 0 }),
};

const riskColor: Record<string, string> = {
  LOW: "text-primary border-primary/30 bg-primary/5",
  MEDIUM: "text-amber-400 border-amber-400/30 bg-amber-400/5",
  HIGH: "text-orange-500 border-orange-500/30 bg-orange-500/5",
  EXISTENTIAL: "text-destructive border-destructive/30 bg-destructive/5",
};

const horizonColor: Record<string, string> = {
  "Quick Win": "text-primary",
  "2-Year Bet": "text-amber-400",
  "Decade Play": "text-purple-400",
};

export default function BoardroomSimulation() {
  const { scenarioId } = useParams<{ scenarioId: string }>();
  const scenario = boardroomScenarios.find(s => s.id === scenarioId);
  const isChallengeMode = typeof window !== "undefined"
    ? new URLSearchParams(window.location.search).get("mode") === "challenge"
    : false;

  // Entry sequence state
  const [entryStep, setEntryStep] = useState<EntryStep>("walkin");
  const [seatsFilled, setSeatsFilled] = useState<number>(0);
  const [doorOpen, setDoorOpen] = useState(false);
  const [entrySkipped, setEntrySkipped] = useState(false);

  // Slide state
  const [slideIndex, setSlideIndex] = useState(0);
  const [direction, setDirection] = useState(1);
  const [chosenOption, setChosenOption] = useState<string | null>(null);
  const [confirmPending, setConfirmPending] = useState<string | null>(null);
  const [votePct, setVotePct] = useState<number | null>(null);
  const [completed, setCompleted] = useState(false);

  const TOTAL_SLIDES = 9;

  // Door animation
  useEffect(() => {
    if (entryStep !== "walkin") return;
    const t1 = setTimeout(() => setDoorOpen(true), 400);
    const t2 = setTimeout(() => {
      if (!entrySkipped) setEntryStep("seat");
    }, 2800);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [entryStep, entrySkipped]);

  // Seat fill animation
  useEffect(() => {
    if (entryStep !== "seat") return;
    setSeatsFilled(0);
    const intervals: ReturnType<typeof setTimeout>[] = [];
    SEAT_NAMES.forEach((_, i) => {
      intervals.push(setTimeout(() => setSeatsFilled(i + 1), 400 + i * 500));
    });
    const done = setTimeout(() => {
      if (!entrySkipped) setEntryStep("agenda");
    }, 400 + SEAT_NAMES.length * 500 + 600);
    return () => { intervals.forEach(clearTimeout); clearTimeout(done); };
  }, [entryStep, entrySkipped]);

  const goNext = useCallback(() => {
    if (slideIndex < TOTAL_SLIDES - 1) { setDirection(1); setSlideIndex(i => i + 1); }
  }, [slideIndex]);

  const goPrev = useCallback(() => {
    if (slideIndex > 0) { setDirection(-1); setSlideIndex(i => i - 1); }
  }, [slideIndex]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (entryStep !== "slides") return;
      if (e.key === "ArrowRight") goNext();
      if (e.key === "ArrowLeft") goPrev();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [goNext, goPrev, entryStep]);

  const skipEntry = () => {
    setEntrySkipped(true);
    setEntryStep("slides");
  };

  const handleVote = (optionId: string) => {
    if (chosenOption) return;
    setConfirmPending(optionId);
  };

  const confirmVote = () => {
    const optionId = confirmPending!;
    setConfirmPending(null);
    setChosenOption(optionId);
    const option = scenario!.options.find(o => o.id === optionId)!;
    addXP(option.xp);
    window.dispatchEvent(new Event("profile_updated"));

    if (isChallengeMode) {
      setVotePct(getAggregate(scenarioId!, optionId));
    }
    if (!completed) {
      const updated = markScenarioComplete("boardroom", scenarioId!);
      setCompleted(true);
      if (updated.completedBoardroom.length >= 4) {
        if (unlockBadge("boardroom_legend")) toast("BOARDROOM LEGEND UNLOCKED", { description: "All 4 boardroom simulations completed" });
      }
    }
    setTimeout(() => { setDirection(1); setSlideIndex(7); }, isChallengeMode ? 2500 : 800);
  };

  if (!scenario) return <div className="text-white p-10 font-ibm bg-[#07080D] min-h-screen">SCENARIO NOT FOUND.</div>;

  // -- ENTRY SEQUENCE --
  if (entryStep !== "slides") {
    return (
      <div className="min-h-[100dvh] w-full bg-[#030407] text-white flex items-center justify-center relative overflow-hidden">
        <button onClick={skipEntry} className="absolute top-6 right-6 text-[10px] font-ibm text-gray-600 hover:text-gray-400 border border-gray-700 px-3 py-1 transition-colors">
          SKIP INTRO
        </button>

        {/* WALK IN */}
        {entryStep === "walkin" && (
          <motion.div key="walkin" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center gap-12">
            {/* CSS Door */}
            <div className="relative w-40 h-60 flex items-end justify-center">
              {/* Door frame */}
              <div className="absolute inset-0 border-2 border-gray-700" />
              {/* Door panel */}
              <motion.div
                className="absolute inset-1 bg-[#0A0C12] border border-gray-800 origin-left"
                animate={{ rotateY: doorOpen ? -75 : 0 }}
                transition={{ duration: 1.2, ease: "easeInOut" }}
                style={{ transformStyle: "preserve-3d", perspective: 800 }}
              >
                <div className="absolute right-3 top-1/2 w-2 h-2 rounded-full bg-amber-500/60" />
                {/* Door panels */}
                <div className="m-3 border border-gray-800 h-24" />
                <div className="m-3 border border-gray-800 h-16 mt-1" />
              </motion.div>
              {/* Light from inside */}
              <motion.div
                className="absolute inset-0 pointer-events-none"
                animate={{ opacity: doorOpen ? 0.15 : 0 }}
                transition={{ duration: 0.8 }}
                style={{ background: "radial-gradient(ellipse at 30% 50%, #F5A62380, transparent)" }}
              />
            </div>
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: doorOpen ? 1 : 0, y: doorOpen ? 0 : 10 }} transition={{ delay: 0.8 }}
              className="text-center space-y-3">
              <div className="text-gray-500 font-ibm text-[10px] tracking-widest">BOARDROOM ACCESS GRANTED</div>
              <p className="font-lora text-lg text-gray-300 italic">You have been summoned. The board is waiting.</p>
            </motion.div>
          </motion.div>
        )}

        {/* SEAT */}
        {entryStep === "seat" && (
          <motion.div key="seat" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center gap-10">
            <div className="text-[10px] font-ibm text-gray-600 tracking-widest">TAKE YOUR SEAT</div>
            {/* Boardroom table — overhead view */}
            <div className="relative w-80 h-56">
              {/* Table */}
              <div className="absolute left-12 right-12 top-8 bottom-8 bg-[#0D0F15] border-2 border-gray-700 rounded-lg" />
              {/* Wood grain lines */}
              {[0.3, 0.5, 0.7].map(p => (
                <div key={p} className="absolute left-14 right-14 h-px bg-gray-700/40" style={{ top: `${p * 100}%` }} />
              ))}

              {/* Seat positions around table */}
              {/* YOU — bottom center */}
              <motion.div className="absolute bottom-0 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1">
                <div className="w-4 h-4 rounded-full bg-primary animate-pulse" />
                <div className="text-[8px] font-ibm text-primary">YOU</div>
              </motion.div>

              {/* Other seats */}
              {SEAT_NAMES.map((name, i) => {
                const positions = [
                  { top: "0%", left: "20%" },
                  { top: "0%", left: "50%", transform: "translateX(-50%)" },
                  { top: "0%", right: "20%" },
                  { top: "40%", left: "0" },
                  { top: "40%", right: "0" },
                ];
                const pos = positions[i];
                return (
                  <motion.div key={name} className="absolute flex flex-col items-center gap-1" style={pos as React.CSSProperties}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: seatsFilled > i ? 1 : 0.1, scale: seatsFilled > i ? 1 : 0.5 }}
                    transition={{ duration: 0.4 }}>
                    <div className="w-3 h-3 rounded-full bg-gray-500" />
                    <div className="text-[7px] font-ibm text-gray-500 whitespace-nowrap">{name}</div>
                  </motion.div>
                );
              })}
            </div>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: seatsFilled >= SEAT_NAMES.length ? 1 : 0 }} transition={{ delay: 0.3 }}
              className="font-lora text-gray-400 text-sm italic">The room is complete.</motion.p>
          </motion.div>
        )}

        {/* AGENDA */}
        {entryStep === "agenda" && (
          <motion.div key="agenda"
            initial={{ x: 120, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="relative max-w-md w-full mx-6"
          >
            {/* Agenda document */}
            <div className="bg-[#F0EDE6] text-[#1a1a1a] p-10 shadow-2xl">
              <div className="border-b border-gray-300 pb-4 mb-6">
                <div className="text-[10px] tracking-widest text-gray-500 font-ibm uppercase mb-1">Confidential Agenda</div>
                <div className="text-2xl font-syne font-bold uppercase text-[#1a1a1a]">{scenario.company}</div>
              </div>
              <div className="space-y-5 text-sm font-ibm">
                <div>
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Meeting Date</div>
                  <div className="text-[#1a1a1a] font-bold">{scenario.title.split(" ").slice(1).join(" ")}</div>
                </div>
                <div>
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Agenda Item</div>
                  <div className="text-[#1a1a1a] font-bold">{scenario.subtitle.split(".")[0]}</div>
                </div>
                <div>
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Attendees</div>
                  {scenario.boardVoices.map((v: { name: string; title: string }, i: number) => (
                    <div key={i} className="text-[#1a1a1a]">{v.name} — {v.title}</div>
                  ))}
                  <div className="text-[#1a1a1a] font-bold mt-1">You — Board Observer</div>
                </div>
                <div>
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Classification</div>
                  <div className="text-red-700 font-bold uppercase tracking-wider">{scenario.badge}</div>
                </div>
              </div>
            </div>
            <button onClick={() => setEntryStep("slides")}
              className="mt-6 w-full py-3 bg-primary text-[#07080D] font-ibm font-bold text-sm hover:bg-white transition-colors">
              ENTER THE BOARDROOM →
            </button>
          </motion.div>
        )}
      </div>
    );
  }

  // -- SLIDE DECK --
  const profile = getProfile();
  const fingerprintData = [
    { subject: "RISK", value: profile.fingerprint.riskAppetite },
    { subject: "INNOVATION", value: profile.fingerprint.innovationBias },
    { subject: "LOSS TOL.", value: profile.fingerprint.lossTolerance },
    { subject: "CONTRARIAN", value: profile.fingerprint.contrarianScore },
    { subject: "SPEED", value: profile.fingerprint.decisionSpeed },
  ];

  const getVerdictText = (optionId: string | null) => {
    if (!optionId) return "";
    if (optionId === "A") return (scenario as any).verdictA || "";
    if (optionId === "B") return (scenario as any).verdictB || "";
    if (optionId === "C") return (scenario as any).verdictC || "";
    return scenario.verdict;
  };

  const slides = [
    // Slide 0 — THE COMPANY TODAY
    <div key="s0" className="flex flex-col h-full p-8 md:p-12 max-w-4xl mx-auto w-full overflow-y-auto">
      <div className="text-primary font-ibm text-[10px] tracking-widest mb-3">SLIDE 01 — THE COMPANY TODAY</div>
      <h1 className="text-4xl font-syne font-bold uppercase mb-1 text-white">{scenario.title}</h1>
      <div className="text-gray-500 font-ibm text-xs mb-6 tracking-wider">{scenario.company} // EXECUTIVE BRIEFING</div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        {scenario.stats.map((stat, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.15 }}
            className="border border-[#1E2028] p-4 text-center bg-[#12141A]">
            <div className="text-[10px] font-ibm text-gray-500 mb-1 uppercase">{stat.label}</div>
            <div className="text-xl font-ibm font-bold text-white">{stat.value}</div>
            {stat.prev && <div className="text-[10px] font-ibm text-gray-600 mt-1">prev: {stat.prev}</div>}
          </motion.div>
        ))}
      </div>

      <div className="bg-[#12141A] border border-[#1E2028] p-4 mb-3">
        <div className="text-[10px] font-ibm text-gray-500 mb-3 tracking-wider">REVENUE TREND (₹Cr or $B)</div>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={scenario.revenueTrend}>
            <XAxis dataKey="year" tick={{ fill: "#6b7280", fontSize: 10, fontFamily: "IBM Plex Mono" }} />
            <YAxis tick={{ fill: "#6b7280", fontSize: 10, fontFamily: "IBM Plex Mono" }} />
            <Tooltip contentStyle={{ background: "#12141A", border: "1px solid #1E2028", fontFamily: "IBM Plex Mono", fontSize: 10 }} />
            <Bar dataKey="revenue" radius={[2, 2, 0, 0]}>
              {scenario.revenueTrend.map((entry: { growth: boolean }, i: number) => (
                <Cell key={i} fill={entry.growth ? "#00FF88" : "#FF2D55"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <p className="font-lora text-xs text-gray-500 italic">This is how much money the company made each year. The direction tells you everything.</p>
    </div>,

    // Slide 1 — THE MARKET
    <div key="s1" className="flex flex-col h-full p-8 md:p-12 max-w-4xl mx-auto w-full overflow-y-auto">
      <div className="text-amber-500 font-ibm text-[10px] tracking-widest mb-3">SLIDE 02 — THE MARKET THEY OPERATE IN</div>
      <h2 className="text-3xl font-syne font-bold uppercase mb-2 text-white">COMPETITIVE LANDSCAPE</h2>
      <p className="font-lora text-gray-400 text-sm mb-6">
        {scenario.crisis.split(".")[0]}. Market position determines what options you actually have.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 flex-1">
        <div className="bg-[#12141A] border border-[#1E2028] p-4">
          <div className="text-[10px] font-ibm text-gray-500 mb-3 tracking-wider">MARKET SHARE</div>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={scenario.marketShare} dataKey="value" cx="50%" cy="50%" outerRadius={75} strokeWidth={0}
                label={({ name, value }) => `${name} ${value}%`}
                labelLine={{ stroke: "#374151" }}>
                {scenario.marketShare.map((_: unknown, i: number) => (
                  <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: "#12141A", border: "1px solid #1E2028", fontFamily: "IBM Plex Mono", fontSize: 10 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="space-y-3">
          {scenario.marketShare.map((item: { name: string; value: number }, i: number) => (
            <motion.div key={i} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }}
              className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
              <span className="font-ibm text-sm text-gray-300 flex-1">{item.name}</span>
              <span className="font-ibm text-sm font-bold" style={{ color: PIE_COLORS[i % PIE_COLORS.length] }}>{item.value}%</span>
            </motion.div>
          ))}
        </div>
      </div>
      <p className="font-lora text-xs text-gray-500 mt-4 italic">In business, where you stand in the market determines what choices you actually have.</p>
    </div>,

    // Slide 2 — THE CRISIS
    <div key="s2" className="flex flex-col h-full p-8 md:p-12 max-w-4xl mx-auto w-full overflow-y-auto">
      <div className="text-destructive font-ibm text-[10px] tracking-widest mb-3">SLIDE 03 — THE CRISIS</div>
      <h2 className="text-4xl font-syne font-bold uppercase mb-6 text-white">{scenario.subtitle.split(",")[0]}</h2>

      {/* Crisis timeline */}
      <div className="relative mb-8">
        <div className="absolute left-4 top-0 bottom-0 w-px bg-[#1E2028]" />
        <div className="space-y-5">
          {scenario.crisisTimeline.map((event: { date: string; event: string }, i: number, arr: unknown[]) => (
            <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.12 }}
              className="flex gap-6 items-start">
              <div className={`relative flex-shrink-0 w-8 h-8 rounded-full border-2 flex items-center justify-center ${i === arr.length - 1 ? "border-destructive bg-destructive/20 animate-pulse" : "border-[#1E2028] bg-[#07080D]"}`}>
                {i === arr.length - 1 ? (
                  <div className="w-2 h-2 rounded-full bg-destructive" />
                ) : (
                  <div className="text-[8px] font-ibm text-gray-500">{i + 1}</div>
                )}
              </div>
              <div className={`pb-4 ${i < arr.length - 1 ? "border-b border-[#1E2028]" : ""}`}>
                <div className={`text-[10px] font-ibm mb-1 tracking-wider ${i === arr.length - 1 ? "text-destructive" : "text-gray-500"}`}>
                  {event.date} {i === arr.length - 1 ? "— YOU ARE HERE" : ""}
                </div>
                <div className={`font-ibm text-sm ${i === arr.length - 1 ? "text-white font-bold" : "text-gray-300"}`}>{event.event}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>,

    // Slide 3 — THE FINANCIALS UNDER PRESSURE
    <div key="s3" className="flex flex-col h-full p-8 md:p-12 max-w-4xl mx-auto w-full overflow-y-auto">
      <div className="text-amber-500 font-ibm text-[10px] tracking-widest mb-3">SLIDE 04 — THE FINANCIALS UNDER PRESSURE</div>
      <h2 className="text-3xl font-syne font-bold uppercase mb-6 text-white">THE NUMBERS TELL A STORY</h2>
      <div className="bg-[#12141A] border border-[#1E2028] p-4 flex-1 min-h-0">
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={scenario.financialPressure}>
            <XAxis dataKey="period" tick={{ fill: "#6b7280", fontSize: 9, fontFamily: "IBM Plex Mono" }} />
            <YAxis yAxisId="left" tick={{ fill: "#6b7280", fontSize: 9, fontFamily: "IBM Plex Mono" }} />
            <YAxis yAxisId="right" orientation="right" tick={{ fill: "#6b7280", fontSize: 9, fontFamily: "IBM Plex Mono" }} />
            <Tooltip contentStyle={{ background: "#12141A", border: "1px solid #1E2028", fontFamily: "IBM Plex Mono", fontSize: 10 }} />
            <Legend wrapperStyle={{ fontFamily: "IBM Plex Mono", fontSize: 10, color: "#9ca3af" }} />
            {Object.keys(scenario.financialPressure[0] || {})
              .filter(k => k !== "period")
              .map((key, i) => (
                <Line key={key} yAxisId={i === 0 ? "left" : "right"} type="monotone" dataKey={key}
                  stroke={i === 0 ? "#00FF88" : "#FF2D55"} strokeWidth={2} dot={false} />
              ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
      <p className="font-lora text-xs text-gray-500 mt-3 italic">When the red line crosses the green line, the company has a problem it can no longer ignore.</p>
    </div>,

    // Slide 4 — THE BOARD SPEAKS
    <div key="s4" className="flex flex-col h-full p-8 md:p-12 max-w-4xl mx-auto w-full overflow-y-auto">
      <div className="text-primary font-ibm text-[10px] tracking-widest mb-3">SLIDE 05 — THE BOARD SPEAKS</div>
      <h2 className="text-3xl font-syne font-bold uppercase mb-6 text-white">THREE VOICES. ONE ROOM.</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {scenario.boardVoices.map((voice: { avatar: string; name: string; title: string; argument: string }, i: number) => {
          const colors = ["border-primary/30 bg-primary/5", "border-destructive/30 bg-destructive/5", "border-amber-500/30 bg-amber-500/5"];
          const avatarColors = ["bg-primary/20 text-primary", "bg-destructive/20 text-destructive", "bg-amber-500/20 text-amber-400"];
          return (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.2 }}
              className={`border p-5 flex flex-col gap-4 ${colors[i]}`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-ibm font-bold ${avatarColors[i]}`}>
                  {voice.avatar}
                </div>
                <div>
                  <div className="font-syne font-bold text-sm text-white">{voice.name}</div>
                  <div className="text-[10px] font-ibm text-gray-500">{voice.title}</div>
                </div>
              </div>
              {/* Speech bubble */}
              <div className="relative">
                <div className="absolute -top-2 left-4 w-0 h-0 border-l-4 border-r-4 border-b-4 border-l-transparent border-r-transparent border-b-[#1E2028]" />
                <p className="font-lora text-gray-300 text-xs leading-relaxed bg-[#07080D]/50 p-3 italic">
                  "{voice.argument}"
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>,

    // Slide 5 — YOUR DECISION
    <div key="s5" className="flex flex-col h-full p-8 md:p-12 max-w-4xl mx-auto w-full overflow-y-auto">
      <div className="text-destructive font-ibm text-[10px] tracking-widest mb-3">SLIDE 06 — YOUR DECISION</div>
      <h2 className="text-3xl font-syne font-bold uppercase mb-2 text-white">THE CALL IS YOURS</h2>
      <p className="font-lora text-gray-400 text-sm mb-6 italic">The room is waiting. What do you recommend to the board?</p>

      {/* Confirm modal */}
      <AnimatePresence>
        {confirmPending && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-6">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
              className="bg-[#0D0F15] border border-[#1E2028] max-w-md w-full p-8 text-center">
              <div className="text-destructive font-ibm text-xs tracking-widest mb-4">⚠ FINAL CONFIRMATION</div>
              <h3 className="text-xl font-syne font-bold text-white mb-3">Are you certain?</h3>
              <p className="font-lora text-gray-400 text-sm mb-2 italic">
                "{scenario.options.find(o => o.id === confirmPending)?.title}"
              </p>
              <p className="text-xs font-ibm text-gray-600 mb-8">This decision cannot be changed.</p>
              <div className="flex gap-4">
                <button onClick={() => setConfirmPending(null)}
                  className="flex-1 py-3 border border-[#1E2028] text-gray-400 font-ibm text-xs hover:border-white hover:text-white transition-colors">
                  RECONSIDER
                </button>
                <button onClick={confirmVote}
                  className="flex-1 py-3 bg-destructive text-white font-ibm text-xs font-bold hover:bg-red-600 transition-colors">
                  COMMIT
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {!chosenOption ? (
        <div className="space-y-4">
          {scenario.options.map((opt: { id: string; title: string; rationale: string; risk: string; timeHorizon: string }) => (
            <button key={opt.id} onClick={() => handleVote(opt.id)}
              className="w-full p-6 border border-[#1E2028] bg-[#12141A] hover:border-primary hover:bg-primary/5 text-left transition-all group">
              <div className="flex items-start justify-between gap-4 mb-3">
                <div className="flex items-start gap-4">
                  <span className="text-3xl font-ibm font-bold text-primary group-hover:scale-110 transition-transform mt-1">{opt.id}</span>
                  <div>
                    <div className="font-syne font-bold text-lg text-white group-hover:text-primary transition-colors">{opt.title}</div>
                    <p className="font-lora text-gray-400 text-sm mt-1 italic">{opt.rationale}</p>
                  </div>
                </div>
                <div className="flex flex-col gap-2 flex-shrink-0">
                  <span className={`text-[10px] font-ibm px-2 py-1 border ${riskColor[opt.risk] ?? "text-white border-white/20"}`}>
                    {opt.risk}
                  </span>
                  <span className={`text-[10px] font-ibm ${horizonColor[opt.timeHorizon] ?? "text-gray-400"}`}>
                    {opt.timeHorizon}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      ) : (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
          <div className="border border-primary/30 bg-primary/5 p-6">
            <div className="text-primary font-ibm text-[10px] tracking-widest mb-2">YOUR RECOMMENDATION</div>
            <div className="text-xl font-syne font-bold text-white">
              {scenario.options.find((o: { id: string }) => o.id === chosenOption)?.title}
            </div>
          </div>
          {isChallengeMode && votePct !== null && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
              className="border border-[#1E2028] bg-[#12141A] p-5">
              <div className="text-[10px] font-ibm text-gray-500 mb-2 tracking-widest">GLOBAL VOTE AGGREGATE</div>
              {votePct > 50 ? (
                <div className="font-ibm text-white text-sm"><span className="text-primary text-xl font-bold">{votePct}%</span> of players chose this. You were in the majority.</div>
              ) : (
                <div className="font-ibm text-white text-sm">Only <span className="text-amber-400 text-xl font-bold">{votePct}%</span> chose this. You went against the room.</div>
              )}
            </motion.div>
          )}
          <p className="font-ibm text-xs text-gray-500">Moving to outcome reveal...</p>
        </motion.div>
      )}
    </div>,

    // Slide 6 — WHAT ACTUALLY HAPPENED
    <div key="s6" className="flex flex-col h-full p-8 md:p-12 max-w-4xl mx-auto w-full overflow-y-auto">
      <div className="text-primary font-ibm text-[10px] tracking-widest mb-3">SLIDE 07 — WHAT ACTUALLY HAPPENED</div>
      {/* Declassified stamp */}
      <div className="flex items-center gap-4 mb-6">
        <h2 className="text-3xl font-syne font-bold uppercase text-white">DECLASSIFIED</h2>
        <motion.div initial={{ opacity: 0, scale: 0.8, rotate: -8 }} animate={{ opacity: 1, scale: 1, rotate: -8 }}
          transition={{ delay: 0.3 }}
          className="text-destructive border-2 border-destructive px-3 py-1 font-syne font-bold text-sm tracking-widest">
          CLASSIFIED
        </motion.div>
      </div>

      <div className="bg-[#12141A] border border-[#1E2028] p-4 mb-4">
        <div className="text-[10px] font-ibm text-gray-500 mb-3 tracking-wider">KEY METRIC — 3 YEARS AFTER</div>
        <ResponsiveContainer width="100%" height={160}>
          <AreaChart data={scenario.outcomeData}>
            <defs>
              <linearGradient id="outcomeGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={scenario.outcomePositive ? "#00FF88" : "#FF2D55"} stopOpacity={0.3} />
                <stop offset="95%" stopColor={scenario.outcomePositive ? "#00FF88" : "#FF2D55"} stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="year" tick={{ fill: "#6b7280", fontSize: 9, fontFamily: "IBM Plex Mono" }} />
            <YAxis tick={{ fill: "#6b7280", fontSize: 9, fontFamily: "IBM Plex Mono" }} />
            <Tooltip contentStyle={{ background: "#12141A", border: "1px solid #1E2028", fontFamily: "IBM Plex Mono", fontSize: 10 }} />
            <Area type="monotone" dataKey="value" stroke={scenario.outcomePositive ? "#00FF88" : "#FF2D55"}
              fill="url(#outcomeGrad)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-[#12141A] border border-primary/20 p-6 relative overflow-hidden">
        <div className="absolute right-4 top-4 text-[80px] opacity-5 font-syne pointer-events-none">"</div>
        <p className="font-lora text-lg text-gray-200 leading-relaxed italic relative z-10">{scenario.verdict}</p>
      </div>
    </div>,

    // Slide 7 — THE WHAT-IF
    <div key="s7" className="flex flex-col h-full p-8 md:p-12 max-w-4xl mx-auto w-full overflow-y-auto">
      <div className="text-amber-500 font-ibm text-[10px] tracking-widest mb-3">SLIDE 08 — THE WHAT-IF</div>
      <h2 className="text-3xl font-syne font-bold uppercase mb-6 text-white">ALTERNATE TIMELINES</h2>
      <div className="space-y-4">
        {scenario.whatIf.map((wi: { option: string; outcome: string }, i: number) => (
          <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.15 }}
            className="border border-[#1E2028] bg-[#0D0F15] p-6 relative overflow-hidden">
            <div className="absolute top-2 right-3 text-[9px] font-ibm text-gray-700 tracking-widest">ALTERNATE TIMELINE {String.fromCharCode(65 + i)}</div>
            {/* Redacted-style header */}
            <div className="flex items-center gap-3 mb-3">
              <div className="w-4 h-4 bg-gray-700 rotate-45 flex-shrink-0" />
              <div className="text-xs font-ibm text-amber-400 font-bold tracking-wide">{wi.option}</div>
            </div>
            <p className="font-lora text-gray-400 text-sm leading-relaxed">{wi.outcome}</p>
          </motion.div>
        ))}
      </div>
    </div>,

    // Slide 8 — YOUR VERDICT
    <div key="s8" className="flex flex-col h-full p-8 md:p-12 max-w-4xl mx-auto w-full overflow-y-auto">
      <div className="text-primary font-ibm text-[10px] tracking-widest mb-3">SLIDE 09 — YOUR VERDICT</div>
      <h2 className="text-3xl font-syne font-bold uppercase mb-6 text-white">DECISION PROFILE</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="bg-[#12141A] border border-[#1E2028] p-4">
          <div className="text-[10px] font-ibm text-gray-500 mb-3 tracking-wider">THIS SESSION'S FINGERPRINT</div>
          <ResponsiveContainer width="100%" height={180}>
            <RadarChart data={fingerprintData} cx="50%" cy="50%" outerRadius={65}>
              <PolarGrid stroke="#1E2028" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: "#6b7280", fontSize: 9, fontFamily: "IBM Plex Mono" }} />
              <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
              <Radar name="You" dataKey="value" stroke="#00FF88" fill="#00FF88" fillOpacity={0.2} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        <div className="space-y-4">
          {chosenOption && (
            <div className="border border-primary/30 bg-primary/5 p-5">
              <div className="text-[10px] font-ibm text-gray-500 tracking-widest mb-2">YOUR CHOICE</div>
              <div className="font-syne font-bold text-white mb-3">
                {scenario.options.find((o: { id: string }) => o.id === chosenOption)?.title}
              </div>
              <p className="font-lora text-gray-300 text-sm italic leading-relaxed">{getVerdictText(chosenOption)}</p>
            </div>
          )}
          {!chosenOption && (
            <div className="border border-[#1E2028] bg-[#12141A] p-5">
              <div className="text-[10px] font-ibm text-gray-500 tracking-widest mb-2">YOU DIDN'T VOTE</div>
              <p className="font-lora text-gray-500 text-sm italic">Go back to Slide 6 to cast your vote and receive your personal verdict.</p>
            </div>
          )}
        </div>
      </div>

      <Link href="/boardroom"
        className="inline-block mt-auto px-8 py-4 border border-[#1E2028] hover:border-primary text-white hover:text-primary font-ibm font-bold tracking-widest text-sm transition-colors self-start">
        &lt; RETURN TO BRIEFING FILES
      </Link>
    </div>,
  ];

  return (
    <div className="min-h-[100dvh] w-full bg-[#07080D] text-white flex flex-col">
      <XPBar />

      {/* Progress bar */}
      <div className="fixed top-10 left-0 right-0 z-40 bg-[#07080D]">
        <div className="h-0.5 bg-[#1E2028]">
          <motion.div className="h-full bg-primary" initial={{ width: 0 }}
            animate={{ width: `${((slideIndex + 1) / TOTAL_SLIDES) * 100}%` }} transition={{ duration: 0.3 }} />
        </div>
        <div className="flex justify-between px-4 py-1">
          {Array.from({ length: TOTAL_SLIDES }).map((_, i) => (
            <button key={i}
              onClick={() => { setDirection(i > slideIndex ? 1 : -1); setSlideIndex(i); }}
              className={`text-[9px] font-ibm transition-colors ${i === slideIndex ? "text-primary" : "text-gray-700 hover:text-gray-400"}`}>
              {(i + 1).toString().padStart(2, "0")}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 pt-20 overflow-hidden relative">
        <AnimatePresence custom={direction} mode="wait">
          <motion.div key={slideIndex} custom={direction} variants={slideVariants}
            initial="enter" animate="center" exit="exit"
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="absolute inset-0 overflow-y-auto">
            {slides[slideIndex]}
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex justify-between items-center px-8 py-4 border-t border-[#1E2028] bg-[#07080D] z-40">
        <button onClick={goPrev} disabled={slideIndex === 0}
          className="px-6 py-2 font-ibm text-xs border border-[#1E2028] text-gray-400 hover:border-white hover:text-white transition-colors disabled:opacity-20 disabled:cursor-not-allowed">
          ← PREV
        </button>
        <div className="text-[10px] font-ibm text-gray-600">{slideIndex + 1} / {TOTAL_SLIDES} — {scenario.title}</div>
        <button onClick={goNext} disabled={slideIndex === TOTAL_SLIDES - 1}
          className="px-6 py-2 font-ibm text-xs border border-[#1E2028] text-gray-400 hover:border-primary hover:text-primary transition-colors disabled:opacity-20 disabled:cursor-not-allowed">
          NEXT →
        </button>
      </div>
    </div>
  );
}
