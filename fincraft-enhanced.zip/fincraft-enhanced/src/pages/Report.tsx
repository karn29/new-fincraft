import React from "react";
import { Link } from "wouter";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer } from "recharts";
import { getProfile, UserProfile } from "@/lib/storage";
import { marketScenarios, boardroomScenarios } from "@/lib/scenarios";

function getArchetype(fp: UserProfile["fingerprint"]): string {
  if (fp.riskAppetite > 70 && fp.contrarianScore > 60) return "CONTRARIAN HAWK";
  if (fp.riskAppetite > 70 && fp.innovationBias > 70) return "ASYMMETRIC THINKER";
  if (fp.riskAppetite < 30 && fp.lossTolerance < 30) return "CAPITAL PRESERVATIONIST";
  if (fp.lossTolerance > 70 && fp.contrarianScore > 60) return "BLACK SWAN NAVIGATOR";
  if (fp.indiaInstinct > 70) return "INDIA BULL";
  return "PATTERN ANALYST";
}

function getArchetypeInsight(archetype: string): string {
  const insights: Record<string, string> = {
    "CONTRARIAN HAWK": "You move against the crowd with precision. Your decision pattern reveals a high tolerance for social pressure and a strong ability to separate signal from noise. In high-stakes environments, you tend to see inflection points before the consensus does — a rare and valuable cognitive edge. The risk: overconfidence in unconventional reads can lead to early positioning that suffers before it succeeds.",
    "ASYMMETRIC THINKER": "Your profile shows a consistent bias toward asymmetric bets — situations where the upside vastly outweighs the downside. You are drawn to structural change and innovation cycles, and you demonstrate the intellectual courage to back ideas that lack immediate social validation. The risk: this approach requires deep conviction and patience, and can be costly when the thesis is directionally right but early.",
    "CAPITAL PRESERVATIONIST": "Your primary instinct is protection of capital. You make decisions that minimize regret in adverse scenarios, which produces consistency but may underweight opportunity cost in secular bull markets. Your edge is discipline in environments of collective irrationality. The development area: building tolerance for short-term volatility in exchange for long-term compound returns.",
    "BLACK SWAN NAVIGATOR": "You demonstrate an unusual ability to remain functional under extreme market stress. Where others freeze or panic, you execute. This is a rare psychological profile — the capacity to hold nerve during maximum uncertainty is one of the highest-leverage traits an investor can possess. Your development area: ensuring this composure doesn't translate into unnecessary heroism in ordinary situations.",
    "INDIA BULL": "Your pattern shows a deep instinct for India's structural growth story. You consistently identify asymmetric opportunities in the Indian market cycle and show strong conviction in domestic policy catalysts. This is not blind optimism — it reflects an informed thesis on demographic dividends, formalization of the economy, and the scale of India's unmet demand. The risk: home bias can reduce diversification.",
    "PATTERN ANALYST": "You demonstrate balanced cognitive tendencies across risk, innovation, and contrarianism. Your strength is adaptability — you don't anchor rigidly to any single mental model, which gives you flexibility across diverse market environments. Your development path: deepening conviction in specific edge cases where your pattern recognition is strongest.",
  };
  return insights[archetype] ?? insights["PATTERN ANALYST"];
}

function generateId(profile: UserProfile): string {
  const hash = (profile.xp + profile.decisions.length * 17 + profile.streak * 3) % 9999;
  return `FIN-${hash.toString().padStart(4, "0")}`;
}

export default function Report() {
  const profile = getProfile();
  const archetype = getArchetype(profile.fingerprint);
  const reportId = generateId(profile);
  const dateGenerated = new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" });

  const radarData = [
    { subject: "RISK", value: profile.fingerprint.riskAppetite, fullMark: 100 },
    { subject: "INNOVATION", value: profile.fingerprint.innovationBias, fullMark: 100 },
    { subject: "LOSS TOLERANCE", value: profile.fingerprint.lossTolerance, fullMark: 100 },
    { subject: "CONTRARIAN", value: profile.fingerprint.contrarianScore, fullMark: 100 },
    { subject: "SPEED", value: profile.fingerprint.decisionSpeed, fullMark: 100 },
    { subject: "INDIA", value: profile.fingerprint.indiaInstinct, fullMark: 100 },
  ];

  const biasMap: Record<string, { name: string; desc: string }[]> = {
    low_risk: [{ name: "Loss Aversion", desc: "Tendency to strongly prefer avoiding losses over acquiring equivalent gains, leading to sub-optimal portfolio outcomes in asymmetric scenarios." }],
    high_contrarian: [{ name: "Contrarian Bias", desc: "Systematic tendency to position against consensus — a valuable edge when backed by analysis, but a risk when driven by contrarianism alone." }],
    high_innovation: [{ name: "Novelty Bias", desc: "Overweighting of new paradigms and disruptive technologies relative to proven business models — can produce outsized returns or premature positioning." }],
    default: [
      { name: "Recency Bias", desc: "Overweighting recent events in decision-making relative to historical base rates — a universal cognitive tendency particularly costly in late-cycle environments." },
      { name: "Herding Instinct", desc: "Tendency to align with consensus positions for social comfort — measurably costs alpha in moments of maximum crowd convergence." },
    ],
  };

  const getBiases = () => {
    const biases = [];
    if (profile.fingerprint.riskAppetite < 40) biases.push(...biasMap.low_risk);
    if (profile.fingerprint.contrarianScore > 65) biases.push(...biasMap.high_contrarian);
    if (profile.fingerprint.innovationBias > 65) biases.push(...biasMap.high_innovation);
    if (biases.length === 0) biases.push(...biasMap.default);
    return biases.slice(0, 3);
  };

  return (
    <div className="min-h-screen bg-[#07080D] text-white print:bg-white print:text-black">
      {/* Print styles via inline style tag */}
      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white !important; color: black !important; }
          .print-border { border-color: #ccc !important; }
          .print-text-black { color: black !important; }
        }
      `}</style>

      {/* Nav bar (hidden on print) */}
      <div className="no-print fixed top-0 left-0 right-0 z-50 h-10 bg-[#07080D] border-b border-[#1E2028] flex items-center justify-between px-6 font-ibm text-xs">
        <Link href="/career" className="text-gray-500 hover:text-primary transition-colors">&lt; BACK TO CAREER DOSSIER</Link>
        <button
          data-testid="btn-export-pdf"
          onClick={() => window.print()}
          className="px-4 py-1.5 bg-primary text-[#07080D] font-bold hover:bg-white transition-colors"
        >
          EXPORT AS PDF
        </button>
      </div>

      {/* Report content */}
      <div className="max-w-4xl mx-auto px-8 pt-20 pb-16 print:pt-8">

        {/* Header */}
        <div className="border-b border-[#1E2028] pb-8 mb-10 print:border-gray-300">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-[10px] font-ibm text-gray-500 tracking-widest mb-2 print:text-gray-600">FINCRAFT INVESTOR REPORT · CONFIDENTIAL</div>
              <h1 className="text-5xl font-syne font-bold tracking-wide text-white print:text-black mb-2">{archetype}</h1>
              <div className="text-primary font-ibm text-sm print:text-gray-800">FINANCIAL IDENTITY CERTIFICATE</div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-ibm font-bold text-white print:text-black mb-1">{reportId}</div>
              <div className="text-xs font-ibm text-gray-500 print:text-gray-600">{dateGenerated}</div>
              <div className="text-xs font-ibm text-gray-500 print:text-gray-600">{profile.decisions.length} DECISIONS LOGGED</div>
              <div className="text-xs font-ibm text-gray-500 print:text-gray-600">LEVEL {Math.floor(profile.xp / 500) + 1} · {profile.xp.toLocaleString()} XP</div>
            </div>
          </div>
        </div>

        {/* Fingerprint section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
          <div>
            <div className="text-[10px] font-ibm text-gray-500 mb-4 tracking-widest print:text-gray-600">FINANCIAL FINGERPRINT</div>
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#1E2028" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: "#9ca3af", fontSize: 9, fontFamily: "'IBM Plex Mono', monospace" }} />
                <Radar name="Fingerprint" dataKey="value" stroke="#00FF88" fill="#00FF88" fillOpacity={0.15} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-3">
            <div className="text-[10px] font-ibm text-gray-500 mb-4 tracking-widest print:text-gray-600">AXIS SCORES</div>
            {[
              { label: "Risk Appetite", value: profile.fingerprint.riskAppetite },
              { label: "Innovation Bias", value: profile.fingerprint.innovationBias },
              { label: "Loss Tolerance", value: profile.fingerprint.lossTolerance },
              { label: "Contrarian Score", value: profile.fingerprint.contrarianScore },
              { label: "Decision Speed", value: profile.fingerprint.decisionSpeed },
              { label: "India Market Instinct", value: profile.fingerprint.indiaInstinct },
            ].map(({ label, value }) => (
              <div key={label}>
                <div className="flex justify-between text-xs font-ibm mb-1">
                  <span className="text-gray-400 print:text-gray-600">{label}</span>
                  <span className="text-white print:text-black font-bold">{value}</span>
                </div>
                <div className="h-1.5 bg-[#1E2028] print:bg-gray-200">
                  <div className="h-full bg-primary" style={{ width: `${value}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Simulation performance */}
        {(profile.completedMarket.length > 0 || profile.completedBoardroom.length > 0) && (
          <div className="mb-10">
            <div className="text-[10px] font-ibm text-gray-500 mb-4 tracking-widest print:text-gray-600">SIMULATION PERFORMANCE</div>
            <table className="w-full font-ibm text-xs border border-[#1E2028] print:border-gray-300">
              <thead>
                <tr className="border-b border-[#1E2028] print:border-gray-300 bg-[#12141A] print:bg-gray-50">
                  <th className="text-left p-3 text-gray-500 print:text-gray-600">SCENARIO</th>
                  <th className="text-left p-3 text-gray-500 print:text-gray-600">TYPE</th>
                  <th className="text-left p-3 text-gray-500 print:text-gray-600">STATUS</th>
                </tr>
              </thead>
              <tbody>
                {profile.completedMarket.map((id) => {
                  const s = marketScenarios.find(x => x.id === id);
                  return s ? (
                    <tr key={id} className="border-b border-[#1E2028] print:border-gray-200">
                      <td className="p-3 text-white print:text-black">{s.title}</td>
                      <td className="p-3 text-primary print:text-green-700">MARKET</td>
                      <td className="p-3 text-green-400 print:text-green-700">COMPLETE</td>
                    </tr>
                  ) : null;
                })}
                {profile.completedBoardroom.map((id) => {
                  const s = boardroomScenarios.find(x => x.id === id);
                  return s ? (
                    <tr key={id} className="border-b border-[#1E2028] print:border-gray-200">
                      <td className="p-3 text-white print:text-black">{s.title}</td>
                      <td className="p-3 text-amber-500 print:text-amber-700">BOARDROOM</td>
                      <td className="p-3 text-green-400 print:text-green-700">COMPLETE</td>
                    </tr>
                  ) : null;
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Cognitive patterns */}
        <div className="mb-10">
          <div className="text-[10px] font-ibm text-gray-500 mb-4 tracking-widest print:text-gray-600">KEY COGNITIVE PATTERNS</div>
          <div className="space-y-4">
            {getBiases().map((bias) => (
              <div key={bias.name} className="border border-[#1E2028] p-5 print:border-gray-300">
                <div className="font-ibm text-sm font-bold text-white print:text-black mb-2">{bias.name}</div>
                <p className="font-lora text-sm text-gray-400 print:text-gray-700 leading-relaxed">{bias.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Signature Insight */}
        <div className="border border-primary/30 p-8 print:border-gray-400 relative overflow-hidden">
          <div className="absolute right-4 top-2 text-[100px] opacity-5 font-syne pointer-events-none">"</div>
          <div className="text-[10px] font-ibm text-primary mb-4 tracking-widest print:text-gray-600">SIGNATURE INSIGHT</div>
          <p className="font-lora text-base text-gray-200 print:text-gray-800 leading-relaxed relative z-10">
            {getArchetypeInsight(archetype)}
          </p>
          <div className="mt-6 pt-4 border-t border-[#1E2028] print:border-gray-300">
            <div className="font-ibm text-xs text-gray-500 print:text-gray-600">FINCRAFT INTELLIGENCE ENGINE · {reportId} · {dateGenerated}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
