import React from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import XPBar from "@/components/XPBar";
import { marketScenarios } from "@/lib/scenarios";
import { getProfile } from "@/lib/storage";

export default function MarketHub() {
  const profile = getProfile();

  return (
    <div className="min-h-[100dvh] w-full bg-[#07080D] text-white flex flex-col pt-16 px-6 pb-12">
      <XPBar />
      
      <div className="max-w-6xl mx-auto w-full">
        <header className="mb-12 border-b border-[#1E2028] pb-6">
          <Link href="/" className="inline-block text-xs font-ibm text-gray-500 hover:text-primary mb-6 transition-colors">
            &lt; RETURN TO SECURE CHANNEL
          </Link>
          <h1 className="text-4xl md:text-5xl font-syne font-bold tracking-wider mb-2">MARKET SIMULATOR</h1>
          <div className="text-primary font-ibm text-sm tracking-widest uppercase">CLASSIFIED INTELLIGENCE FILES</div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {marketScenarios.map((scenario, i) => {
            const isCompleted = profile.completedMarket.includes(scenario.id);
            const threatColor = scenario.threatLevel === "CRITICAL" ? "text-destructive border-destructive bg-destructive/10" : "text-warning border-warning bg-warning/10";
            
            return (
              <motion.div 
                key={scenario.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="group relative"
              >
                <Link href={`/market/${scenario.id}`} className="block h-full border border-[#1E2028] bg-[#12141A] p-6 hover:border-primary/50 transition-colors relative overflow-hidden">
                  {/* Subtle hover glow */}
                  <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                  
                  {/* Classified stamp */}
                  <div className="absolute top-4 right-4 classified-stamp">
                    CLASSIFIED
                  </div>
                  
                  {isCompleted && (
                    <div className="absolute top-4 left-4 text-[10px] font-ibm bg-primary/20 text-primary px-2 py-1 border border-primary/30">
                      DEBRIEFED
                    </div>
                  )}

                  <div className="mt-10 mb-4">
                    <span className="text-4xl font-ibm font-light text-gray-200 tracking-tighter">
                      {scenario.id}
                    </span>
                  </div>
                  
                  <h2 className="text-xl font-syne font-bold uppercase mb-4 tracking-wide text-gray-100">
                    {scenario.title.split("—")[1]?.trim() || scenario.title}
                  </h2>
                  
                  <div className="mb-6 flex items-center">
                    <span className={`text-[10px] font-ibm px-2 py-1 border ${threatColor}`}>
                      THREAT LEVEL: {scenario.threatLevel}
                    </span>
                  </div>
                  
                  <p className="font-lora text-gray-400 text-sm leading-relaxed mb-6">
                    {scenario.hook}
                  </p>
                  
                  <div className="flex justify-between items-center border-t border-[#1E2028] pt-4 mt-auto">
                    <span className="text-xs font-ibm text-gray-500 uppercase tracking-wider">STATUS: {isCompleted ? 'COMPLETED' : 'UNREAD'}</span>
                    <span className="text-xs font-ibm text-primary group-hover:translate-x-2 transition-transform">DECRYPT &gt;</span>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}