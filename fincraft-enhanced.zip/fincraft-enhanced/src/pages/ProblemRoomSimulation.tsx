import React, { useState } from "react";
import { Link, useParams } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import XPBar from "@/components/XPBar";
import { problemRoomScenarios } from "@/lib/scenarios";
import { addXP, markScenarioComplete } from "@/lib/storage";
import { toast } from "sonner";

type Phase = "brief" | "matrix" | "decide" | "consequences";

const RISK_LABELS: Record<string, string> = {
  LOW: "text-primary",
  "LOW-MEDIUM": "text-primary/70",
  MEDIUM: "text-amber-400",
  "MEDIUM-HIGH": "text-orange-400",
  HIGH: "text-destructive",
};

const REWARD_LABELS: Record<string, string> = {
  CERTAIN: "text-primary",
  STABLE: "text-primary",
  DIRECT: "text-amber-400",
  BALANCED: "text-amber-400",
  STRATEGIC: "text-blue-400",
  HIGH: "text-orange-400",
  "SHORT-TERM": "text-gray-400",
  DEFENSIVE: "text-gray-400",
  MODEST: "text-gray-400",
  ASYMMETRIC: "text-purple-400",
  "BEST CASE": "text-purple-400",
};

export default function ProblemRoomSimulation() {
  const { scenarioId } = useParams<{ scenarioId: string }>();
  const scenario = problemRoomScenarios.find(s => s.id === scenarioId);

  const [phase, setPhase] = useState<Phase>("brief");
  const [chosenOption, setChosenOption] = useState<string | null>(null);
  const [consequenceIndex, setConsequenceIndex] = useState(0);

  if (!scenario) return <div className="text-white p-10 font-ibm bg-[#07080D] min-h-screen">SCENARIO NOT FOUND.</div>;

  const handleDecision = (optionId: string) => {
    setChosenOption(optionId);
    addXP(120);
    window.dispatchEvent(new Event("profile_updated"));
    markScenarioComplete("boardroom", `pr-${scenario.id}`);
    toast("DECISION LOGGED", { description: `You advised: ${scenario.decisions.find(d => d.id === optionId)?.title}` });
    setPhase("consequences");
  };

  const consequences = chosenOption
    ? (scenario.consequences as Record<string, string[]>)[chosenOption] ?? []
    : [];

  const chosen = scenario.decisions.find(d => d.id === chosenOption);

  return (
    <div className="min-h-[100dvh] w-full bg-[#07080D] text-white flex flex-col pt-10">
      <XPBar />

      <AnimatePresence mode="wait">
        {/* BRIEF */}
        {phase === "brief" && (
          <motion.div key="brief" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex-1 max-w-4xl mx-auto w-full p-6 pb-20">
            <Link href="/problem" className="inline-block text-xs font-ibm text-gray-500 hover:text-primary mb-6 transition-colors">
              &lt; ALL SCENARIOS
            </Link>

            <div className="mb-2">
              <div className="text-primary font-ibm text-[10px] tracking-widest mb-1">{scenario.category}</div>
              <h1 className="text-4xl font-syne font-bold uppercase text-white">{scenario.title}</h1>
              <p className="font-lora text-gray-400 mt-2 italic">{scenario.subtitle}</p>
            </div>

            <div className="h-px bg-[#1E2028] my-8" />

            {/* Financials */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
              {scenario.financials.map((f, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
                  className="border border-[#1E2028] bg-[#0D0F15] p-5 text-center">
                  <div className="text-[10px] font-ibm text-gray-500 mb-1 uppercase">{f.label}</div>
                  <div className="text-xl font-ibm font-bold text-white">{f.value}</div>
                  <div className={`text-[10px] font-ibm mt-1 ${f.change.toLowerCase().includes("rising") || f.change.toLowerCase().includes("shrink") || f.change.toLowerCase().includes("flat") ? "text-destructive" : "text-primary"}`}>
                    {f.change}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Company Overview */}
            <div className="mb-8">
              <div className="text-[10px] font-ibm text-gray-500 tracking-widest mb-4">COMPANY OVERVIEW</div>
              <div className="space-y-4">
                <p className="font-lora text-gray-300 leading-relaxed">{scenario.overview}</p>
                <p className="font-lora text-gray-300 leading-relaxed">{scenario.overview2}</p>
              </div>
            </div>

            {/* Problem Statement */}
            <div className="border-l-2 border-destructive pl-6 mb-10">
              <div className="text-[10px] font-ibm text-destructive tracking-widest mb-3">THE PROBLEM</div>
              <p className="font-syne text-white text-lg leading-relaxed">{scenario.problem}</p>
            </div>

            <button onClick={() => setPhase("matrix")}
              className="px-8 py-4 bg-primary text-[#07080D] font-ibm font-bold text-sm hover:bg-white transition-colors">
              STUDY THE DECISION MATRIX →
            </button>
          </motion.div>
        )}

        {/* DECISION MATRIX */}
        {phase === "matrix" && (
          <motion.div key="matrix" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex-1 max-w-4xl mx-auto w-full p-6 pb-20">
            <div className="mb-8">
              <div className="text-primary font-ibm text-[10px] tracking-widest mb-2">DECISION MATRIX // {scenario.title}</div>
              <h2 className="text-3xl font-syne font-bold uppercase text-white">RISK VS REWARD</h2>
              <p className="font-lora text-gray-400 text-sm mt-2 italic">
                Each option is plotted by its estimated risk exposure and potential reward. Position is advisory, not definitive.
              </p>
            </div>

            {/* Matrix plot */}
            <div className="relative bg-[#0D0F15] border border-[#1E2028] mb-8 overflow-hidden" style={{ height: 360 }}>
              {/* Axes */}
              <div className="absolute bottom-8 left-8 right-8 h-px bg-[#1E2028]" />
              <div className="absolute left-8 top-8 bottom-8 w-px bg-[#1E2028]" />
              {/* Labels */}
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[10px] font-ibm text-gray-600">RISK →</div>
              <div className="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] font-ibm text-gray-600 -rotate-90">REWARD →</div>

              {/* Quadrant labels */}
              <div className="absolute top-6 right-10 text-[9px] font-ibm text-gray-700">HIGH RISK / HIGH REWARD</div>
              <div className="absolute top-6 left-12 text-[9px] font-ibm text-gray-700">LOW RISK / HIGH REWARD</div>
              <div className="absolute bottom-10 right-10 text-[9px] font-ibm text-gray-700">HIGH RISK / LOW REWARD</div>
              <div className="absolute bottom-10 left-12 text-[9px] font-ibm text-gray-700">LOW RISK / LOW REWARD</div>

              {/* Grid lines */}
              <div className="absolute left-1/2 top-8 bottom-8 w-px bg-[#1E2028]/40" />
              <div className="absolute left-8 right-8 top-1/2 h-px bg-[#1E2028]/40" />

              {/* Decision dots */}
              {scenario.decisions.map((d, i) => {
                // Convert 0-100 risk/reward to plot positions
                const plotX = 8 + (d.risk / 100) * (100 - 16) + "%";
                const plotY = 8 + ((100 - d.reward) / 100) * (100 - 16) + "%";
                const colors = ["#00FF88", "#FF2D55", "#F5A623", "#4ECDC4"];
                return (
                  <motion.div key={d.id}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.15 }}
                    className="absolute flex flex-col items-center gap-1"
                    style={{ left: plotX, top: plotY, transform: "translate(-50%, -50%)" }}
                  >
                    <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center text-[9px] font-ibm font-bold text-[#07080D] cursor-default"
                      style={{ background: colors[i], borderColor: colors[i] }}>
                      {d.id}
                    </div>
                    <div className="text-[8px] font-ibm whitespace-nowrap" style={{ color: colors[i] }}>
                      {d.title.split(" ").slice(0, 3).join(" ")}
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Decision cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              {scenario.decisions.map((d, i) => {
                const colors = ["#00FF88", "#FF2D55", "#F5A623", "#4ECDC4"];
                return (
                  <div key={d.id} className="border border-[#1E2028] bg-[#0D0F15] p-5">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-ibm font-bold text-[#07080D]"
                        style={{ background: colors[i] }}>
                        {d.id}
                      </div>
                      <div className="font-syne font-bold text-sm text-white">{d.title}</div>
                    </div>
                    <p className="font-ibm text-xs text-gray-400 leading-relaxed mb-3">{d.rationale}</p>
                    <div className="flex gap-4 text-[10px] font-ibm">
                      <span>RISK: <span className={RISK_LABELS[d.riskLabel] || "text-gray-400"}>{d.riskLabel}</span></span>
                      <span>REWARD: <span className={REWARD_LABELS[d.rewardLabel] || "text-gray-400"}>{d.rewardLabel}</span></span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex gap-4">
              <button onClick={() => setPhase("brief")} className="px-6 py-3 border border-[#1E2028] text-gray-400 font-ibm text-xs hover:text-white hover:border-gray-400 transition-colors">
                ← BACK
              </button>
              <button onClick={() => setPhase("decide")}
                className="px-8 py-3 bg-primary text-[#07080D] font-ibm font-bold text-sm hover:bg-white transition-colors">
                MAKE YOUR RECOMMENDATION →
              </button>
            </div>
          </motion.div>
        )}

        {/* DECIDE */}
        {phase === "decide" && (
          <motion.div key="decide" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex-1 max-w-4xl mx-auto w-full p-6 pb-20">
            <div className="mb-8">
              <div className="text-destructive font-ibm text-[10px] tracking-widest mb-2">FINAL RECOMMENDATION // {scenario.title}</div>
              <h2 className="text-3xl font-syne font-bold uppercase text-white">WHAT DO YOU ADVISE?</h2>
              <p className="font-lora text-gray-400 text-sm mt-2 italic">
                There is no historical correct answer. Only your reasoning and its consequences.
              </p>
            </div>

            <div className="space-y-4">
              {scenario.decisions.map((d, i) => {
                const colors = ["#00FF88", "#FF2D55", "#F5A623", "#4ECDC4"];
                return (
                  <motion.button key={d.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    onClick={() => handleDecision(d.id)}
                    className="w-full p-6 border border-[#1E2028] bg-[#0D0F15] text-left hover:border-primary hover:bg-primary/5 transition-all group"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-ibm font-bold text-[#07080D] flex-shrink-0 group-hover:scale-110 transition-transform"
                        style={{ background: colors[i] }}>
                        {d.id}
                      </div>
                      <div>
                        <div className="font-syne font-bold text-lg text-white group-hover:text-primary transition-colors mb-1">{d.title}</div>
                        <p className="font-lora text-gray-400 text-sm italic">{d.rationale}</p>
                        <div className="flex gap-4 mt-3 text-[10px] font-ibm">
                          <span>RISK: <span className={RISK_LABELS[d.riskLabel] || "text-gray-400"}>{d.riskLabel}</span></span>
                          <span>REWARD: <span className={REWARD_LABELS[d.rewardLabel] || "text-gray-400"}>{d.rewardLabel}</span></span>
                        </div>
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* CONSEQUENCES */}
        {phase === "consequences" && (
          <motion.div key="consequences" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="flex-1 max-w-4xl mx-auto w-full p-6 pb-20">
            <div className="mb-8">
              <div className="text-primary font-ibm text-[10px] tracking-widest mb-2">CONSEQUENCE SIMULATION // {scenario.title}</div>
              <h2 className="text-3xl font-syne font-bold uppercase text-white">THREE POSSIBLE FUTURES</h2>
              <p className="font-lora text-gray-400 text-sm mt-2 italic">
                You advised: <span className="text-white not-italic font-semibold">{chosen?.title}</span>. No single outcome is guaranteed.
              </p>
            </div>

            <div className="mb-6 border border-primary/30 bg-primary/5 p-5">
              <div className="text-[10px] font-ibm text-gray-500 mb-2 tracking-wider">YOUR REASONING</div>
              <p className="font-lora text-gray-300 text-sm italic">{chosen?.rationale}</p>
              <div className="flex gap-4 mt-3 text-[10px] font-ibm">
                <span>RISK: <span className={RISK_LABELS[chosen?.riskLabel ?? ""] || "text-gray-400"}>{chosen?.riskLabel}</span></span>
                <span>REWARD: <span className={REWARD_LABELS[chosen?.rewardLabel ?? ""] || "text-gray-400"}>{chosen?.rewardLabel}</span></span>
              </div>
            </div>

            {/* Consequence cards */}
            <div className="space-y-4 mb-10">
              {consequences.map((outcome, i) => {
                const labels = ["OPTIMISTIC SCENARIO", "REALISTIC SCENARIO", "WORST CASE"];
                const colors = ["text-primary border-primary/30", "text-amber-400 border-amber-400/30", "text-destructive border-destructive/30"];
                return (
                  <motion.div key={i}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.15 }}
                    className={`border bg-[#0D0F15] p-6 ${colors[i]}`}>
                    <div className={`text-[10px] font-ibm mb-3 tracking-widest font-bold ${colors[i].split(" ")[0]}`}>
                      {labels[i]}
                    </div>
                    <p className="font-lora text-gray-300 text-sm leading-relaxed">{outcome}</p>
                  </motion.div>
                );
              })}
            </div>

            {/* Key insight */}
            <div className="border border-[#1E2028] bg-[#0D0F15] p-6 mb-8">
              <div className="text-[10px] font-ibm text-gray-500 mb-3 tracking-widest">THE META-LESSON</div>
              <p className="font-lora text-gray-300 italic leading-relaxed">
                Unlike the historical simulations, this scenario has no verified outcome. Your reasoning process — not the choice itself — is what builds judgment. The best analysts aren't the ones who are always right. They're the ones who are right about why they're right.
              </p>
            </div>

            <div className="flex gap-4">
              <Link href="/problem" className="px-8 py-4 border border-[#1E2028] hover:border-primary text-white hover:text-primary font-ibm font-bold tracking-widest text-sm transition-colors">
                &lt; ALL SCENARIOS
              </Link>
              <Link href="/career" className="px-8 py-4 border border-primary/40 text-primary hover:bg-primary hover:text-[#07080D] font-ibm font-bold text-sm transition-colors">
                VIEW CAREER DOSSIER
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
