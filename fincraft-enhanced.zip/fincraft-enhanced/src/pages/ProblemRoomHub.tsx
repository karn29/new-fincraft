import React from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import XPBar from "@/components/XPBar";
import { problemRoomScenarios } from "@/lib/scenarios";
import { getProfile } from "@/lib/storage";

const categoryColors: Record<string, string> = {
  "M&A": "text-amber-400 border-amber-400/30 bg-amber-400/5",
  "B2B SaaS": "text-blue-400 border-blue-400/30 bg-blue-400/5",
  "EV": "text-primary border-primary/30 bg-primary/5",
  "Healthtech": "text-purple-400 border-purple-400/30 bg-purple-400/5",
};

export default function ProblemRoomHub() {
  const profile = getProfile();

  return (
    <div className="min-h-[100dvh] w-full bg-[#07080D] text-white flex flex-col pt-16 px-6 pb-12">
      <XPBar />
      <div className="max-w-6xl mx-auto w-full">
        <header className="mb-12 border-b border-[#1E2028] pb-6">
          <Link href="/" className="inline-block text-xs font-ibm text-gray-500 hover:text-primary mb-6 transition-colors">
            &lt; RETURN TO SECURE CHANNEL
          </Link>
          <h1 className="text-4xl md:text-5xl font-syne font-bold tracking-wider mb-2">THE PROBLEM ROOM</h1>
          <div className="text-primary font-ibm text-sm tracking-widest uppercase mb-4">FIRST-PRINCIPLES DECISION CHAMBER</div>
          <p className="font-lora text-gray-400 text-sm max-w-2xl">
            No historical answer exists. You are handed a company you have never heard of — fully fictional, fully detailed — and given a live business problem to solve from first principles. Your reasoning is your only tool.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {problemRoomScenarios.map((scenario, i) => {
            const isCompleted = profile.completedBoardroom.includes(`pr-${scenario.id}`);
            const firstCategory = scenario.category.split(" · ")[0];
            const colorClass = categoryColors[firstCategory] || "text-gray-400 border-gray-400/30 bg-gray-400/5";

            return (
              <motion.div key={scenario.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="group relative"
              >
                <Link href={`/problem/${scenario.id}`}
                  className="block h-full border border-[#1E2028] bg-[#0D0F15] p-6 hover:border-primary/50 transition-colors relative overflow-hidden">
                  <div className="absolute inset-0 bg-primary/3 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                  <div className="absolute top-0 left-0 w-0 group-hover:w-full h-0.5 bg-primary transition-all duration-500" />

                  {isCompleted && (
                    <div className="absolute top-4 right-4 text-[10px] font-ibm bg-primary/20 text-primary px-2 py-1 border border-primary/30">
                      EVALUATED
                    </div>
                  )}

                  <div className="mb-4">
                    <div className={`inline-block text-[10px] font-ibm px-2 py-1 border tracking-wider ${colorClass}`}>
                      {scenario.category}
                    </div>
                  </div>

                  <h2 className="text-2xl font-syne font-bold uppercase mb-2 text-white group-hover:text-primary transition-colors">
                    {scenario.title}
                  </h2>

                  <p className="font-lora text-gray-400 text-sm leading-relaxed mb-4 italic">
                    {scenario.subtitle}
                  </p>

                  <p className="font-ibm text-xs text-gray-600 leading-relaxed mb-6 line-clamp-2">
                    {scenario.overview.split(".")[0]}.
                  </p>

                  <div className="grid grid-cols-4 gap-2 mb-6">
                    {scenario.financials.map((f, j) => (
                      <div key={j} className="text-center">
                        <div className="text-xs font-ibm font-bold text-white">{f.value}</div>
                        <div className="text-[9px] font-ibm text-gray-600 uppercase mt-0.5">{f.label}</div>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between items-center border-t border-[#1E2028] pt-4">
                    <span className="text-xs font-ibm text-gray-500 uppercase tracking-wider">
                      {scenario.decisions.length} PATHS AVAILABLE
                    </span>
                    <span className="text-xs font-ibm text-primary group-hover:translate-x-1 transition-transform">
                      ENTER THE ROOM →
                    </span>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>

        <div className="mt-12 border border-[#1E2028] p-6 bg-[#0D0F15]">
          <div className="text-[10px] font-ibm text-gray-500 tracking-widest mb-2">HOW THIS WORKS</div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-ibm text-gray-400">
            {["Read the company brief and financial snapshot.", "Study the decision matrix — Risk vs Reward for each path.", "Choose your recommendation. Commit to it.", "See 3 plausible consequence scenarios for your choice. No right answer exists."].map((step, i) => (
              <div key={i} className="flex gap-3 items-start">
                <span className="text-primary font-bold flex-shrink-0">0{i + 1}</span>
                <span>{step}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
