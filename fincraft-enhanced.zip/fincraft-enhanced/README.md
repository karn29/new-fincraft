# FinCraft — Gamified Finance Education

> Every crisis was predictable. The question is whether you were in the room.

FinCraft is a gamified finance EdTech web application that puts you inside real financial crises and boardroom decisions. Make the call with incomplete information. Live with the consequences.

## Features

### 🏦 The Market Simulator
Allocate a real portfolio across companies during 6 historical crashes:
- **1929** — Black Tuesday
- **1991** — India Liberalization
- **1992** — Harshad Mehta Scam
- **2000** — Dot-com Collapse *(new)*
- **2008** — The Great Collapse
- **2020** — Pandemic Panic *(new)*

### 🏛️ The Boardroom
Make executive decisions in 6 real company crises:
- **Netflix 2011** — The Qwikster split
- **Amazon 2003** — Launch AWS or stay retail
- **Infosys 1999** — Bet on post-Y2K
- **Zomato 2021** — Acquire Blinkit
- **Twitter 2022** — Sue Elon or negotiate *(new)*
- **Byju's 2023** — What do you do as CFO *(new)*

### 🧠 The Problem Room
Fully fictional companies, real business problems, zero historical answers:
- Gridline (B2B SaaS price war)
- Solara Mobility (EV term sheet dilemma)
- Lumen Health (monetization ethics)
- Terravia Logistics (unit economics crisis) *(new)*
- Novara Fintech (RBI regulatory notice) *(new)*

### 🎮 Progression System
- XP and leveling across all three modes
- Achievement badges
- Career Dossier — a persistent record of your decisions
- Investor Report — your full performance history

---

## Tech Stack

- **React 18** + TypeScript
- **Vite 5** (no Replit plugins)
- **Tailwind CSS v4** + shadcn/ui
- **Framer Motion** for animations
- **Recharts** for data visualizations
- **Wouter** for routing
- **localStorage** for progress persistence (no backend required)

---

## Getting Started

```bash
npm install
npm run dev
```

Visit `http://localhost:5173`

### Build for production

```bash
npm run build
```

Output is in `dist/` — deploy to Vercel, Netlify, or GitHub Pages.

### Deploy to Vercel (recommended)

```bash
npm install -g vercel
vercel
```

### Deploy to Netlify

```bash
npm run build
# Drag the dist/ folder to netlify.com/drop
```

---

## Project Structure

```
src/
├── components/        # Shared UI components (XPBar, Charts, etc.)
├── components/ui/     # shadcn/ui component library
├── hooks/             # Custom React hooks
├── lib/
│   ├── scenarios.ts   # All game content (market, boardroom, problem room)
│   └── storage.ts     # localStorage persistence layer
├── pages/
│   ├── Landing.tsx
│   ├── MarketHub.tsx / MarketSimulation.tsx
│   ├── BoardroomHub.tsx / BoardroomSimulation.tsx
│   ├── ProblemRoomHub.tsx / ProblemRoomSimulation.tsx
│   ├── Career.tsx
│   └── Report.tsx
└── App.tsx
```

---

## Adding New Scenarios

All content lives in `src/lib/scenarios.ts`. Three arrays:

- `marketScenarios[]` — historical market crash simulations
- `boardroomScenarios[]` — executive decision cases
- `problemRoomScenarios[]` — fictional first-principles problems

Each array has a well-typed schema at the top of the file.

---

## License

MIT
